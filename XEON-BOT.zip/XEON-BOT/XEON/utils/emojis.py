"""
utils/emojis.py
═══════════════════════════════════════════════════════════════
Backward-compatible shim — DO NOT import emoji literals here.

All emoji definitions live in:
    emojis.json             (source of truth / fallback IDs)
    emojis.uploaded.json    (application emoji IDs after upload)
    XEON/emojis.py          (manager with fallback logic)

This file re-exports every constant from XEON/emojis.py so that
all existing  `from utils import emojis as E`  calls in cogs
continue to work without any changes to those cog files.

Usage:
    from utils import emojis as E
    f"{E.SUCCESS} Done!"
    f"{E.ERROR} Failed!"
═══════════════════════════════════════════════════════════════
"""

from XEON.emojis import E as _E

# ── Attribute-style proxy ──────────────────────────────────────
# Every attribute access on this module (e.g. emojis.SUCCESS)
# is forwarded to the singleton EmojiMap.

import sys as _sys

class _Proxy(_sys.modules[__name__].__class__):
    def __getattr__(self, name: str) -> str:
        val = _E[name]
        if val != "❔" or name in _E:
            return val
        raise AttributeError(f"Emoji key '{name}' not found in emojis.json")

_sys.modules[__name__].__class__ = _Proxy

# ── Also expose E directly for convenience ─────────────────────
E = _E
