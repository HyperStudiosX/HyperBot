"""
XEON/emojis.py
═══════════════════════════════════════════════════════════════
Centralized Emoji Manager for XEON Bot.

Resolution order for every key:
  1. emojis.uploaded.json  — IDs after upload to Discord Application
                             (produced by scripts/upload_application_emojis.py)
  2. emojis.json           — Original / fallback guild emoji IDs

Usage anywhere in the project:
    from XEON.emojis import E
    f"{E.SUCCESS} Done!"
    f"{E['ERROR']} Failed!"    # dict-style also works

Both attribute-style (E.KEY) and dict-style (E["KEY"]) are supported.
All keys are UPPER_CASE strings.
═══════════════════════════════════════════════════════════════
"""

from __future__ import annotations

import json
import os
import re
from typing import Optional

# ── Paths ────────────────────────────────────────────────────────────────────
_BASE_DIR      = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_DEFINITIONS   = os.path.join(_BASE_DIR, "emojis.json")
_UPLOADED      = os.path.join(_BASE_DIR, "emojis.uploaded.json")

# ── Helpers ───────────────────────────────────────────────────────────────────
_EMOJI_RE = re.compile(r"^<(a)?:([A-Za-z0-9_]+):(\d+)>$")


def _parse(literal: str) -> Optional[dict]:
    """Parse '<a:name:id>' or '<:name:id>' into a dict."""
    m = _EMOJI_RE.match(literal)
    if not m:
        return None
    return {"animated": bool(m.group(1)), "name": m.group(2), "id": m.group(3)}


def _format(name: str, eid: str, animated: bool) -> str:
    return f"<{'a' if animated else ''}:{name}:{eid}>"


def _load_json(path: str) -> dict:
    try:
        if not os.path.exists(path):
            return {}
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as exc:
        print(f"[XEON/emojis] Failed to load {os.path.basename(path)}: {exc}")
        return {}


# ── EmojiMap class ────────────────────────────────────────────────────────────

class _EmojiMap:
    """
    Flat key→string emoji map that supports both attribute and dict access.
    Loaded once at import time; call reload() after running the upload script
    if you want the bot process to pick up new IDs without restarting.
    """

    def __init__(self):
        self._map: dict[str, str] = {}
        self._load()

    # ── Internal loader ───────────────────────────────────────────────────────

    def _load(self):
        definitions = _load_json(_DEFINITIONS)
        uploaded    = _load_json(_UPLOADED)

        # First pass: map every source (guild) emoji ID -> its uploaded
        # Application emoji result, wherever ANY key recorded one for it.
        # This is what lets newly-added keys that happen to reuse an
        # already-uploaded source ID (e.g. several keys all fall back to
        # the same "grey_arrw" guild emoji) resolve to the Application
        # emoji immediately, without needing their own separate upload
        # cache entry or a re-run of the upload script.
        source_id_to_upload: dict[str, dict] = {}
        for key, fallback_literal in definitions.items():
            if key.startswith("_") or not isinstance(fallback_literal, str):
                continue
            parsed = _parse(fallback_literal)
            if not parsed:
                continue
            up = uploaded.get(key)
            if up and isinstance(up, dict) and up.get("id") and up.get("name"):
                source_id_to_upload.setdefault(parsed["id"], up)

        result: dict[str, str] = {}

        for key, fallback_literal in definitions.items():
            if key.startswith("_"):
                continue   # skip comment keys

            # 1. This key's own uploaded entry, if present.
            up = uploaded.get(key)
            if up and isinstance(up, dict) and up.get("id") and up.get("name"):
                result[key] = _format(up["name"], str(up["id"]), bool(up.get("animated")))
                continue

            # 2. No direct entry — but if this key's fallback shares a
            #    source ID with another key that WAS uploaded, reuse that
            #    Application emoji instead of the stale guild fallback.
            parsed = _parse(fallback_literal) if isinstance(fallback_literal, str) else None
            if parsed:
                sibling_up = source_id_to_upload.get(parsed["id"])
                if sibling_up:
                    result[key] = _format(
                        sibling_up["name"], str(sibling_up["id"]), bool(sibling_up.get("animated"))
                    )
                    continue

            # 3. Fall back to the raw literal stored in emojis.json.
            if parsed:
                result[key] = _format(parsed["name"], parsed["id"], parsed["animated"])
            elif isinstance(fallback_literal, str):
                result[key] = fallback_literal   # unicode emoji
            else:
                result[key] = "❔"

        # Keys only in uploaded (newly added)
        for key, up in uploaded.items():
            if key not in result and isinstance(up, dict) and up.get("id") and up.get("name"):
                result[key] = _format(up["name"], str(up["id"]), bool(up.get("animated")))

        self._map = result

    # ── Public API ────────────────────────────────────────────────────────────

    def reload(self):
        """Reload from disk. Call after running the upload script."""
        self._load()
        return self

    def get(self, key: str, default: str = "❔") -> str:
        return self._map.get(key, default)

    def keys(self):
        return self._map.keys()

    def items(self):
        return self._map.items()

    def __getattr__(self, key: str) -> str:
        try:
            return self._map[key]
        except KeyError:
            # Don't raise AttributeError for missing keys — return fallback
            return "❔"

    def __getitem__(self, key: str) -> str:
        return self._map.get(key, "❔")

    def __contains__(self, key: str) -> bool:
        return key in self._map

    def __repr__(self) -> str:
        return f"<EmojiMap keys={len(self._map)}>"


# ── Singleton ─────────────────────────────────────────────────────────────────

E = _EmojiMap()

# Convenience: expose E directly so callers can do:
#   from XEON.emojis import E
#   E.SUCCESS
