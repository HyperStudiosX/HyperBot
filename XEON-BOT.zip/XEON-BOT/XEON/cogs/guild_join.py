"""
Guild Join Cog — Welcome messages when bot joins a server.
Components V2 container style.

- DM to server owner: Thanks + prefix info + buttons
- Server message: Welcome info + buttons
"""

import discord
from discord.ext import commands
from discord import ui


# ── Emojis (Name + ID — change IDs here ONLY) ────────────────────────────────

from XEON.emojis import E as _EMGR
import re as _re

# Local key -> central emojis.json key (sourced from XEON/emojis.py)
_LOCAL_KEY_MAP = {
    "success": "SUCCESS",
    "error": "ERROR",
    "info": "INFO",
    "wave": "WAVE",
    "link": "LINK_ICO",
}

def E(key: str) -> discord.PartialEmoji:
    """Returns a discord.PartialEmoji for buttons/select options."""
    s = _EMGR[_LOCAL_KEY_MAP.get(key, key.upper())]
    m = _re.match(r'<(a)?:([A-Za-z0-9_]+):(\d+)>', s)
    if m:
        return discord.PartialEmoji(name=m.group(2), id=int(m.group(3)), animated=bool(m.group(1)))
    return discord.PartialEmoji(name='grey_arrw', id=1517367908714549308)

def ES(key: str) -> str:
    """Returns the raw emoji string for text/embeds."""
    return _EMGR[_LOCAL_KEY_MAP.get(key, key.upper())]


# ── Config (change these) ────────────────────────────────────────────────────

DEFAULT_PREFIX = "&"                                        # ← Your bot's default prefix
SUPPORT_LINK = "https://discord.gg/VmKvfWHHBa"     # ← Your support server invite
INVITE_LINK = "https://discord.com/oauth2/authorize?client_id=1517529925702123592&permissions=8&integration_type=0&scope=bot+applications.commands"  # ← Bot invite / website
BOT_NAME = "XEON"                                          # ← Your bot's name

DEFAULT_ACCENT = discord.Colour(0x000000)


# ── DM View (sent to server owner) ───────────────────────────────────────────

class WelcomeDMView(ui.LayoutView):
    def __init__(self, bot: commands.Bot, guild: discord.Guild):
        super().__init__(timeout=None)

        c = ui.Container(accent_color=DEFAULT_ACCENT)

        # Header with bot avatar
        header = ui.TextDisplay(
            f"{ES('wave')} **Thanks for adding {BOT_NAME}!**\n\n"
            f"My default prefix is `{DEFAULT_PREFIX}`\n"
            f"Use `{DEFAULT_PREFIX}help` in the server for commands\n"
            f"For questions join the **Support server**"
        )

        if bot.user and bot.user.avatar:
            section = ui.Section(
                header,
                accessory=ui.Thumbnail(
                    media=discord.UnfurledMediaItem(url=bot.user.display_avatar.url)
                ),
            )
            c.add_item(section)
        else:
            c.add_item(header)

        c.add_item(ui.Separator())

        # Buttons: Support + Invite
        c.add_item(ui.ActionRow(
            ui.Button(
                label="Support Server",
                style=discord.ButtonStyle.link,
                url=SUPPORT_LINK,
            ),
            ui.Button(
                label="Invite Bot",
                style=discord.ButtonStyle.link,
                url=INVITE_LINK,
            ),
        ))

        # Button: Go to server
        c.add_item(ui.ActionRow(
            ui.Button(
                label=f"Go to {guild.name}"[:80],
                style=discord.ButtonStyle.link,
                url=f"https://discord.com/channels/{guild.id}",
            ),
        ))

        c.add_item(ui.Separator(visible=False))
        c.add_item(ui.TextDisplay(f"-# {BOT_NAME} • Thanks for choosing us"))

        self.add_item(c)


# ── Server View (posted in the server) ────────────────────────────────────────

class WelcomeServerView(ui.LayoutView):
    def __init__(self, bot: commands.Bot, guild: discord.Guild):
        super().__init__(timeout=None)

        c = ui.Container(accent_color=DEFAULT_ACCENT)

        # Header with bot avatar
        header = ui.TextDisplay(
            f"{ES('wave')} **Thanks for adding {BOT_NAME}!**\n\n"
            f"My default prefix is `{DEFAULT_PREFIX}`\n"
            f"Use `{DEFAULT_PREFIX}help` or mention me for commands\n"
            f"For questions join our **Support server**"
        )

        if bot.user and bot.user.avatar:
            section = ui.Section(
                header,
                accessory=ui.Thumbnail(
                    media=discord.UnfurledMediaItem(url=bot.user.display_avatar.url)
                ),
            )
            c.add_item(section)
        else:
            c.add_item(header)

        c.add_item(ui.Separator())

        # Buttons
        c.add_item(ui.ActionRow(
            ui.Button(
                label="Support Server",
                style=discord.ButtonStyle.link,
                url=SUPPORT_LINK,
            ),
            ui.Button(
                label="Invite Bot",
                style=discord.ButtonStyle.link,
                url=INVITE_LINK,
            ),
        ))

        c.add_item(ui.Separator(visible=False))
        c.add_item(ui.TextDisplay(f"-# Use `{DEFAULT_PREFIX}help` to get started"))

        self.add_item(c)


# ── Cog ───────────────────────────────────────────────────────────────────────

class GuildJoin(commands.Cog):
    """Welcome messages when bot joins a new server."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_guild_join(self, guild: discord.Guild):
        # ── 1. DM the server owner ──
        owner = guild.owner
        if owner:
            try:
                dm_view = WelcomeDMView(self.bot, guild)
                await owner.send(view=dm_view)
            except discord.Forbidden:
                pass
            except Exception:
                pass

        # ── 2. Post in the server ──
        target_channel = self._find_channel(guild)
        if not target_channel:
            return

        try:
            server_view = WelcomeServerView(self.bot, guild)
            await target_channel.send(view=server_view)
        except discord.Forbidden:
            pass
        except Exception:
            pass

    def _find_channel(self, guild: discord.Guild) -> discord.TextChannel | None:
        """Find the best channel to post the welcome in."""
        me = guild.me
        if not me:
            return None

        # Priority 1: common channel names
        priority_names = ("general", "welcome", "bot-commands", "commands", "bot", "chat")
        for name in priority_names:
            ch = discord.utils.find(
                lambda c: (
                    isinstance(c, discord.TextChannel)
                    and name in c.name.lower()
                    and c.permissions_for(me).send_messages
                ),
                guild.channels,
            )
            if ch:
                return ch

        # Priority 2: system channel
        if guild.system_channel and guild.system_channel.permissions_for(me).send_messages:
            return guild.system_channel

        # Priority 3: first text channel with perms
        for ch in guild.text_channels:
            if ch.permissions_for(me).send_messages:
                return ch

        return None


async def setup(bot: commands.Bot):
    await bot.add_cog(GuildJoin(bot))