/*
============================================================
Created by HyperForgeX
Copyright © 2026 HyperForgeX. All rights reserved.
============================================================
*/

let dashboardData = null;
let currentPage = "dashboard";

/*
============================================================
HELPERS
============================================================
*/

function $(id) {
    return document.getElementById(id);
}

function formatNumber(value) {
    return Number(value || 0).toLocaleString();
}

function mbToGB(mb) {
    return (Number(mb || 0) / 1024).toFixed(1);
}

function escapeHtml(value) {
    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

async function api(url, options = {}) {
    const response = await fetch(
        url,
        {
            credentials: "same-origin",
            ...options
        }
    );

    if (response.status === 401) {
        showLogin();
        throw new Error("Authentication required");
    }

    const data = await response.json();

    if (!response.ok) {
        throw new Error(
            data.error || "Request failed"
        );
    }

    return data;
}

/*
============================================================
AUTH
============================================================
*/

async function loadAuth() {
    const data =
        await api("/api/auth/me");

    if (!data.authenticated) {
        showLogin();
        return false;
    }

    $("username").textContent =
        data.user.globalName ||
        data.user.username;

    $("welcomeName").textContent =
        data.user.globalName ||
        data.user.username;

    if (data.user.avatar) {
        $("avatar").src =
            `https://cdn.discordapp.com/avatars/${data.user.id}/${data.user.avatar}.png?size=128`;
    } else {
        $("avatar").src =
            `https://cdn.discordapp.com/embed/avatars/0.png`;
    }

    if (data.admin) {
        $("adminNavigation")
            .classList.remove("hidden");
    }

    return true;
}

function showLogin() {
    $("loginScreen")
        .classList.remove("hidden");

    $("dashboardContent")?.classList.add(
        "hidden"
    );
}

/*
============================================================
DASHBOARD DATA
============================================================
*/
async function loadServerStatus(serverId) {
    try {
        const data =
            await api(
                `/api/servers/${encodeURIComponent(serverId)}/status`
            );

        const status =
            data.status?.current_state ||
            data.status?.state ||
            "unknown";

        const element =
            $(`status-${serverId}`);

        if (!element) {
            return;
        }

        element.textContent =
            status;

        element.classList.remove(
            "online",
            "offline"
        );

        if (
            status === "running"
        ) {
            element.classList.add(
                "online"
            );
        } else {
            element.classList.add(
                "offline"
            );
        }

    } catch (error) {
        const element =
            $(`status-${serverId}`);

        if (element) {
            element.textContent =
                "Unavailable";
        }
    }
}

async function serverPower(
    serverId,
    action
) {
    try {
        const response =
            await api(
                `/api/servers/${encodeURIComponent(serverId)}/power`,
                {
                    method: "POST",
                    headers: {
                        "Content-Type":
                            "application/json"
                    },
                    body:
                        JSON.stringify({
                            action
                        })
                }
            );

        if (response.success) {
            await loadDashboard();
        }

    } catch (error) {
        alert(
            error.message
        );
    }
}

async function renameServer(
    serverId
) {
    const name =
        prompt(
            "Enter the new server name:"
        );

    if (!name) {
        return;
    }

    try {
        await api(
            `/api/servers/${encodeURIComponent(serverId)}`,
            {
                method: "PATCH",
                headers: {
                    "Content-Type":
                        "application/json"
                },
                body:
                    JSON.stringify({
                        name
                    })
            }
        );

        await loadDashboard();

    } catch (error) {
        alert(
            error.message
        );
    }
}

async function deleteServer(
    serverId
) {
    const confirmed =
        confirm(
            "Are you sure you want to delete this server?\n\nYour server will be removed from Pterodactyl and its resources will be refunded."
        );

    if (!confirmed) {
        return;
    }

    const secondConfirm =
        confirm(
            "This action cannot be undone. Continue?"
        );

    if (!secondConfirm) {
        return;
    }

    try {
        await api(
            `/api/servers/${encodeURIComponent(serverId)}`,
            {
                method: "DELETE"
            }
        );

        await loadDashboard();

    } catch (error) {
        alert(
            error.message
        );
    }
}

async function loadDashboard() {
    try {
        dashboardData =
            await api("/api/dashboard");

        renderDashboard(
            dashboardData
        );

    } catch (error) {
        console.error(
            "[Dashboard]",
            error
        );
    }
}

function renderDashboard(data) {

    const stats =
        data.stats || {};

    const resources =
        stats.resources ||
        data.resources ||
        {};

    const servers =
        data.servers || [];

    $("coins").textContent =
        formatNumber(
            stats.coins ??
            data.balance ??
            0
        );

    $("servers").textContent =
        formatNumber(
            servers.length
        );

    $("ram").textContent =
        `${mbToGB(resources.ram)} GB`;

    $("disk").textContent =
        `${mbToGB(resources.disk)} GB`;

    $("resourceRam").textContent =
        `${mbToGB(resources.ram)} GB`;

    $("resourceCpu").textContent =
        `${formatNumber(resources.cpu)}%`;

    $("resourceDisk").textContent =
        `${mbToGB(resources.disk)} GB`;

    $("allocations").textContent =
        formatNumber(
            resources.allocations
        );

    $("databases").textContent =
        formatNumber(
            resources.databases
        );

    $("backups").textContent =
        formatNumber(
            resources.backups
        );

    $("ramProgress").style.width =
        `${Math.min(100, Number(resources.ram || 0) / 32768 * 100)}%`;

    $("cpuProgress").style.width =
        `${Math.min(100, Number(resources.cpu || 0) / 500 * 100)}%`;

    $("diskProgress").style.width =
        `${Math.min(100, Number(resources.disk || 0) / 81920 * 100)}%`;

    renderServers(
        servers
    );

    renderTransactions(
        data.transactions || []
    );

    renderPlans(
        data.plans || []
    );

    renderServerPage(
        servers
    );

    renderResourcePage(
        resources
    );
}

/*
============================================================
SERVERS
============================================================
*/

function renderServers(servers) {

    const container =
        $("serverList");

    if (!servers.length) {
        container.innerHTML = `
            <div class="empty-state">
                You don't have any servers yet.
            </div>
        `;

        return;
    }

    container.innerHTML =
        servers
            .slice(0, 5)
            .map(server => `
                <div class="server-item">

                    <div class="server-item-icon">
                        ▣
                    </div>

                    <div class="server-item-info">

                        <strong>
                            ${escapeHtml(server.name)}
                        </strong>

                        <span>
                            ID:
                            ${escapeHtml(server.id)}
                        </span>

                    </div>

                    <span class="server-status">
                        Active
                    </span>

                </div>
            `)
            .join("");
}

function renderServerPage(servers) {
    const container = $("serversPageList");

    if (!container) {
        return;
    }

    if (!servers.length) {
        container.innerHTML = `
            <div class="panel empty-state">
                You don't have any servers yet.
            </div>
        `;

        return;
    }

    container.innerHTML = servers.map(server => `
        <div class="server-card">

            <div class="server-card-header">

                <div class="server-item-icon">
                    ▣
                </div>

                <div>
                    <strong>
                        ${escapeHtml(server.name)}
                    </strong>

                    <span>
                        Server ID:
                        ${escapeHtml(server.id)}
                    </span>
                </div>

                <span
                    class="server-status"
                    id="status-${escapeHtml(server.id)}"
                >
                    Checking...
                </span>

            </div>

            <div class="server-card-resources">

                <div class="server-resource">
                    <span>RAM</span>
                    <strong>
                        ${mbToGB(server.ram)} GB
                    </strong>
                </div>

                <div class="server-resource">
                    <span>CPU</span>
                    <strong>
                        ${formatNumber(server.cpu)}%
                    </strong>
                </div>

                <div class="server-resource">
                    <span>DISK</span>
                    <strong>
                        ${mbToGB(server.disk)} GB
                    </strong>
                </div>

            </div>

            <div class="server-actions">

                <button
                    onclick="serverPower('${escapeHtml(server.id)}','start')"
                >
                    Start
                </button>

                <button
                    onclick="serverPower('${escapeHtml(server.id)}','restart')"
                >
                    Restart
                </button>

                <button
                    onclick="serverPower('${escapeHtml(server.id)}','stop')"
                >
                    Stop
                </button>

                <button
                    onclick="renameServer('${escapeHtml(server.id)}')"
                >
                    Rename
                </button>

                <button
                    class="danger-button"
                    onclick="deleteServer('${escapeHtml(server.id)}')"
                >
                    Delete
                </button>

            </div>

        </div>
    `).join("");

    servers.forEach(
        server => loadServerStatus(server.id)
    );
}

/*
============================================================
RESOURCES
============================================================
*/

function renderResourcePage(resources) {

    $("pageRam").textContent =
        `${mbToGB(resources.ram)} GB`;

    $("pageCpu").textContent =
        `${formatNumber(resources.cpu)}%`;

    $("pageDisk").textContent =
        `${mbToGB(resources.disk)} GB`;

    $("pageAllocations").textContent =
        formatNumber(
            resources.allocations
        );

    $("pageDatabases").textContent =
        formatNumber(
            resources.databases
        );

    $("pageBackups").textContent =
        formatNumber(
            resources.backups
        );
}

/*
============================================================
TRANSACTIONS
============================================================
*/

function renderTransactions(
    transactions
) {

    const containers = [
        $("transactions"),
        $("transactionPageList")
    ];

    const html =
        transactions.length
            ? transactions.map(transaction => {

                const amount =
                    Number(
                        transaction.amount ||
                        transaction.coins ||
                        0
                    );

                const positive =
                    amount >= 0;

                return `
                    <div class="transaction">

                        <div class="transaction-icon">
                            ${positive ? "↑" : "↓"}
                        </div>

                        <div class="transaction-info">

                            <strong>
                                ${escapeHtml(
                                    transaction.type ||
                                    transaction.description ||
                                    "Transaction"
                                )}
                            </strong>

                            <span>
                                ${escapeHtml(
                                    transaction.created_at ||
                                    ""
                                )}
                            </span>

                        </div>

                        <div class="
                            transaction-amount
                            ${positive ? "positive" : "negative"}
                        ">
                            ${positive ? "+" : ""}
                            ${formatNumber(amount)}
                        </div>

                    </div>
                `;

            }).join("")
            : `
                <div class="empty-state">
                    No transactions yet.
                </div>
            `;

    containers.forEach(
        container => {
            if (container) {
                container.innerHTML =
                    html;
            }
        }
    );
}

/*
============================================================
PLANS
============================================================
*/

function renderPlans(plans) {

    const container =
        $("plansGrid");

    if (!container) {
        return;
    }

    container.innerHTML =
        plans
            .slice(0, 5)
            .map((plan, index) => `
                <div class="
                    plan-card
                    ${index === 2 ? "featured" : ""}
                ">

                    <h2>
                        ${escapeHtml(plan.name)}
                    </h2>

                    <p>
                        ${escapeHtml(
                            plan.description || ""
                        )}
                    </p>

                    <div class="plan-price">
                        ${formatNumber(plan.price)}
                        <span>coins</span>
                    </div>

                    <div class="plan-resources">

                        <div class="plan-resource">
                            <span>RAM</span>
                            <strong>
                                ${mbToGB(plan.ram)} GB
                            </strong>
                        </div>

                        <div class="plan-resource">
                            <span>CPU</span>
                            <strong>
                                ${formatNumber(plan.cpu)}%
                            </strong>
                        </div>

                        <div class="plan-resource">
                            <span>Disk</span>
                            <strong>
                                ${mbToGB(plan.disk)} GB
                            </strong>
                        </div>

                        <div class="plan-resource">
                            <span>Allocations</span>
                            <strong>
                                ${formatNumber(
                                    plan.allocations
                                )}
                            </strong>
                        </div>

                        <div class="plan-resource">
                            <span>Databases</span>
                            <strong>
                                ${formatNumber(
                                    plan.databases
                                )}
                            </strong>
                        </div>

                        <div class="plan-resource">
                            <span>Backups</span>
                            <strong>
                                ${formatNumber(
                                    plan.backups
                                )}
                            </strong>
                        </div>

                    </div>

                    <button
                        class="primary-button"
                        onclick="buyPlan('${escapeHtml(plan.id)}')"
                        style="width:100%"
                    >
                        Purchase Plan
                    </button>

                </div>
            `)
            .join("");
}

async function buyPlan(planId) {

    if (
        !confirm(
            "Purchase this plan using your coins?"
        )
    ) {
        return;
    }

    try {

        /*
         * The purchase endpoint will be connected
         * to the existing PetroV2 economy service
         * in the next backend phase.
         */

        alert(
            "Plan purchasing will be connected to PetroV2 economy next."
        );

    } catch (error) {

        alert(
            error.message
        );

    }
}

/*
============================================================
NAVIGATION
============================================================
*/

const pages = [
    "dashboard",
    "servers",
    "resources",
    "plans",
    "economy",
    "transactions",
    "settings",
    "admin"
];

function showPage(page) {

    if (!pages.includes(page)) {
        page = "dashboard";
    }

    currentPage = page;

    pages.forEach(
        name => {

            const element =
                $(`${name}Page`);

            if (element) {
                element.classList.toggle(
                    "hidden",
                    name !== page
                );
            }

        }
    );

    document
        .querySelectorAll(".nav-item")
        .forEach(button => {

            button.classList.toggle(
                "active",
                button.dataset.page === page
            );

        });

    const titles = {
        dashboard: "Overview",
        servers: "Servers",
        resources: "Resources",
        plans: "Plans",
        economy: "Economy",
        transactions: "Transactions",
        settings: "Settings",
        admin: "Admin Panel"
    };

    $("pageTitle").textContent =
        titles[page] || "Overview";

    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
}

document
    .querySelectorAll(".nav-item")
    .forEach(button => {

        button.addEventListener(
            "click",
            () => {

                showPage(
                    button.dataset.page
                );

                $("sidebar")
                    .classList.remove("open");

            }
        );

    });

document
    .querySelectorAll("[data-page-button]")
    .forEach(button => {

        button.addEventListener(
            "click",
            () => {
                showPage(
                    button.dataset.pageButton
                );
            }
        );

    });

/*
============================================================
THEMES
============================================================
*/

function loadTheme() {

    const theme =
        localStorage.getItem(
            "petro-theme"
        ) || "mythical";

    document.documentElement
        .dataset.theme =
        theme;

    document
        .querySelectorAll(".theme-option")
        .forEach(button => {

            button.classList.toggle(
                "active",
                button.dataset.theme === theme
            );

        });
}

document
    .querySelectorAll(".theme-option")
    .forEach(button => {

        button.addEventListener(
            "click",
            () => {

                const theme =
                    button.dataset.theme;

                document.documentElement
                    .dataset.theme =
                    theme;

                localStorage.setItem(
                    "petro-theme",
                    theme
                );

                document
                    .querySelectorAll(
                        ".theme-option"
                    )
                    .forEach(option => {

                        option.classList.toggle(
                            "active",
                            option === button
                        );

                    });

            }
        );

    });

/*
============================================================
SIDEBAR
============================================================
*/

$("mobileMenu")
    ?.addEventListener(
        "click",
        () => {

            $("sidebar")
                .classList.toggle("open");

        }
    );

$("compactSidebar")
    ?.addEventListener(
        "change",
        event => {

            document.body.classList.toggle(
                "compact-sidebar",
                event.target.checked
            );

        }
    );

/*
============================================================
ADMIN
============================================================
*/

async function loadAdmin() {

    try {

        const data =
            await api("/api/admin");

        $("adminUsers").textContent =
            formatNumber(data.users);

        $("adminServers").textContent =
            formatNumber(data.servers);

        $("adminTransactions").textContent =
            formatNumber(
                data.transactions
            );

    } catch (error) {

        console.error(
            "[Admin]",
            error
        );

    }
}

/*
============================================================
START
============================================================
*/

async function init() {

    loadTheme();

    try {

        const authenticated =
            await loadAuth();

        if (!authenticated) {
            return;
        }

        await loadDashboard();

        await loadAdmin();

    } catch (error) {

        console.error(
            "[Dashboard Init]",
            error
        );

    }

}

init();

/*
============================================================
End of app.js
Created by HyperForgeX
Copyright © 2026 HyperForgeX. All rights reserved.
============================================================
*/