/*
 * ============================================================
 * PetroBot V2 - Main Application Controller
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */

import {
    Client,
    Collection,
    GatewayIntentBits,
    Partials
} from "discord.js";

import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

import { config } from "./config.js";

import { ensureUser } from "./services/userService.js";
import serverManager from "./services/serverManager.js";

import {
    errorEmbed,
    successEmbed
} from "./utils/embeds.js";

import {
    handleHelpButton
} from "./commands/help.js";

import {
    registerCommands
} from "./registerCommands.js";

/* ============================================================
 * APPLICATION PATHS
 * ============================================================
 */

const __filename =
    fileURLToPath(import.meta.url);

const __dirname =
    path.dirname(__filename);

const commandsPath =
    path.join(
        __dirname,
        "commands"
    );

/* ============================================================
 * APPLICATION CONSTANTS
 * ============================================================
 */

const START_TIME =
    Date.now();

const PREFIX =
    String(
        config.PREFIX || "!"
    );

const COMMAND_TIMEOUT_MS =
    120000;

const MAX_PREFIX_ARGUMENTS =
    50;

const MAX_MESSAGE_LENGTH =
    2000;

const MAX_ERROR_LENGTH =
    1500;

/* ============================================================
 * DISCORD CLIENT
 * ============================================================
 */

const client =
    new Client({
        intents: [
            GatewayIntentBits.Guilds,
            GatewayIntentBits.GuildMessages,
            GatewayIntentBits.MessageContent,
            GatewayIntentBits.DirectMessages
        ],
        partials: [
            Partials.Channel
        ]
    });

/* ============================================================
 * COMMAND COLLECTIONS
 * ============================================================
 */

client.commands =
    new Collection();

client.prefixCommands =
    new Collection();

client.commandFiles =
    new Collection();

/* ============================================================
 * COMMAND STATISTICS
 * ============================================================
 */

client.commandStats = {
    loaded: 0,
    failed: 0,
    prefix: 0,
    slash: 0,
    aliases: 0,
    startedAt: START_TIME
};

/* ============================================================
 * APPLICATION METADATA
 * ============================================================
 */

client.petro = {
    version: "2.0.0",
    creator: "HyperForgeX",
    prefix: PREFIX,
    startedAt: START_TIME
};

/* ============================================================
 * BASIC HELPERS
 * ============================================================
 */

function text(
    value,
    fallback = ""
) {
    if (
        value === undefined ||
        value === null
    ) {
        return fallback;
    }

    return String(value);
}

function cleanText(
    value,
    fallback = ""
) {
    return text(
        value,
        fallback
    ).trim();
}

function truncate(
    value,
    max = 1900
) {
    const input =
        text(value);

    if (
        input.length <= max
    ) {
        return input;
    }

    return (
        input.slice(
            0,
            Math.max(
                0,
                max - 3
            )
        ) +
        "..."
    );
}

function commandName(
    value
) {
    return cleanText(
        value
    ).toLowerCase();
}

function isFunction(
    value
) {
    return (
        typeof value ===
        "function"
    );
}

function isPromiseLike(
    value
) {
    return Boolean(
        value &&
        typeof value.then ===
            "function"
    );
}

/* ============================================================
 * LOGGING
 * ============================================================
 */

function timestamp() {
    return new Date()
        .toISOString();
}

function logInfo(
    message,
    ...args
) {
    console.log(
        `[${timestamp()}] [INFO] ${message}`,
        ...args
    );
}

function logWarn(
    message,
    ...args
) {
    console.warn(
        `[${timestamp()}] [WARN] ${message}`,
        ...args
    );
}

function logError(
    message,
    error = null
) {
    if (error) {
        console.error(
            `[${timestamp()}] [ERROR] ${message}`,
            error
        );
        return;
    }

    console.error(
        `[${timestamp()}] [ERROR] ${message}`
    );
}

function logStartupLine(
    label,
    value
) {
    console.log(
        `│ ${String(label).padEnd(22, " ")} ${text(value, "-")}`
    );
}

/* ============================================================
 * ERROR HELPERS
 * ============================================================
 */

function getErrorMessage(
    error,
    fallback =
        "An unexpected error occurred."
) {
    if (!error) {
        return fallback;
    }

    const value =
        error instanceof Error
            ? error.message
            : error?.message ||
              error;

    return truncate(
        cleanText(
            value,
            fallback
        ),
        MAX_ERROR_LENGTH
    );
}

/* ============================================================
 * DISCORD HELPERS
 * ============================================================
 */

function isAcknowledged(
    interaction
) {
    return Boolean(
        interaction?.deferred ||
        interaction?.replied
    );
}

function getUserId(
    source
) {
    return text(
        source?.user?.id ||
        source?.author?.id ||
        ""
    );
}

function getUsername(
    source
) {
    return text(
        source?.user?.username ||
        source?.author?.username ||
        "User"
    );
}

function getGuildId(
    source
) {
    return text(
        source?.guildId ||
        source?.guild?.id ||
        "DM"
    );
}

/* ============================================================
 * SAFE INTERACTION RESPONSE
 * ============================================================
 */

async function safeInteractionReply(
    interaction,
    payload
) {
    try {
        if (
            !interaction
        ) {
            return false;
        }

        if (
            isAcknowledged(
                interaction
            )
        ) {
            await interaction.editReply(
                payload
            );
        } else {
            await interaction.reply(
                payload
            );
        }

        return true;
    } catch (error) {
        logError(
            "Failed to respond to interaction.",
            error
        );

        return false;
    }
}

async function safeInteractionError(
    interaction,
    error,
    title = "Error"
) {
    return safeInteractionReply(
        interaction,
        {
            embeds: [
                errorEmbed(
                    title,
                    getErrorMessage(
                        error
                    )
                )
            ],
            ephemeral: true
        }
    );
}

async function safeMessageReply(
    message,
    content
) {
    try {
        if (
            !message?.reply
        ) {
            return false;
        }

        await message.reply(
            truncate(
                content,
                MAX_MESSAGE_LENGTH
            )
        );

        return true;
    } catch (error) {
        logError(
            "Failed to reply to prefix command.",
            error
        );

        return false;
    }
}

/* ============================================================
 * COMMAND TIMEOUT
 * ============================================================
 */

async function withTimeout(
    promise,
    label
) {
    let timer;

    const timeout =
        new Promise(
            (_, reject) => {
                timer =
                    setTimeout(
                        () => {
                            reject(
                                new Error(
                                    `${label} timed out after ${Math.floor(COMMAND_TIMEOUT_MS / 1000)} seconds.`
                                )
                            );
                        },
                        COMMAND_TIMEOUT_MS
                    );
            }
        );

    try {
        return await Promise.race([
            promise,
            timeout
        ]);
    } finally {
        clearTimeout(
            timer
        );
    }
}

async function runHandler(
    handler,
    label
) {
    if (
        !isFunction(handler)
    ) {
        throw new Error(
            `${label} handler is unavailable.`
        );
    }

    const result =
        handler();

    if (
        isPromiseLike(result)
    ) {
        return withTimeout(
            result,
            label
        );
    }

    return result;
}

/* ============================================================
 * ENSURE LOCAL USER
 * ============================================================
 */

async function ensureDiscordUser(
    source
) {
    const userId =
        getUserId(source);

    if (!userId) {
        return null;
    }

    const username =
        getUsername(source);

    return ensureUser(
        userId,
        username
    );
}

/* ============================================================
 * PREFIX PARSER
 * ============================================================
 *
 * Examples:
 *
 * !plans
 * !buy plan1
 * !deploy 4096 200 20480 Survival
 * !deploy 4096 200 20480 "My Survival Server"
 * ============================================================
 */

function hasPrefix(
    content
) {
    return cleanText(
        content
    ).startsWith(
        PREFIX
    );
}

function tokenize(
    content
) {
    if (!content) {
        return [];
    }

    return (
        content.match(
            /(?:[^\s"]+|"[^"]*")+/g
        ) || []
    );
}

function normalizeToken(
    token
) {
    const value =
        text(token);

    if (
        value.length >= 2 &&
        value.startsWith("\"") &&
        value.endsWith("\"")
    ) {
        return value.slice(
            1,
            -1
        );
    }

    return value;
}

function parsePrefixCommand(
    content
) {
    const body =
        cleanText(
            content
        ).slice(
            PREFIX.length
        ).trim();

    const tokens =
        tokenize(body)
            .map(
                normalizeToken
            );

    const name =
        commandName(
            tokens.shift()
        );

    return {
        name,
        args: tokens.slice(
            0,
            MAX_PREFIX_ARGUMENTS
        )
    };
}

/* ============================================================
 * COMMAND ENTRY CREATION
 * ============================================================
 */

function getAliases(
    module,
    command
) {
    const aliases =
        module?.aliases ||
        command?.aliases ||
        [];

    if (
        !Array.isArray(
            aliases
        )
    ) {
        return [];
    }

    return aliases
        .map(
            commandName
        )
        .filter(Boolean);
}

function createCommandEntry(
    module,
    file
) {
    const command =
        module?.default ||
        module ||
        {};

    const data =
        module?.data ||
        command?.data ||
        null;

    const name =
        commandName(
            module?.name ||
            command?.name ||
            data?.name ||
            ""
        );

    const execute =
        module?.execute ||
        command?.execute;

    const prefixExecute =
        module?.prefixExecute ||
        command?.prefixExecute ||
        null;

    const aliases =
        getAliases(
            module,
            command
        );

    return {
        ...command,
        ...module,
        name,
        data,
        execute,
        prefixExecute,
        aliases,
        file,
        description:
            module?.description ||
            command?.description ||
            data?.description ||
            ""
    };
}

/* ============================================================
 * COMMAND LOADING
 * ============================================================
 */

function clearCommands() {
    client.commands.clear();
    client.prefixCommands.clear();
    client.commandFiles.clear();

    client.commandStats.loaded = 0;
    client.commandStats.failed = 0;
    client.commandStats.prefix = 0;
    client.commandStats.slash = 0;
    client.commandStats.aliases = 0;
}

function registerCommand(
    collection,
    name,
    command
) {
    const normalized =
        commandName(name);

    if (!normalized) {
        return;
    }

    collection.set(
        normalized,
        command
    );
}

async function loadCommands() {
    clearCommands();

    if (
        !fs.existsSync(
            commandsPath
        )
    ) {
        throw new Error(
            `Commands directory does not exist: ${commandsPath}`
        );
    }

    const files =
        fs.readdirSync(
            commandsPath
        )
            .filter(
                file =>
                    file.endsWith(
                        ".js"
                    )
            )
            .sort(
                (a, b) =>
                    a.localeCompare(
                        b
                    )
            );

    logInfo(
        `Found ${files.length} command files.`
    );

    for (
        const file
        of files
    ) {
        try {
            const module =
                await import(
                    `./commands/${file}`
                );

            const command =
                createCommandEntry(
                    module,
                    file
                );

            if (
                !command.name
            ) {
                client.commandStats.failed++;

                logWarn(
                    `Skipping ${file}: no command name.`
                );

                continue;
            }

            if (
                !isFunction(
                    command.execute
                )
            ) {
                client.commandStats.failed++;

                logWarn(
                    `Skipping ${file}: execute() is missing.`
                );

                continue;
            }

            /*
             * Register the primary command name.
             */
            registerCommand(
                client.commands,
                command.name,
                command
            );

            client.commandFiles.set(
                file,
                command
            );

            /*
             * Register slash command.
             */
            if (
                command.data
            ) {
                client.commandStats.slash++;
            }

            /*
             * Register prefix command.
             *
             * Hybrid commands use prefixExecute().
             *
             * Commands without slash data may use execute()
             * as their prefix handler.
             */
            const hasPrefix =
                isFunction(
                    command.prefixExecute
                ) ||
                !command.data;

            if (
                hasPrefix
            ) {
                registerCommand(
                    client.prefixCommands,
                    command.name,
                    command
                );

                client.commandStats.prefix++;
            }

            /*
             * Register aliases.
             */
            for (
                const alias
                of command.aliases
            ) {
                registerCommand(
                    client.commands,
                    alias,
                    command
                );

                if (
                    hasPrefix
                ) {
                    registerCommand(
                        client.prefixCommands,
                        alias,
                        command
                    );
                }

                client.commandStats.aliases++;
            }

            client.commandStats.loaded++;

            logInfo(
                `Loaded ${command.name} from ${file}.`
            );
        } catch (error) {
            client.commandStats.failed++;

            logError(
                `Failed to load ${file}.`,
                error
            );
        }
    }

    console.log("");
    console.log(
        "╔══════════════════════════════════════════════════════════╗"
    );
    console.log(
        "║                 PETROBOT COMMAND LOADER                 ║"
    );
    console.log(
        "╠══════════════════════════════════════════════════════════╣"
    );

    logStartupLine(
        "Loaded:",
        client.commandStats.loaded
    );

    logStartupLine(
        "Failed:",
        client.commandStats.failed
    );

    logStartupLine(
        "Slash:",
        client.commandStats.slash
    );

    logStartupLine(
        "Prefix:",
        client.commandStats.prefix
    );

    logStartupLine(
        "Aliases:",
        client.commandStats.aliases
    );

    logStartupLine(
        "Command keys:",
        client.commands.size
    );

    console.log(
        "╚══════════════════════════════════════════════════════════╝"
    );

    console.log("");
}

/* ============================================================
 * SLASH COMMAND EXECUTION
 * ============================================================
 */

async function executeSlashCommand(
    interaction
) {
    const name =
        commandName(
            interaction.commandName
        );

    const command =
        client.commands.get(
            name
        );

    if (
        !command
    ) {
        return safeInteractionReply(
            interaction,
            {
                embeds: [
                    errorEmbed(
                        "Command Not Found",
                        `The command \`/${name}\` could not be found.`
                    )
                ],
                ephemeral: true
            }
        );
    }

    if (
        !isFunction(
            command.execute
        )
    ) {
        return safeInteractionReply(
            interaction,
            {
                embeds: [
                    errorEmbed(
                        "Command Unavailable",
                        `The command \`/${name}\` is not available right now.`
                    )
                ],
                ephemeral: true
            }
        );
    }

    logInfo(
        `Slash command /${name} | user=${interaction.user.id} | guild=${getGuildId(interaction)}`
    );

    await ensureDiscordUser(
        interaction
    );

    return runHandler(
        () =>
            command.execute(
                interaction
            ),
        `/${name}`
    );
}

/* ============================================================
 * PREFIX COMMAND EXECUTION
 * ============================================================
 */

async function executePrefixCommand(
    message,
    command,
    args
) {
    const handler =
        isFunction(
            command?.prefixExecute
        )
            ? command.prefixExecute
            : !command?.data &&
              isFunction(
                  command?.execute
              )
                ? command.execute
                : null;

    if (
        !handler
    ) {
        return safeMessageReply(
            message,
            `❌ The command \`${PREFIX}${command?.name || "unknown"}\` does not support prefix execution.`
        );
    }

    logInfo(
        `Prefix command ${PREFIX}${command.name} | user=${message.author.id} | guild=${getGuildId(message)}`
    );

    return runHandler(
        () =>
            handler(
                message,
                args
            ),
        `${PREFIX}${command.name}`
    );
}

/* ============================================================
 * PREFIX MESSAGE HANDLER
 * ============================================================
 */

async function handlePrefixMessage(
    message
) {
    if (
        !message ||
        !message.author ||
        message.author.bot
    ) {
        return;
    }

    if (
        message.content ===
        undefined
    ) {
        return;
    }

    if (
        !hasPrefix(
            message.content
        )
    ) {
        return;
    }

    const parsed =
        parsePrefixCommand(
            message.content
        );

    if (
        !parsed.name
    ) {
        return;
    }

    const command =
        client.prefixCommands.get(
            parsed.name
        );

    /*
     * Unknown commands are silently ignored.
     */
    if (
        !command
    ) {
        return;
    }

    await ensureDiscordUser(
        message
    );

    await executePrefixCommand(
        message,
        command,
        parsed.args
    );
}

/* ============================================================
 * HELP BUTTON ROUTING
 * ============================================================
 */

async function routeHelpComponent(
    interaction
) {
    const customId =
        text(
            interaction.customId
        );

    if (
        !interaction.isButton?.() ||
        !customId.startsWith(
            "help_"
        )
    ) {
        return false;
    }

    await handleHelpButton(
        interaction
    );

    return true;
}

/* ============================================================
 * USER COMPONENT ROUTING
 * ============================================================
 */

async function routeUserComponent(
    interaction
) {
    const customId =
        text(
            interaction.customId
        );

    if (
        !(
            customId.startsWith(
                "user_create_open:"
            ) ||
            customId.startsWith(
                "user_create_cancel:"
            ) ||
            customId ===
                "user_create_modal"
        )
    ) {
        return false;
    }

    const command =
        await import(
            "./commands/user.js"
        );

    if (
        !isFunction(
            command.handleUserComponent
        )
    ) {
        throw new Error(
            "user.js does not export handleUserComponent()."
        );
    }

    await command.handleUserComponent(
        interaction
    );

    return true;
}

/* ============================================================
 * MANAGE COMPONENT ROUTING
 * ============================================================
 */

async function routeManageComponent(
    interaction
) {
    const customId =
        text(
            interaction.customId
        );

    if (
        customId !==
            "manage_server_select" &&
        customId !==
            "server_select"
    ) {
        return false;
    }

    const command =
        await import(
            "./commands/manage.js"
        );

    if (
        !isFunction(
            command.handleManageSelection
        )
    ) {
        throw new Error(
            "manage.js does not export handleManageSelection()."
        );
    }

    await command.handleManageSelection(
        interaction
    );

    return true;
}

/* ============================================================
 * MYSERVER COMPONENT ROUTING
 * ============================================================
 */

async function routeMyServerComponent(
    interaction
) {
    const customId =
        text(
            interaction.customId
        );

    if (
        customId !==
        "myserver_select"
    ) {
        return false;
    }

    const command =
        await import(
            "./commands/myserver.js"
        );

    if (
        !isFunction(
            command.handleServerSelection
        )
    ) {
        throw new Error(
            "myserver.js does not export handleServerSelection()."
        );
    }

    await command.handleServerSelection(
        interaction
    );

    return true;
}

/* ============================================================
 * SERVERS PAGINATION
 * ============================================================
 */

async function routeServersPagination(
    interaction
) {
    const customId =
        text(
            interaction.customId
        );

    if (
        !(
            customId.startsWith(
                "servers_previous:"
            ) ||
            customId.startsWith(
                "servers_next:"
            )
        )
    ) {
        return false;
    }

    const command =
        await import(
            "./commands/servers.js"
        );

    if (
        !isFunction(
            command.handleServersPagination
        )
    ) {
        throw new Error(
            "servers.js does not export handleServersPagination()."
        );
    }

    await command.handleServersPagination(
        interaction
    );

    return true;
}

/* ============================================================
 * DELETE SERVER BUTTON ROUTING
 * ============================================================
 */

async function routeDeleteServerComponent(
    interaction
) {
    const customId =
        text(
            interaction.customId
        );

    if (
        !(
            customId.startsWith(
                "delete_server_confirm:"
            ) ||
            customId.startsWith(
                "delete_server_cancel:"
            )
        )
    ) {
        return false;
    }

    const command =
        await import(
            "./commands/deleteserver.js"
        );

    /*
     * IMPORTANT:
     *
     * The new deleteserver.js exports:
     *
     * handleDeleteServerButton()
     *
     * This matches the V2 command generated for this project.
     */
    if (
        !isFunction(
            command.handleDeleteServerButton
        )
    ) {
        throw new Error(
            "deleteserver.js does not export handleDeleteServerButton()."
        );
    }

    await command.handleDeleteServerButton(
        interaction
    );

    return true;
}

/* ============================================================
 * REINSTALL BUTTON ROUTING
 * ============================================================
 */

async function routeReinstallComponent(
    interaction
) {
    const customId =
        text(
            interaction.customId
        );

    if (
        !(
            customId.startsWith(
                "reinstall_confirm:"
            ) ||
            customId.startsWith(
                "reinstall_cancel:"
            )
        )
    ) {
        return false;
    }

    const command =
        await import(
            "./commands/reinstall.js"
        );

    if (
        isFunction(
            command.handleReinstallConfirmation
        )
    ) {
        await command.handleReinstallConfirmation(
            interaction
        );

        return true;
    }

    /*
     * If the installed reinstall command uses another
     * handler name, do not crash the entire bot.
     */
    logWarn(
        "Reinstall button detected but reinstall.js does not export handleReinstallConfirmation()."
    );

    return false;
}

/* ============================================================
 * SERVER BUTTON ROUTING
 * ============================================================
 *
 * Supported:
 *
 * server_start:<serverId>
 * server_stop:<serverId>
 * server_restart:<serverId>
 * server_info:<serverId>
 * server_rename:<serverId>
 * server_delete:<serverId>
 * server_back:<serverId>
 *
 * These are generated by manage.js / myserver.js.
 * ============================================================
 */

async function routeServerButton(
    interaction
) {
    const customId =
        text(
            interaction.customId
        );

    if (
        !customId.startsWith(
            "server_"
        )
    ) {
        return false;
    }

    const parts =
        customId.split(
            ":"
        );

    const action =
        parts[0] || "";

    const serverId =
        parts[1] || "";

    /*
     * Back button.
     */
    if (
        action ===
        "server_back"
    ) {
        await interaction.update({
            content:
                `Use \`${PREFIX}manage\` to select a server.`,
            embeds: [],
            components: []
        });

        return true;
    }

    /*
     * Rename button.
     *
     * The actual rename command is handled through
     * !rename / /rename.
     */
    if (
        action ===
        "server_rename"
    ) {
        await interaction.reply({
            embeds: [
                successEmbed(
                    "Rename Server",
                    `Use \`${PREFIX}rename ${serverId} <new name>\` to rename this server.`
                )
            ],
            ephemeral: true
        });

        return true;
    }

    if (
        !serverId
    ) {
        throw new Error(
            "The server button is missing a server ID."
        );
    }

    /*
     * Ownership check.
     */
    const server =
        serverManager.requireServerOwner(
            interaction.user.id,
            serverId
        );

    /*
     * Start.
     */
    if (
        action ===
        "server_start"
    ) {
        await serverManager.startServer(
            server
        );

        await interaction.update({
            embeds: [
                successEmbed(
                    "Server Started",
                    `**${server.name}** has been started successfully.`
                )
            ],
            components: []
        });

        return true;
    }

    /*
     * Stop.
     */
    if (
        action ===
        "server_stop"
    ) {
        await serverManager.stopServer(
            server
        );

        await interaction.update({
            embeds: [
                successEmbed(
                    "Server Stopped",
                    `**${server.name}** has been stopped successfully.`
                )
            ],
            components: []
        });

        return true;
    }

    /*
     * Restart.
     */
    if (
        action ===
        "server_restart"
    ) {
        await serverManager.restartServer(
            server
        );

        await interaction.update({
            embeds: [
                successEmbed(
                    "Server Restarted",
                    `**${server.name}** has been restarted successfully.`
                )
            ],
            components: []
        });

        return true;
    }

    /*
     * Information.
     */
    if (
        action ===
        "server_info"
    ) {
        const info =
            await serverManager.getServerInfo(
                server
            );

        const description =
            [
                `**Name:** ${info?.name || server.name || "Unknown"}`,
                `**Server ID:** \`${server.id}\``,
                `**Pterodactyl ID:** \`${server.pterodactyl_id || "Unknown"}\``,
                `**Identifier:** \`${server.identifier || "Unknown"}\``,
                `**Node:** \`${server.node_id || server.nodeId || "Unknown"}\``,
                `**Status:** \`${server.status || "Unknown"}\``
            ].join("\n");

        await interaction.update({
            embeds: [
                successEmbed(
                    "Server Information",
                    description
                )
            ],
            components: []
        });

        return true;
    }

    /*
     * Delete button.
     *
     * Redirect to the normal deletion command rather than
     * silently deleting a server.
     */
    if (
        action ===
        "server_delete"
    ) {
        await interaction.reply({
            embeds: [
                errorEmbed(
                    "Server Deletion",
                    `For safety, use \`${PREFIX}deleteserver ${server.id}\` to delete this server.`
                )
            ],
            ephemeral: true
        });

        return true;
    }

    /*
     * Unknown server button.
     */
    return false;
}

/* ============================================================
 * NAVIGATION BUTTONS
 * ============================================================
 */

async function routeNavigationButton(
    interaction
) {
    const customId =
        text(
            interaction.customId
        );

    if (
        customId ===
            "menu_help" ||
        customId ===
            "menu_home"
    ) {
        await handleHelpButton(
            interaction
        );

        return true;
    }

    if (
        customId ===
        "menu_servers"
    ) {
        await interaction.reply({
            content:
                `Use \`${PREFIX}servers\` to view your servers.`,
            ephemeral: true
        });

        return true;
    }

    if (
        customId ===
        "menu_economy"
    ) {
        await interaction.reply({
            content:
                `Use \`${PREFIX}coins\` or \`${PREFIX}balance\` to view your coin balance.`,
            ephemeral: true
        });

        return true;
    }

    if (
        customId ===
        "menu_redeem"
    ) {
        await interaction.reply({
            content:
                `Use \`${PREFIX}redeem <code>\` to redeem a code.`,
            ephemeral: true
        });

        return true;
    }

    if (
        customId ===
        "menu_deploy"
    ) {
        await interaction.reply({
            content:
                `Use \`${PREFIX}deploy <RAM_MB> <CPU_%> <DISK_MB> [server name]\` to deploy a server.`,
            ephemeral: true
        });

        return true;
    }

    return false;
}

/* ============================================================
 * CENTRAL COMPONENT ROUTER
 * ============================================================
 */

async function routeComponent(
    interaction
) {
    const customId =
        text(
            interaction.customId
        );

    /*
     * User account components.
     */
    if (
        await routeUserComponent(
            interaction
        )
    ) {
        return true;
    }

    /*
     * Help.
     */
    if (
        await routeHelpComponent(
            interaction
        )
    ) {
        return true;
    }

    /*
     * Manage server selection.
     */
    if (
        await routeManageComponent(
            interaction
        )
    ) {
        return true;
    }

    /*
     * My server selection.
     */
    if (
        await routeMyServerComponent(
            interaction
        )
    ) {
        return true;
    }

    /*
     * Servers pagination.
     */
    if (
        await routeServersPagination(
            interaction
        )
    ) {
        return true;
    }

    /*
     * Delete confirmation.
     */
    if (
        await routeDeleteServerComponent(
            interaction
        )
    ) {
        return true;
    }

    /*
     * Reinstall confirmation.
     */
    if (
        await routeReinstallComponent(
            interaction
        )
    ) {
        return true;
    }

    /*
     * Server control buttons.
     */
    if (
        await routeServerButton(
            interaction
        )
    ) {
        return true;
    }

    /*
     * General navigation.
     */
    if (
        await routeNavigationButton(
            interaction
        )
    ) {
        return true;
    }

    logWarn(
        `Unhandled component: ${customId}`
    );

    return false;
}

/* ============================================================
 * INTERACTION HANDLER
 * ============================================================
 */

async function handleInteraction(
    interaction
) {
    if (
        !interaction
    ) {
        return;
    }

    /*
     * Buttons.
     */
    if (
        interaction.isButton?.()
    ) {
        const handled =
            await routeComponent(
                interaction
            );

        if (
            handled
        ) {
            return;
        }
    }

    /*
     * Select menus.
     */
    if (
        interaction.isStringSelectMenu?.()
    ) {
        const handled =
            await routeComponent(
                interaction
            );

        if (
            handled
        ) {
            return;
        }
    }

    /*
     * Modals.
     */
    if (
        interaction.isModalSubmit?.()
    ) {
        const handled =
            await routeComponent(
                interaction
            );

        if (
            handled
        ) {
            return;
        }
    }

    /*
     * Slash commands.
     */
    if (
        interaction.isChatInputCommand?.()
    ) {
        await executeSlashCommand(
            interaction
        );
    }
}

/* ============================================================
 * PROCESS ERROR HANDLING
 * ============================================================
 */

let shuttingDown =
    false;

async function shutdown(
    reason
) {
    if (
        shuttingDown
    ) {
        return;
    }

    shuttingDown =
        true;

    logInfo(
        `Shutdown requested: ${reason}`
    );

    try {
        if (
            client.isReady()
        ) {
            client.destroy();
        }
    } catch (error) {
        logError(
            "Failed to destroy Discord client.",
            error
        );
    }

    logInfo(
        "PetroBot V2 shutdown complete."
    );
}

function registerProcessHandlers() {
    process.on(
        "unhandledRejection",
        error => {
            logError(
                "Unhandled promise rejection.",
                error
            );
        }
    );

    process.on(
        "uncaughtException",
        error => {
            logError(
                "Uncaught exception.",
                error
            );
        }
    );

    process.on(
        "SIGINT",
        async () => {
            await shutdown(
                "SIGINT"
            );

            process.exit(
                0
            );
        }
    );

    process.on(
        "SIGTERM",
        async () => {
            await shutdown(
                "SIGTERM"
            );

            process.exit(
                0
            );
        }
    );
}

/* ============================================================
 * DISCORD EVENTS
 * ============================================================
 */

function registerDiscordEvents() {
    /*
     * --------------------------------------------------------
     * READY
     * --------------------------------------------------------
     */

    client.once(
        "ready",
        () => {
            console.log("");
            console.log(
                "╔══════════════════════════════════════════════════════════╗"
            );
            console.log(
                "║                    PETROBOT V2 ONLINE                   ║"
            );
            console.log(
                "╠══════════════════════════════════════════════════════════╣"
            );

            logStartupLine(
                "Bot:",
                client.user?.tag ||
                    client.user?.username ||
                    "Unknown"
            );

            logStartupLine(
                "Discord ID:",
                client.user?.id ||
                    "Unknown"
            );

            logStartupLine(
                "Guilds:",
                client.guilds.cache.size
            );

            logStartupLine(
                "Commands:",
                client.commands.size
            );

            logStartupLine(
                "Prefix:",
                PREFIX
            );

            logStartupLine(
                "Node.js:",
                process.version
            );

            logStartupLine(
                "Creator:",
                "HyperForgeX"
            );

            console.log(
                "╚══════════════════════════════════════════════════════════╝"
            );

            console.log("");

            logInfo(
                `PetroBot V2 is ready as ${client.user.tag}.`
            );
        }
    );

    /*
     * --------------------------------------------------------
     * MESSAGE CREATE
     * --------------------------------------------------------
     */

    client.on(
        "messageCreate",
        async message => {
            try {
                await handlePrefixMessage(
                    message
                );
            } catch (error) {
                logError(
                    "Prefix command failed.",
                    error
                );

                await safeMessageReply(
                    message,
                    `❌ **PetroBot Error**\n${getErrorMessage(error)}`
                );
            }
        }
    );

    /*
     * --------------------------------------------------------
     * INTERACTION CREATE
     * --------------------------------------------------------
     */

    client.on(
        "interactionCreate",
        async interaction => {
            try {
                await handleInteraction(
                    interaction
                );
            } catch (error) {
                logError(
                    "Interaction failed.",
                    error
                );

                await safeInteractionError(
                    interaction,
                    error,
                    "PetroBot Error"
                );
            }
        }
    );

    /*
     * --------------------------------------------------------
     * DISCORD ERROR
     * --------------------------------------------------------
     */

    client.on(
        "error",
        error => {
            logError(
                "Discord client error.",
                error
            );
        }
    );

    /*
     * --------------------------------------------------------
     * DISCORD WARNING
     * --------------------------------------------------------
     */

    client.on(
        "warn",
        warning => {
            logWarn(
                `Discord warning: ${warning}`
            );
        }
    );

    /*
     * --------------------------------------------------------
     * SHARD ERROR
     * --------------------------------------------------------
     */

    client.on(
        "shardError",
        error => {
            logError(
                "Discord shard error.",
                error
            );
        }
    );
}

/* ============================================================
 * CONFIGURATION VALIDATION
 * ============================================================
 */

async function validateConfiguration() {
    const warnings =
        [];

    if (
        !config.DISCORD_TOKEN
    ) {
        warnings.push(
            "DISCORD_TOKEN is missing."
        );
    }

    if (
        !config.DISCORD_CLIENT_ID
    ) {
        warnings.push(
            "DISCORD_CLIENT_ID is missing."
        );
    }

    if (
        !config.PTERODACTYL_URL
    ) {
        warnings.push(
            "PTERODACTYL_URL is missing."
        );
    }

    if (
        !config.PTERODACTYL_API_KEY
    ) {
        warnings.push(
            "PTERODACTYL_API_KEY is missing."
        );
    }

    for (
        const warning
        of warnings
    ) {
        logWarn(
            warning
        );
    }

    /*
     * The Discord token is the only value that prevents the
     * Discord client from starting entirely.
     */
    if (
        !config.DISCORD_TOKEN
    ) {
        throw new Error(
            "DISCORD_TOKEN is required."
        );
    }
}

/* ============================================================
 * DASHBOARD
 * ============================================================
 */

async function startDashboard() {
    if (
        !config.DASHBOARD_ENABLED
    ) {
        logInfo(
            "Dashboard is disabled."
        );

        return null;
    }

    const dashboardPath =
        path.join(
            __dirname,
            "dashboard",
            "server.js"
        );

    if (
        !fs.existsSync(
            dashboardPath
        )
    ) {
        logWarn(
            "Dashboard is enabled but dashboard/server.js was not found."
        );

        return null;
    }

    try {
        const dashboard =
            await import(
                "./dashboard/server.js"
            );

        if (
            isFunction(
                dashboard.startDashboard
            )
        ) {
            const result =
                await dashboard.startDashboard();

            logInfo(
                "Dashboard started."
            );

            return result;
        }

        if (
            isFunction(
                dashboard.start
            )
        ) {
            const result =
                await dashboard.start();

            logInfo(
                "Dashboard started."
            );

            return result;
        }

        logWarn(
            "Dashboard module has no supported start function."
        );

        return null;
    } catch (error) {
        /*
         * Dashboard failure should not stop the Discord bot.
         */
        logError(
            "Dashboard failed to start.",
            error
        );

        return null;
    }
}

/* ============================================================
 * COMMAND REGISTRATION
 * ============================================================
 */

async function registerDiscordCommands() {
    logInfo(
        "Registering slash commands with Discord..."
    );

    try {
        const registered =
            await registerCommands({
                token:
                    config.DISCORD_TOKEN,
                clientId:
                    config.DISCORD_CLIENT_ID,
                guildId:
                    config.DISCORD_GUILD_ID ||
                    config.GUILD_ID ||
                    null
            });

        logInfo(
            `Successfully registered ${registered.length} slash commands.`
        );

        return registered;
    } catch (error) {
        logError(
            "Slash command registration failed.",
            error
        );

        /*
         * Do not prevent the bot from starting if Discord
         * registration temporarily fails. Prefix commands can
         * still operate.
         */
        return [];
    }
}

/* ============================================================
 * STARTUP BANNER
 * ============================================================
 */

function printStartupBanner() {
    console.log("");
    console.log(
        "╔══════════════════════════════════════════════════════════╗"
    );
    console.log(
        "║                       PETROBOT V2                       ║"
    );
    console.log(
        "╠══════════════════════════════════════════════════════════╣"
    );

    logStartupLine(
        "Creator:",
        "HyperForgeX"
    );

    logStartupLine(
        "Version:",
        client.petro.version
    );

    logStartupLine(
        "Node.js:",
        process.version
    );

    logStartupLine(
        "Prefix:",
        PREFIX
    );

    logStartupLine(
        "Pterodactyl:",
        config.PTERODACTYL_URL ||
            "Not configured"
    );

    logStartupLine(
        "Dashboard:",
        config.DASHBOARD_ENABLED
            ? "Enabled"
            : "Disabled"
    );

    logStartupLine(
        "PID:",
        process.pid
    );

    console.log(
        "╚══════════════════════════════════════════════════════════╝"
    );

    console.log("");
}

/* ============================================================
 * STARTUP
 * ============================================================
 *
 * Order:
 *
 * 1. Validate configuration
 * 2. Register process handlers
 * 3. Register Discord events
 * 4. Load command modules
 * 5. Register slash commands
 * 6. Start dashboard
 * 7. Login to Discord
 *
 * This ensures every command/component handler exists before
 * Discord starts delivering interactions to the bot.
 * ============================================================
 */

async function bootstrap() {
    printStartupBanner();

    await validateConfiguration();

    registerProcessHandlers();

    registerDiscordEvents();

    await loadCommands();

    await registerDiscordCommands();

    await startDashboard();

    logInfo(
        "Connecting to Discord..."
    );

    await client.login(
        config.DISCORD_TOKEN
    );
}

/* ============================================================
 * START APPLICATION
 * ============================================================
 */

try {
    await bootstrap();
} catch (error) {
    logError(
        "PetroBot V2 failed to start.",
        error
    );

    process.exit(
        1
    );
}

/*
 * ============================================================
 * End of index.js
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */