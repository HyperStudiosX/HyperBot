/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * PetroBot V2 - Discord Command Registration
 * ============================================================
 */

import {
    REST,
    Routes
} from "discord.js";

import config from "./config.js";

/* ============================================================
 * COMMAND IMPORTS
 * ============================================================
 */

import balance from "./commands/balance.js";
import buy from "./commands/buy.js";
import coins from "./commands/coins.js";
import createcode from "./commands/createcode.js";
import deleteserver from "./commands/deleteserver.js";
import deploy from "./commands/deploy.js";
import givecoins from "./commands/givecoins.js";
import help from "./commands/help.js";
import kill from "./commands/kill.js";
import manage from "./commands/manage.js";
import myserver from "./commands/myserver.js";
import plans from "./commands/plans.js";
import power from "./commands/power.js";
import profile from "./commands/profile.js";
import redeem from "./commands/redeem.js";
import reinstall from "./commands/reinstall.js";
import rename from "./commands/rename.js";
import resources from "./commands/resources.js";
import restart from "./commands/restart.js";
import servers from "./commands/servers.js";
import serverinfo from "./commands/serverinfo.js";
import start from "./commands/start.js";
import status from "./commands/status.js";
import stop from "./commands/stop.js";
import suspend from "./commands/suspend.js";
import transfer from "./commands/transfer.js";
import unsuspend from "./commands/unsuspend.js";
import user from "./commands/user.js";
import utility from "./commands/utility.js";

/* ============================================================
 * COMMAND COLLECTION
 * ============================================================
 *
 * Keep this list centralized so index.js does not have to
 * know about every slash command individually.
 * ============================================================
 */

const commands = [
    balance,
    buy,
    coins,
    createcode,
    deleteserver,
    deploy,
    givecoins,
    help,
    kill,
    manage,
    myserver,
    plans,
    power,
    profile,
    redeem,
    reinstall,
    rename,
    resources,
    restart,
    servers,
    serverinfo,
    start,
    status,
    stop,
    suspend,
    transfer,
    unsuspend,
    user,
    utility
];

/* ============================================================
 * BUILD COMMAND DATA
 * ============================================================
 */

function getCommandData(command) {
    if (!command) {
        return null;
    }

    if (command.data) {
        if (
            typeof command.data.toJSON ===
            "function"
        ) {
            return command.data.toJSON();
        }

        return command.data;
    }

    return null;
}

/* ============================================================
 * VALIDATE COMMANDS
 * ============================================================
 */

function validateCommands() {
    const validCommands = [];
    const names = new Set();

    for (const command of commands) {
        const data =
            getCommandData(command);

        if (!data) {
            console.warn(
                "[Commands] Skipping command without slash command data:",
                command?.name || "unknown"
            );

            continue;
        }

        if (!data.name) {
            console.warn(
                "[Commands] Skipping command without a name."
            );

            continue;
        }

        const name =
            String(data.name)
                .trim()
                .toLowerCase();

        if (names.has(name)) {
            console.warn(
                `[Commands] Duplicate slash command "${name}" detected.`
            );

            continue;
        }

        names.add(name);
        validCommands.push(data);
    }

    return validCommands;
}

/* ============================================================
 * GET DISCORD CONFIG
 * ============================================================
 */

function getConfigValue(
    ...keys
) {
    for (const key of keys) {
        if (
            config &&
            config[key] !== undefined &&
            config[key] !== null &&
            String(config[key]).trim()
        ) {
            return config[key];
        }
    }

    return null;
}

function getToken() {
    return (
        process.env.DISCORD_TOKEN ||
        process.env.BOT_TOKEN ||
        getConfigValue(
            "discordToken",
            "token",
            "botToken"
        )
    );
}

function getClientId() {
    return (
        process.env.DISCORD_CLIENT_ID ||
        process.env.CLIENT_ID ||
        getConfigValue(
            "clientId",
            "discordClientId",
            "applicationId"
        )
    );
}

function getGuildId() {
    return (
        process.env.DISCORD_GUILD_ID ||
        process.env.GUILD_ID ||
        getConfigValue(
            "guildId",
            "discordGuildId"
        )
    );
}

/* ============================================================
 * REGISTER COMMANDS
 * ============================================================
 *
 * If DISCORD_GUILD_ID is configured, commands are registered
 * to that guild for fast development updates.
 *
 * If no guild ID is configured, commands are registered
 * globally.
 * ============================================================
 */

export async function registerCommands(options = {}) {
    const token =
        options.token ||
        getToken();

    const clientId =
        options.clientId ||
        getClientId();

    const guildId =
        options.guildId ||
        getGuildId();

    if (!token) {
        throw new Error(
            "Discord bot token is missing. Set DISCORD_TOKEN in your environment."
        );
    }

    if (!clientId) {
        throw new Error(
            "Discord client ID is missing. Set DISCORD_CLIENT_ID in your environment."
        );
    }

    const commandData =
        validateCommands();

    if (!commandData.length) {
        throw new Error(
            "No valid slash commands were found to register."
        );
    }

    const rest =
        new REST({
            version: "10"
        }).setToken(token);

    const route =
        guildId
            ? Routes.applicationGuildCommands(
                clientId,
                guildId
            )
            : Routes.applicationCommands(
                clientId
            );

    console.log("");
    console.log(
        "========================================"
    );
    console.log(
        "[Commands] Registering Discord slash commands"
    );
    console.log(
        "========================================"
    );

    console.log(
        `[Commands] Count: ${commandData.length}`
    );

    if (guildId) {
        console.log(
            `[Commands] Scope: Guild (${guildId})`
        );
    } else {
        console.log(
            "[Commands] Scope: Global"
        );
    }

    try {
        const registered =
            await rest.put(
                route,
                {
                    body: commandData
                }
            );

        console.log(
            `[Commands] Successfully registered ${registered.length} slash commands.`
        );

        for (
            const command of registered
        ) {
            console.log(
                `[Commands] /${command.name}`
            );
        }

        console.log(
            "========================================"
        );
        console.log("");

        return registered;
    } catch (error) {
        console.error(
            "[Commands] Failed to register slash commands:",
            error
        );

        throw error;
    }
}

/* ============================================================
 * GET COMMANDS
 * ============================================================
 */

export function getCommands() {
    return [
        ...commands
    ];
}

export function getCommand(
    name
) {
    const target =
        String(name ?? "")
            .trim()
            .toLowerCase();

    if (!target) {
        return null;
    }

    return (
        commands.find(command => {
            const commandName =
                String(
                    command?.name ||
                    command?.data?.name ||
                    ""
                )
                    .trim()
                    .toLowerCase();

            if (
                commandName === target
            ) {
                return true;
            }

            const aliases =
                Array.isArray(
                    command?.aliases
                )
                    ? command.aliases
                    : [];

            return aliases.some(
                alias =>
                    String(alias)
                        .trim()
                        .toLowerCase() ===
                    target
            );
        }) || null
    );
}

/* ============================================================
 * AUTO REGISTER
 * ============================================================
 *
 * registerCommands.js can also be executed directly by the
 * package script if desired.
 *
 * The normal bot startup should call registerCommands()
 * explicitly from index.js.
 * ============================================================
 */

export default registerCommands;

/*
 * ============================================================
 * End of registerCommands.js
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * PetroBot V2 - Discord Command Registration
 * ============================================================
 */