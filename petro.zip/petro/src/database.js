/*
 * ============================================================
 * PetroBot V2 - Database Layer
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 *
 * This file is the central persistent-data layer for PetroBot V2.
 *
 * Responsibilities:
 * - Discord account storage
 * - Pterodactyl account linking
 * - Coin economy
 * - Resource balances
 * - Server records
 * - Deployment attempt tracking
 * - Redeem codes
 * - Redeem history
 * - Transactions
 * - Plan purchases
 * - Resource transaction history
 * - Administrative audit records
 * - Database migrations and maintenance
 *
 * Storage engine: SQLite through Node.js node:sqlite DatabaseSync.
 *
 * Resource units:
 * - RAM: MB
 * - CPU: percentage points
 * - Disk: MB
 * - Backups: count
 * - Allocations: count
 * - Databases: count
 * - Server slots: count
 *
 * The module intentionally exports both named functions and a
 * default database object so existing PetroBot V2 services can
 * continue using either import style.
 * ============================================================
 */

import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { DatabaseSync } from "node:sqlite";
import { config } from "./config.js";

/* ============================================================
 * DATABASE CONFIGURATION
 * ============================================================ */

const dataDirectory = path.resolve(
    config.dataDirectory || "./data"
);

fs.mkdirSync(dataDirectory, { recursive: true });

const databasePath = path.join(
    dataDirectory,
    "database.sqlite"
);

const db = new DatabaseSync(databasePath);

const DATABASE_VERSION = 2;

const MAX_USERNAME_LENGTH = 100;
const MAX_SERVER_NAME_LENGTH = 191;
const MAX_DESCRIPTION_LENGTH = 1000;
const MAX_TRANSACTION_DESCRIPTION_LENGTH = 1000;
const MAX_AUDIT_DETAILS_LENGTH = 4000;
const MAX_ERROR_LENGTH = 4000;

const DEFAULT_TRANSACTION_LIMIT = 20;
const MAX_TRANSACTION_LIMIT = 500;

const RESOURCE_FIELDS = [
    "ram",
    "cpu",
    "disk",
    "backups",
    "allocations",
    "databases",
    "server_slots"
];

const RESOURCE_ALIASES = {
    ram: [
        "ram",
        "ramMb",
        "ram_mb"
    ],
    cpu: [
        "cpu",
        "cpuPercent",
        "cpu_percent"
    ],
    disk: [
        "disk",
        "diskMb",
        "disk_mb"
    ],
    backups: [
        "backups",
        "backup"
    ],
    allocations: [
        "allocations",
        "allocation"
    ],
    databases: [
        "databases",
        "database"
    ],
    server_slots: [
        "server_slots",
        "serverSlots",
        "servers",
        "slots"
    ]
};

/* ============================================================
 * SQLITE PRAGMAS
 * ============================================================ */

db.exec(`
    PRAGMA journal_mode = WAL;
    PRAGMA foreign_keys = ON;
    PRAGMA synchronous = NORMAL;
    PRAGMA busy_timeout = 5000;
    PRAGMA temp_store = MEMORY;
`);

/* ============================================================
 * GENERAL HELPERS
 * ============================================================ */

function nowIso() {
    return new Date().toISOString();
}

function safeString(value, fallback = "") {
    if (value === null || value === undefined) {
        return fallback;
    }

    return String(value);
}

function safeNumber(value, fallback = 0) {
    const number = Number(value);

    if (!Number.isFinite(number)) {
        return fallback;
    }

    return number;
}

function safeInteger(value, fallback = 0) {
    const number = Number(value);

    if (!Number.isFinite(number)) {
        return fallback;
    }

    return Math.trunc(number);
}

function positiveInteger(value, fallback = 0) {
    const number = safeInteger(value, fallback);

    return number < 0 ? fallback : number;
}

function normalizeDiscordId(value) {
    return safeString(value).trim();
}

function normalizeEmail(value) {
    return safeString(value)
        .trim()
        .toLowerCase();
}

function normalizeUsername(value) {
    return safeString(value)
        .trim()
        .slice(0, MAX_USERNAME_LENGTH);
}

function normalizeServerName(value) {
    return safeString(value)
        .trim()
        .slice(0, MAX_SERVER_NAME_LENGTH);
}

function normalizeDescription(value) {
    return safeString(value)
        .trim()
        .slice(0, MAX_DESCRIPTION_LENGTH);
}

function normalizeTransactionDescription(value) {
    return safeString(value)
        .trim()
        .slice(0, MAX_TRANSACTION_DESCRIPTION_LENGTH);
}

function normalizeError(value) {
    return safeString(value)
        .trim()
        .slice(0, MAX_ERROR_LENGTH);
}

function normalizeAuditDetails(value) {
    return safeString(value)
        .trim()
        .slice(0, MAX_AUDIT_DETAILS_LENGTH);
}

function jsonStringify(value, fallback = "{}") {
    try {
        return JSON.stringify(value);
    } catch {
        return fallback;
    }
}

function jsonParse(value, fallback = null) {
    if (value === null || value === undefined || value === "") {
        return fallback;
    }

    try {
        return JSON.parse(value);
    } catch {
        return fallback;
    }
}

function randomCode(length = 16) {
    return crypto
        .randomBytes(Math.ceil(length / 2))
        .toString("hex")
        .slice(0, length)
        .toUpperCase();
}

function createId(prefix = "") {
    const value = crypto
        .randomBytes(16)
        .toString("hex");

    return `${prefix}${value}`;
}

function clampLimit(value) {
    const number = positiveInteger(
        value,
        DEFAULT_TRANSACTION_LIMIT
    );

    return Math.min(
        number || DEFAULT_TRANSACTION_LIMIT,
        MAX_TRANSACTION_LIMIT
    );
}

function normalizeResourceObject(resources = {}) {
    const result = {};

    for (const field of RESOURCE_FIELDS) {
        let found = undefined;

        for (const alias of RESOURCE_ALIASES[field]) {
            if (
                resources &&
                resources[alias] !== undefined &&
                resources[alias] !== null
            ) {
                found = resources[alias];
                break;
            }
        }

        result[field] = positiveInteger(
            found,
            0
        );
    }

    return result;
}

function addResourceObjects(a = {}, b = {}) {
    const left = normalizeResourceObject(a);
    const right = normalizeResourceObject(b);

    const result = {};

    for (const field of RESOURCE_FIELDS) {
        result[field] =
            left[field] +
            right[field];
    }

    return result;
}

function subtractResourceObjects(a = {}, b = {}) {
    const left = normalizeResourceObject(a);
    const right = normalizeResourceObject(b);

    const result = {};

    for (const field of RESOURCE_FIELDS) {
        result[field] =
            left[field] -
            right[field];
    }

    return result;
}

function resourceObjectHasNegativeValue(resources = {}) {
    for (const field of RESOURCE_FIELDS) {
        for (const alias of RESOURCE_ALIASES[field]) {
            if (
                resources &&
                resources[alias] !== undefined &&
                resources[alias] !== null
            ) {
                const value = Number(resources[alias]);

                if (
                    Number.isFinite(value) &&
                    value < 0
                ) {
                    return true;
                }
            }
        }
    }

    return false;
}

function resourcesAreSufficient(
    available = {},
    required = {}
) {
    const current =
        normalizeResourceObject(available);

    const wanted =
        normalizeResourceObject(required);

    return RESOURCE_FIELDS.every(
        field =>
            current[field] >= wanted[field]
    );
}

function getMissingResources(
    available = {},
    required = {}
) {
    const current =
        normalizeResourceObject(available);

    const wanted =
        normalizeResourceObject(required);

    const missing = {};

    for (const field of RESOURCE_FIELDS) {
        missing[field] = Math.max(
            0,
            wanted[field] - current[field]
        );
    }

    return missing;
}

function withTransaction(callback) {
    db.exec("BEGIN IMMEDIATE");

    try {
        const result = callback();

        db.exec("COMMIT");

        return result;
    } catch (error) {
        try {
            db.exec("ROLLBACK");
        } catch {
            // Ignore rollback errors.
        }

        throw error;
    }
}

function tableExists(tableName) {
    const row = db
        .prepare(`
            SELECT name
            FROM sqlite_master
            WHERE type = 'table'
            AND name = ?
            LIMIT 1
        `)
        .get(tableName);

    return Boolean(row);
}

function columnExists(
    tableName,
    columnName
) {
    if (!tableExists(tableName)) {
        return false;
    }

    const columns = db
        .prepare(
            `PRAGMA table_info(${tableName})`
        )
        .all();

    return columns.some(
        column =>
            column.name === columnName
    );
}

function addColumnIfMissing(
    tableName,
    columnName,
    definition
) {
    if (columnExists(
        tableName,
        columnName
    )) {
        return;
    }

    db.exec(`
        ALTER TABLE ${tableName}
        ADD COLUMN ${columnName}
        ${definition}
    `);
}

/* ============================================================
 * INITIAL SCHEMA
 * ============================================================ */

db.exec(`
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        discord_id TEXT NOT NULL UNIQUE,
        username TEXT,
        email TEXT,
        pterodactyl_user_id INTEGER,
        pterodactyl_username TEXT,
        pterodactyl_email TEXT,
        first_name TEXT,
        last_name TEXT,
        root_admin INTEGER NOT NULL DEFAULT 0,
        active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        last_seen_at TEXT,
        metadata TEXT NOT NULL DEFAULT '{}'
    );

    CREATE TABLE IF NOT EXISTS coins (
        user_id INTEGER PRIMARY KEY,
        balance INTEGER NOT NULL DEFAULT 0,
        lifetime_earned INTEGER NOT NULL DEFAULT 0,
        lifetime_spent INTEGER NOT NULL DEFAULT 0,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id)
            REFERENCES users(id)
            ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS user_resources (
        user_id INTEGER PRIMARY KEY,
        ram INTEGER NOT NULL DEFAULT 0,
        cpu INTEGER NOT NULL DEFAULT 0,
        disk INTEGER NOT NULL DEFAULT 0,
        backups INTEGER NOT NULL DEFAULT 0,
        allocations INTEGER NOT NULL DEFAULT 0,
        databases INTEGER NOT NULL DEFAULT 0,
        server_slots INTEGER NOT NULL DEFAULT 0,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id)
            REFERENCES users(id)
            ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS servers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        discord_user_id TEXT NOT NULL,
        pterodactyl_server_id INTEGER,
        pterodactyl_identifier TEXT,
        pterodactyl_uuid TEXT,
        name TEXT NOT NULL,
        description TEXT,
        node_id INTEGER,
        node_name TEXT,
        allocation_id INTEGER,
        allocation_ip TEXT,
        allocation_port INTEGER,
        ram INTEGER NOT NULL DEFAULT 0,
        cpu INTEGER NOT NULL DEFAULT 0,
        disk INTEGER NOT NULL DEFAULT 0,
        backups INTEGER NOT NULL DEFAULT 0,
        databases INTEGER NOT NULL DEFAULT 0,
        allocations INTEGER NOT NULL DEFAULT 0,
        status TEXT DEFAULT 'unknown',
        plan_id INTEGER,
        plan_name TEXT,
        active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        metadata TEXT NOT NULL DEFAULT '{}'
    );

    CREATE TABLE IF NOT EXISTS transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        discord_user_id TEXT,
        type TEXT NOT NULL,
        amount INTEGER NOT NULL DEFAULT 0,
        balance_before INTEGER,
        balance_after INTEGER,
        description TEXT,
        reference_id TEXT,
        metadata TEXT NOT NULL DEFAULT '{}',
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id)
            REFERENCES users(id)
            ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS deployment_attempts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        discord_user_id TEXT NOT NULL,
        user_id INTEGER,
        requested_ram INTEGER NOT NULL DEFAULT 0,
        requested_cpu INTEGER NOT NULL DEFAULT 0,
        requested_disk INTEGER NOT NULL DEFAULT 0,
        requested_backups INTEGER NOT NULL DEFAULT 0,
        requested_databases INTEGER NOT NULL DEFAULT 0,
        requested_allocations INTEGER NOT NULL DEFAULT 0,
        requested_server_slots INTEGER NOT NULL DEFAULT 0,
        node_id INTEGER,
        allocation_id INTEGER,
        pterodactyl_server_id INTEGER,
        status TEXT NOT NULL DEFAULT 'pending',
        error_message TEXT,
        server_name TEXT,
        plan_id INTEGER,
        metadata TEXT NOT NULL DEFAULT '{}',
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id)
            REFERENCES users(id)
            ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS redeem_codes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT NOT NULL UNIQUE,
        type TEXT NOT NULL,
        value INTEGER NOT NULL DEFAULT 0,
        ram INTEGER NOT NULL DEFAULT 0,
        cpu INTEGER NOT NULL DEFAULT 0,
        disk INTEGER NOT NULL DEFAULT 0,
        backups INTEGER NOT NULL DEFAULT 0,
        allocations INTEGER NOT NULL DEFAULT 0,
        databases INTEGER NOT NULL DEFAULT 0,
        server_slots INTEGER NOT NULL DEFAULT 0,
        max_uses INTEGER NOT NULL DEFAULT 1,
        uses INTEGER NOT NULL DEFAULT 0,
        active INTEGER NOT NULL DEFAULT 1,
        created_by TEXT,
        description TEXT,
        expires_at TEXT,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        metadata TEXT NOT NULL DEFAULT '{}'
    );

    CREATE TABLE IF NOT EXISTS redeemed_codes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code_id INTEGER NOT NULL,
        user_id INTEGER,
        discord_user_id TEXT NOT NULL,
        code TEXT NOT NULL,
        type TEXT NOT NULL,
        value INTEGER NOT NULL DEFAULT 0,
        ram INTEGER NOT NULL DEFAULT 0,
        cpu INTEGER NOT NULL DEFAULT 0,
        disk INTEGER NOT NULL DEFAULT 0,
        backups INTEGER NOT NULL DEFAULT 0,
        allocations INTEGER NOT NULL DEFAULT 0,
        databases INTEGER NOT NULL DEFAULT 0,
        server_slots INTEGER NOT NULL DEFAULT 0,
        redeemed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        metadata TEXT NOT NULL DEFAULT '{}',
        FOREIGN KEY(code_id)
            REFERENCES redeem_codes(id)
            ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS plans (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        plan_id TEXT NOT NULL UNIQUE,
        name TEXT NOT NULL,
        description TEXT,
        ram INTEGER NOT NULL DEFAULT 0,
        cpu INTEGER NOT NULL DEFAULT 0,
        disk INTEGER NOT NULL DEFAULT 0,
        backups INTEGER NOT NULL DEFAULT 0,
        allocations INTEGER NOT NULL DEFAULT 0,
        databases INTEGER NOT NULL DEFAULT 0,
        server_slots INTEGER NOT NULL DEFAULT 1,
        price INTEGER NOT NULL DEFAULT 0,
        active INTEGER NOT NULL DEFAULT 1,
        sort_order INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        metadata TEXT NOT NULL DEFAULT '{}'
    );

    CREATE TABLE IF NOT EXISTS plan_purchases (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        discord_user_id TEXT NOT NULL,
        plan_id TEXT NOT NULL,
        plan_name TEXT,
        price INTEGER NOT NULL DEFAULT 0,
        ram INTEGER NOT NULL DEFAULT 0,
        cpu INTEGER NOT NULL DEFAULT 0,
        disk INTEGER NOT NULL DEFAULT 0,
        backups INTEGER NOT NULL DEFAULT 0,
        allocations INTEGER NOT NULL DEFAULT 0,
        databases INTEGER NOT NULL DEFAULT 0,
        server_slots INTEGER NOT NULL DEFAULT 0,
        coins_before INTEGER,
        coins_after INTEGER,
        status TEXT NOT NULL DEFAULT 'completed',
        reference_id TEXT,
        metadata TEXT NOT NULL DEFAULT '{}',
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id)
            REFERENCES users(id)
            ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS resource_transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        discord_user_id TEXT NOT NULL,
        type TEXT NOT NULL,
        ram INTEGER NOT NULL DEFAULT 0,
        cpu INTEGER NOT NULL DEFAULT 0,
        disk INTEGER NOT NULL DEFAULT 0,
        backups INTEGER NOT NULL DEFAULT 0,
        allocations INTEGER NOT NULL DEFAULT 0,
        databases INTEGER NOT NULL DEFAULT 0,
        server_slots INTEGER NOT NULL DEFAULT 0,
        before_ram INTEGER,
        after_ram INTEGER,
        before_cpu INTEGER,
        after_cpu INTEGER,
        before_disk INTEGER,
        after_disk INTEGER,
        before_backups INTEGER,
        after_backups INTEGER,
        before_allocations INTEGER,
        after_allocations INTEGER,
        before_databases INTEGER,
        after_databases INTEGER,
        before_server_slots INTEGER,
        after_server_slots INTEGER,
        description TEXT,
        reference_id TEXT,
        metadata TEXT NOT NULL DEFAULT '{}',
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id)
            REFERENCES users(id)
            ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS admin_audit_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        admin_discord_id TEXT NOT NULL,
        action TEXT NOT NULL,
        target_discord_id TEXT,
        target_type TEXT,
        target_id TEXT,
        details TEXT,
        metadata TEXT NOT NULL DEFAULT '{}',
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS bot_settings (
        key TEXT PRIMARY KEY,
        value TEXT,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
`);

/* ============================================================
 * INDEXES
 * ============================================================ */

db.exec(`
    CREATE INDEX IF NOT EXISTS idx_users_discord_id
        ON users(discord_id);

    CREATE INDEX IF NOT EXISTS idx_users_email
        ON users(email);

    CREATE INDEX IF NOT EXISTS idx_users_pterodactyl_user_id
        ON users(pterodactyl_user_id);

    CREATE INDEX IF NOT EXISTS idx_servers_discord_user_id
        ON servers(discord_user_id);

    CREATE INDEX IF NOT EXISTS idx_servers_pterodactyl_server_id
        ON servers(pterodactyl_server_id);

    CREATE INDEX IF NOT EXISTS idx_servers_identifier
        ON servers(pterodactyl_identifier);

    CREATE INDEX IF NOT EXISTS idx_transactions_user_id
        ON transactions(user_id);

    CREATE INDEX IF NOT EXISTS idx_transactions_discord_user_id
        ON transactions(discord_user_id);

    CREATE INDEX IF NOT EXISTS idx_transactions_created_at
        ON transactions(created_at);

    CREATE INDEX IF NOT EXISTS idx_deployment_attempts_user_id
        ON deployment_attempts(user_id);

    CREATE INDEX IF NOT EXISTS idx_deployment_attempts_discord_user_id
        ON deployment_attempts(discord_user_id);

    CREATE INDEX IF NOT EXISTS idx_deployment_attempts_status
        ON deployment_attempts(status);

    CREATE INDEX IF NOT EXISTS idx_redeem_codes_code
        ON redeem_codes(code);

    CREATE INDEX IF NOT EXISTS idx_redeemed_codes_user_id
        ON redeemed_codes(user_id);

    CREATE INDEX IF NOT EXISTS idx_redeemed_codes_code_id
        ON redeemed_codes(code_id);

    CREATE INDEX IF NOT EXISTS idx_plan_purchases_user_id
        ON plan_purchases(user_id);

    CREATE INDEX IF NOT EXISTS idx_plan_purchases_discord_user_id
        ON plan_purchases(discord_user_id);

    CREATE INDEX IF NOT EXISTS idx_resource_transactions_user_id
        ON resource_transactions(user_id);

    CREATE INDEX IF NOT EXISTS idx_resource_transactions_discord_user_id
        ON resource_transactions(discord_user_id);

    CREATE INDEX IF NOT EXISTS idx_admin_audit_logs_admin
        ON admin_audit_logs(admin_discord_id);

    CREATE INDEX IF NOT EXISTS idx_admin_audit_logs_target
        ON admin_audit_logs(target_discord_id);
`);

/* ============================================================
 * MIGRATIONS FOR OLDER PETROBOT DATABASES
 * ============================================================ */

function runMigrations() {
    /*
     * Older PetroBot versions may already have the main tables.
     * These checks allow the expanded V2 database to work with
     * an existing database instead of forcing a fresh database.
     */

    if (tableExists("users")) {
        addColumnIfMissing(
            "users",
            "pterodactyl_username",
            "TEXT"
        );

        addColumnIfMissing(
            "users",
            "pterodactyl_email",
            "TEXT"
        );

        addColumnIfMissing(
            "users",
            "first_name",
            "TEXT"
        );

        addColumnIfMissing(
            "users",
            "last_name",
            "TEXT"
        );

        addColumnIfMissing(
            "users",
            "root_admin",
            "INTEGER NOT NULL DEFAULT 0"
        );

        addColumnIfMissing(
            "users",
            "active",
            "INTEGER NOT NULL DEFAULT 1"
        );

        addColumnIfMissing(
            "users",
            "last_seen_at",
            "TEXT"
        );

        addColumnIfMissing(
            "users",
            "metadata",
            "TEXT NOT NULL DEFAULT '{}'"
        );
    }

    if (tableExists("coins")) {
        addColumnIfMissing(
            "coins",
            "lifetime_earned",
            "INTEGER NOT NULL DEFAULT 0"
        );

        addColumnIfMissing(
            "coins",
            "lifetime_spent",
            "INTEGER NOT NULL DEFAULT 0"
        );

        addColumnIfMissing(
            "coins",
            "updated_at",
            "TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP"
        );
    }

    if (tableExists("user_resources")) {
        addColumnIfMissing(
            "user_resources",
            "backups",
            "INTEGER NOT NULL DEFAULT 0"
        );

        addColumnIfMissing(
            "user_resources",
            "allocations",
            "INTEGER NOT NULL DEFAULT 0"
        );

        addColumnIfMissing(
            "user_resources",
            "databases",
            "INTEGER NOT NULL DEFAULT 0"
        );

        addColumnIfMissing(
            "user_resources",
            "server_slots",
            "INTEGER NOT NULL DEFAULT 0"
        );

        addColumnIfMissing(
            "user_resources",
            "updated_at",
            "TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP"
        );
    }

    if (tableExists("servers")) {
        addColumnIfMissing(
            "servers",
            "description",
            "TEXT"
        );

        addColumnIfMissing(
            "servers",
            "node_id",
            "INTEGER"
        );

        addColumnIfMissing(
            "servers",
            "node_name",
            "TEXT"
        );

        addColumnIfMissing(
            "servers",
            "allocation_id",
            "INTEGER"
        );

        addColumnIfMissing(
            "servers",
            "allocation_ip",
            "TEXT"
        );

        addColumnIfMissing(
            "servers",
            "allocation_port",
            "INTEGER"
        );

        addColumnIfMissing(
            "servers",
            "ram",
            "INTEGER NOT NULL DEFAULT 0"
        );

        addColumnIfMissing(
            "servers",
            "cpu",
            "INTEGER NOT NULL DEFAULT 0"
        );

        addColumnIfMissing(
            "servers",
            "disk",
            "INTEGER NOT NULL DEFAULT 0"
        );

        addColumnIfMissing(
            "servers",
            "backups",
            "INTEGER NOT NULL DEFAULT 0"
        );

        addColumnIfMissing(
            "servers",
            "databases",
            "INTEGER NOT NULL DEFAULT 0"
        );

        addColumnIfMissing(
            "servers",
            "allocations",
            "INTEGER NOT NULL DEFAULT 0"
        );

        addColumnIfMissing(
            "servers",
            "status",
            "TEXT DEFAULT 'unknown'"
        );

        addColumnIfMissing(
            "servers",
            "plan_id",
            "INTEGER"
        );

        addColumnIfMissing(
            "servers",
            "plan_name",
            "TEXT"
        );

        addColumnIfMissing(
            "servers",
            "active",
            "INTEGER NOT NULL DEFAULT 1"
        );

        addColumnIfMissing(
            "servers",
            "metadata",
            "TEXT NOT NULL DEFAULT '{}'"
        );
    }

    if (tableExists("transactions")) {
        addColumnIfMissing(
            "transactions",
            "discord_user_id",
            "TEXT"
        );

        addColumnIfMissing(
            "transactions",
            "balance_before",
            "INTEGER"
        );

        addColumnIfMissing(
            "transactions",
            "balance_after",
            "INTEGER"
        );

        addColumnIfMissing(
            "transactions",
            "reference_id",
            "TEXT"
        );

        addColumnIfMissing(
            "transactions",
            "metadata",
            "TEXT NOT NULL DEFAULT '{}'"
        );
    }

    if (tableExists("redeem_codes")) {
        addColumnIfMissing(
            "redeem_codes",
            "ram",
            "INTEGER NOT NULL DEFAULT 0"
        );

        addColumnIfMissing(
            "redeem_codes",
            "cpu",
            "INTEGER NOT NULL DEFAULT 0"
        );

        addColumnIfMissing(
            "redeem_codes",
            "disk",
            "INTEGER NOT NULL DEFAULT 0"
        );

        addColumnIfMissing(
            "redeem_codes",
            "backups",
            "INTEGER NOT NULL DEFAULT 0"
        );

        addColumnIfMissing(
            "redeem_codes",
            "allocations",
            "INTEGER NOT NULL DEFAULT 0"
        );

        addColumnIfMissing(
            "redeem_codes",
            "databases",
            "INTEGER NOT NULL DEFAULT 0"
        );

        addColumnIfMissing(
            "redeem_codes",
            "server_slots",
            "INTEGER NOT NULL DEFAULT 0"
        );

        addColumnIfMissing(
            "redeem_codes",
            "description",
            "TEXT"
        );

        addColumnIfMissing(
            "redeem_codes",
            "expires_at",
            "TEXT"
        );

        addColumnIfMissing(
            "redeem_codes",
            "metadata",
            "TEXT NOT NULL DEFAULT '{}'"
        );
    }

    db.prepare(`
        INSERT OR IGNORE INTO bot_settings
        (key, value, updated_at)
        VALUES (?, ?, ?)
    `).run(
        "database_version",
        String(DATABASE_VERSION),
        nowIso()
    );

    db.prepare(`
        UPDATE bot_settings
        SET value = ?,
            updated_at = ?
        WHERE key = ?
    `).run(
        String(DATABASE_VERSION),
        nowIso(),
        "database_version"
    );
}

runMigrations();

/* ============================================================
 * USER CREATION / LOOKUP
 * ============================================================ */

export function getUser(
    discordUserId
) {
    const id =
        normalizeDiscordId(discordUserId);

    if (!id) {
        return null;
    }

    return db.prepare(`
        SELECT *
        FROM users
        WHERE discord_id = ?
        LIMIT 1
    `).get(id) || null;
}

export function getUserById(
    userId
) {
    const id =
        positiveInteger(userId, 0);

    if (!id) {
        return null;
    }

    return db.prepare(`
        SELECT *
        FROM users
        WHERE id = ?
        LIMIT 1
    `).get(id) || null;
}

export function getUserByDiscordId(
    discordUserId
) {
    return getUser(discordUserId);
}

export function getUserByEmail(
    email
) {
    const normalized =
        normalizeEmail(email);

    if (!normalized) {
        return null;
    }

    return db.prepare(`
        SELECT *
        FROM users
        WHERE LOWER(email) = ?
           OR LOWER(pterodactyl_email) = ?
        ORDER BY id ASC
        LIMIT 1
    `).get(
        normalized,
        normalized
    ) || null;
}

export function createUser(
    discordUserId,
    username = null,
    email = null,
    options = {}
) {
    const discordId =
        normalizeDiscordId(discordUserId);

    if (!discordId) {
        throw new Error(
            "A valid Discord user ID is required."
        );
    }

    const existing =
        getUser(discordId);

    if (existing) {
        return existing;
    }

    const normalizedUsername =
        normalizeUsername(username);

    const normalizedEmail =
        normalizeEmail(email);

    const pterodactylUserId =
        options.pterodactylUserId ??
        options.pterodactyl_user_id ??
        null;

    const pterodactylUsername =
        options.pterodactylUsername ??
        options.pterodactyl_username ??
        null;

    const pterodactylEmail =
       (options.pterodactylEmail ??
         options.pterodactyl_email ??
         normalizedEmail) ||
         null;

    const firstName =
        options.firstName ??
        options.first_name ??
        null;

    const lastName =
        options.lastName ??
        options.last_name ??
        null;

    const rootAdmin =
        options.rootAdmin ??
        options.root_admin ??
        false;

    const metadata =
        options.metadata || {};

    const timestamp =
        nowIso();

    return withTransaction(() => {
        const result = db.prepare(`
            INSERT INTO users (
                discord_id,
                username,
                email,
                pterodactyl_user_id,
                pterodactyl_username,
                pterodactyl_email,
                first_name,
                last_name,
                root_admin,
                active,
                created_at,
                updated_at,
                last_seen_at,
                metadata
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?)
        `).run(
            discordId,
            normalizedUsername || null,
            normalizedEmail || null,
            pterodactylUserId,
            pterodactylUsername,
            pterodactylEmail,
            firstName,
            lastName,
            rootAdmin ? 1 : 0,
            timestamp,
            timestamp,
            timestamp,
            jsonStringify(metadata)
        );

        const user =
            getUserById(result.lastInsertRowid);

        ensureCoinsRow(
            user.id
        );

        ensureResourcesRow(
            user.id
        );

        return getUserById(
            user.id
        );
    });
}

export function updateUsername(
    discordUserId,
    username
) {
    const id =
        normalizeDiscordId(discordUserId);

    const value =
        normalizeUsername(username);

    if (!id) {
        return null;
    }

    db.prepare(`
        UPDATE users
        SET username = ?,
            updated_at = ?,
            last_seen_at = ?
        WHERE discord_id = ?
    `).run(
        value || null,
        nowIso(),
        nowIso(),
        id
    );

    return getUser(id);
}

export function updateUser(
    discordUserId,
    updates = {}
) {
    const id =
        normalizeDiscordId(discordUserId);

    if (!id) {
        return null;
    }

    const user =
        getUser(id);

    if (!user) {
        return null;
    }

    const allowed = {
        username: value =>
            normalizeUsername(value) || null,

        email: value =>
            normalizeEmail(value) || null,

        pterodactyl_user_id: value =>
            value === null ||
            value === undefined
                ? null
                : positiveInteger(value, null),

        pterodactyl_username: value =>
            value === null ||
            value === undefined
                ? null
                : safeString(value).trim(),

        pterodactyl_email: value =>
            value === null ||
            value === undefined
                ? null
                : normalizeEmail(value),

        first_name: value =>
            value === null ||
            value === undefined
                ? null
                : safeString(value).trim(),

        last_name: value =>
            value === null ||
            value === undefined
                ? null
                : safeString(value).trim(),

        root_admin: value =>
            value ? 1 : 0,

        active: value =>
            value ? 1 : 0,

        metadata: value =>
            typeof value === "string"
                ? value
                : jsonStringify(value)
    };

    const columns = [];
    const values = [];

    for (const [
        key,
        converter
    ] of Object.entries(allowed)) {
        if (
            Object.prototype.hasOwnProperty.call(
                updates,
                key
            )
        ) {
            columns.push(
                `${key} = ?`
            );

            values.push(
                converter(updates[key])
            );
        }
    }

    if (
        Object.prototype.hasOwnProperty.call(
            updates,
            "pterodactylUserId"
        )
    ) {
        columns.push(
            "pterodactyl_user_id = ?"
        );

        values.push(
            positiveInteger(
                updates.pterodactylUserId,
                null
            )
        );
    }

    if (
        Object.prototype.hasOwnProperty.call(
            updates,
            "pterodactylUsername"
        )
    ) {
        columns.push(
            "pterodactyl_username = ?"
        );

        values.push(
            safeString(
                updates.pterodactylUsername
            ).trim()
        );
    }

    if (
        Object.prototype.hasOwnProperty.call(
            updates,
            "pterodactylEmail"
        )
    ) {
        columns.push(
            "pterodactyl_email = ?"
        );

        values.push(
            normalizeEmail(
                updates.pterodactylEmail
            )
        );
    }

    if (
        Object.prototype.hasOwnProperty.call(
            updates,
            "rootAdmin"
        )
    ) {
        columns.push(
            "root_admin = ?"
        );

        values.push(
            updates.rootAdmin ? 1 : 0
        );
    }

    if (!columns.length) {
        return user;
    }

    columns.push(
        "updated_at = ?"
    );

    columns.push(
        "last_seen_at = ?"
    );

    values.push(
        nowIso(),
        nowIso(),
        id
    );

    db.prepare(`
        UPDATE users
        SET ${columns.join(", ")}
        WHERE discord_id = ?
    `).run(...values);

    return getUser(id);
}

export function updateUserById(
    userId,
    updates = {}
) {
    const user =
        getUserById(userId);

    if (!user) {
        return null;
    }

    return updateUser(
        user.discord_id,
        updates
    );
}

/* ============================================================
 * PTERODACTYL LINKING
 * ============================================================ */

export function linkPterodactylUser(
    discordUserId,
    pterodactylUserId,
    email = null,
    username = null,
    options = {}
) {
    const id =
        normalizeDiscordId(discordUserId);

    if (!id) {
        return null;
    }

    let user =
        getUser(id);

    if (!user) {
        user =
            createUser(
                id,
                options.discordUsername ||
                    username ||
                    null,
                email,
                {
                    pterodactylUserId,
                    pterodactylEmail: email,
                    pterodactylUsername: username,
                    firstName:
                        options.firstName || null,
                    lastName:
                        options.lastName || null,
                    rootAdmin:
                        options.rootAdmin || false
                }
            );
    } else {
        db.prepare(`
            UPDATE users
            SET pterodactyl_user_id = ?,
                pterodactyl_email = ?,
                pterodactyl_username = ?,
                updated_at = ?,
                last_seen_at = ?
            WHERE discord_id = ?
        `).run(
            positiveInteger(
                pterodactylUserId,
                null
            ),
            normalizeEmail(email) || null,
            username
                ? safeString(username).trim()
                : null,
            nowIso(),
            nowIso(),
            id
        );
    }

    return getUser(id);
}

export function unlinkPterodactylUser(
    discordUserId
) {
    const id =
        normalizeDiscordId(discordUserId);

    if (!id) {
        return null;
    }

    db.prepare(`
        UPDATE users
        SET pterodactyl_user_id = NULL,
            pterodactyl_username = NULL,
            pterodactyl_email = NULL,
            updated_at = ?,
            last_seen_at = ?
        WHERE discord_id = ?
    `).run(
        nowIso(),
        nowIso(),
        id
    );

    return getUser(id);
}

export function getUserByPterodactylId(
    pterodactylUserId
) {
    const id =
        positiveInteger(
            pterodactylUserId,
            0
        );

    if (!id) {
        return null;
    }

    return db.prepare(`
        SELECT *
        FROM users
        WHERE pterodactyl_user_id = ?
        LIMIT 1
    `).get(id) || null;
}

export function hasPterodactylAccount(
    discordUserId
) {
    const user =
        getUser(discordUserId);

    return Boolean(
        user &&
        user.pterodactyl_user_id
    );
}

/* ============================================================
 * USER ACTIVITY
 * ============================================================ */

export function touchUser(
    discordUserId,
    username = null
) {
    const id =
        normalizeDiscordId(discordUserId);

    if (!id) {
        return null;
    }

    const user =
        getUser(id);

    if (!user) {
        return null;
    }

    if (username !== null) {
        db.prepare(`
            UPDATE users
            SET username = ?,
                updated_at = ?,
                last_seen_at = ?
            WHERE discord_id = ?
        `).run(
            normalizeUsername(username) || null,
            nowIso(),
            nowIso(),
            id
        );
    } else {
        db.prepare(`
            UPDATE users
            SET updated_at = ?,
                last_seen_at = ?
            WHERE discord_id = ?
        `).run(
            nowIso(),
            nowIso(),
            id
        );
    }

    return getUser(id);
}

export function setUserActive(
    discordUserId,
    active = true
) {
    const id =
        normalizeDiscordId(discordUserId);

    if (!id) {
        return null;
    }

    db.prepare(`
        UPDATE users
        SET active = ?,
            updated_at = ?
        WHERE discord_id = ?
    `).run(
        active ? 1 : 0,
        nowIso(),
        id
    );

    return getUser(id);
}

export function setUserRootAdmin(
    discordUserId,
    rootAdmin = true
) {
    const id =
        normalizeDiscordId(discordUserId);

    if (!id) {
        return null;
    }

    db.prepare(`
        UPDATE users
        SET root_admin = ?,
            updated_at = ?
        WHERE discord_id = ?
    `).run(
        rootAdmin ? 1 : 0,
        nowIso(),
        id
    );

    return getUser(id);
}

/* ============================================================
 * COIN ROW HELPERS
 * ============================================================ */

export function ensureCoinsRow(
    userId
) {
    const id =
        positiveInteger(userId, 0);

    if (!id) {
        throw new Error(
            "Invalid user ID."
        );
    }

    db.prepare(`
        INSERT OR IGNORE INTO coins (
            user_id,
            balance,
            lifetime_earned,
            lifetime_spent,
            updated_at
        )
        VALUES (?, 0, 0, 0, ?)
    `).run(
        id,
        nowIso()
    );

    return db.prepare(`
        SELECT *
        FROM coins
        WHERE user_id = ?
        LIMIT 1
    `).get(id);
}

export function ensureResourcesRow(
    userId
) {
    const id =
        positiveInteger(userId, 0);

    if (!id) {
        throw new Error(
            "Invalid user ID."
        );
    }

    db.prepare(`
        INSERT OR IGNORE INTO user_resources (
            user_id,
            ram,
            cpu,
            disk,
            backups,
            allocations,
            databases,
            server_slots,
            updated_at
        )
        VALUES (?, 0, 0, 0, 0, 0, 0, 0, ?)
    `).run(
        id,
        nowIso()
    );

    return db.prepare(`
        SELECT *
        FROM user_resources
        WHERE user_id = ?
        LIMIT 1
    `).get(id);
}

/* ============================================================
 * COIN MANAGEMENT
 * ============================================================ */

export function getCoins(
    discordUserId
) {
    const user =
        getUser(discordUserId);

    if (!user) {
        return 0;
    }

    const row =
        ensureCoinsRow(user.id);

    return safeInteger(
        row.balance,
        0
    );
}

export function getCoinBalance(
    discordUserId
) {
    return getCoins(
        discordUserId
    );
}

export function getCoinRow(
    discordUserId
) {
    const user =
        getUser(discordUserId);

    if (!user) {
        return null;
    }

    return ensureCoinsRow(
        user.id
    );
}

export function setCoins(
    discordUserId,
    amount,
    description = "Coin balance updated",
    metadata = {}
) {
    const id =
        normalizeDiscordId(discordUserId);

    const value =
        positiveInteger(amount, 0);

    if (!id) {
        throw new Error(
            "Invalid Discord user ID."
        );
    }

    let user =
        getUser(id);

    if (!user) {
        user =
            createUser(id);
    }

    return withTransaction(() => {
        const coins =
            ensureCoinsRow(user.id);

        const before =
            safeInteger(
                coins.balance,
                0
            );

        db.prepare(`
            UPDATE coins
            SET balance = ?,
                updated_at = ?
            WHERE user_id = ?
        `).run(
            value,
            nowIso(),
            user.id
        );

        const after =
            value;

        db.prepare(`
            INSERT INTO transactions (
                user_id,
                discord_user_id,
                type,
                amount,
                balance_before,
                balance_after,
                description,
                reference_id,
                metadata,
                created_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).run(
            user.id,
            id,
            "set",
            after - before,
            before,
            after,
            normalizeTransactionDescription(
                description
            ),
            null,
            jsonStringify(metadata),
            nowIso()
        );

        return after;
    });
}

export function addCoins(
    discordUserId,
    amount,
    description = "Coins added",
    metadata = {},
    referenceId = null
) {
    const id =
        normalizeDiscordId(discordUserId);

    const value =
        positiveInteger(amount, 0);

    if (!id) {
        throw new Error(
            "Invalid Discord user ID."
        );
    }

    if (value <= 0) {
        return getCoins(id);
    }

    let user =
        getUser(id);

    if (!user) {
        user =
            createUser(id);
    }

    return withTransaction(() => {
        const coins =
            ensureCoinsRow(user.id);

        const before =
            safeInteger(
                coins.balance,
                0
            );

        const after =
            before + value;

        db.prepare(`
            UPDATE coins
            SET balance = ?,
                lifetime_earned =
                    lifetime_earned + ?,
                updated_at = ?
            WHERE user_id = ?
        `).run(
            after,
            value,
            nowIso(),
            user.id
        );

        db.prepare(`
            INSERT INTO transactions (
                user_id,
                discord_user_id,
                type,
                amount,
                balance_before,
                balance_after,
                description,
                reference_id,
                metadata,
                created_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).run(
            user.id,
            id,
            "credit",
            value,
            before,
            after,
            normalizeTransactionDescription(
                description
            ),
            referenceId,
            jsonStringify(metadata),
            nowIso()
        );

        return after;
    });
}

export function removeCoins(
    discordUserId,
    amount,
    description = "Coins removed",
    metadata = {},
    referenceId = null
) {
    const id =
        normalizeDiscordId(discordUserId);

    const value =
        positiveInteger(amount, 0);

    if (!id) {
        throw new Error(
            "Invalid Discord user ID."
        );
    }

    if (value <= 0) {
        return getCoins(id);
    }

    let user =
        getUser(id);

    if (!user) {
        throw new Error(
            "User does not exist."
        );
    }

    return withTransaction(() => {
        const coins =
            ensureCoinsRow(user.id);

        const before =
            safeInteger(
                coins.balance,
                0
            );

        if (before < value) {
            throw new Error(
                `Insufficient coins. Required ${value}, available ${before}.`
            );
        }

        const after =
            before - value;

        db.prepare(`
            UPDATE coins
            SET balance = ?,
                lifetime_spent =
                    lifetime_spent + ?,
                updated_at = ?
            WHERE user_id = ?
        `).run(
            after,
            value,
            nowIso(),
            user.id
        );

        db.prepare(`
            INSERT INTO transactions (
                user_id,
                discord_user_id,
                type,
                amount,
                balance_before,
                balance_after,
                description,
                reference_id,
                metadata,
                created_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).run(
            user.id,
            id,
            "debit",
            -value,
            before,
            after,
            normalizeTransactionDescription(
                description
            ),
            referenceId,
            jsonStringify(metadata),
            nowIso()
        );

        return after;
    });
}

export function transferCoins(
    fromDiscordUserId,
    toDiscordUserId,
    amount,
    description = "Coin transfer",
    metadata = {}
) {
    const fromId =
        normalizeDiscordId(
            fromDiscordUserId
        );

    const toId =
        normalizeDiscordId(
            toDiscordUserId
        );

    const value =
        positiveInteger(amount, 0);

    if (!fromId || !toId) {
        throw new Error(
            "Both sender and receiver are required."
        );
    }

    if (fromId === toId) {
        throw new Error(
            "You cannot transfer coins to yourself."
        );
    }

    if (value <= 0) {
        throw new Error(
            "Transfer amount must be greater than zero."
        );
    }

    let sender =
        getUser(fromId);

    if (!sender) {
        throw new Error(
            "Sender does not exist."
        );
    }

    let receiver =
        getUser(toId);

    if (!receiver) {
        receiver =
            createUser(toId);
    }

    return withTransaction(() => {
        const senderCoins =
            ensureCoinsRow(sender.id);

        const receiverCoins =
            ensureCoinsRow(receiver.id);

        const senderBefore =
            safeInteger(
                senderCoins.balance,
                0
            );

        const receiverBefore =
            safeInteger(
                receiverCoins.balance,
                0
            );

        if (senderBefore < value) {
            throw new Error(
                `Insufficient coins. Required ${value}, available ${senderBefore}.`
            );
        }

        const senderAfter =
            senderBefore - value;

        const receiverAfter =
            receiverBefore + value;

        db.prepare(`
            UPDATE coins
            SET balance = ?,
                lifetime_spent =
                    lifetime_spent + ?,
                updated_at = ?
            WHERE user_id = ?
        `).run(
            senderAfter,
            value,
            nowIso(),
            sender.id
        );

        db.prepare(`
            UPDATE coins
            SET balance = ?,
                lifetime_earned =
                    lifetime_earned + ?,
                updated_at = ?
            WHERE user_id = ?
        `).run(
            receiverAfter,
            value,
            nowIso(),
            receiver.id
        );

        const reference =
            createId("TRANSFER-");

        db.prepare(`
            INSERT INTO transactions (
                user_id,
                discord_user_id,
                type,
                amount,
                balance_before,
                balance_after,
                description,
                reference_id,
                metadata,
                created_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).run(
            sender.id,
            fromId,
            "transfer_sent",
            -value,
            senderBefore,
            senderAfter,
            normalizeTransactionDescription(
                description
            ),
            reference,
            jsonStringify({
                ...metadata,
                receiver: toId
            }),
            nowIso()
        );

        db.prepare(`
            INSERT INTO transactions (
                user_id,
                discord_user_id,
                type,
                amount,
                balance_before,
                balance_after,
                description,
                reference_id,
                metadata,
                created_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).run(
            receiver.id,
            toId,
            "transfer_received",
            value,
            receiverBefore,
            receiverAfter,
            normalizeTransactionDescription(
                description
            ),
            reference,
            jsonStringify({
                ...metadata,
                sender: fromId
            }),
            nowIso()
        );

        return {
            referenceId: reference,
            amount: value,
            sender: {
                discordId: fromId,
                before: senderBefore,
                after: senderAfter
            },
            receiver: {
                discordId: toId,
                before: receiverBefore,
                after: receiverAfter
            }
        };
    });
}

/* ============================================================
 * COIN TRANSACTION HISTORY
 * ============================================================ */

export function getTransactions(
    discordUserId,
    limit = DEFAULT_TRANSACTION_LIMIT,
    offset = 0
) {
    const id =
        normalizeDiscordId(discordUserId);

    if (!id) {
        return [];
    }

    const safeLimit =
        clampLimit(limit);

    const safeOffset =
        Math.max(
            0,
            positiveInteger(offset, 0)
        );

    return db.prepare(`
        SELECT *
        FROM transactions
        WHERE discord_user_id = ?
        ORDER BY id DESC
        LIMIT ? OFFSET ?
    `).all(
        id,
        safeLimit,
        safeOffset
    );
}

export function getTransactionHistory(
    discordUserId,
    limit = DEFAULT_TRANSACTION_LIMIT
) {
    return getTransactions(
        discordUserId,
        limit,
        0
    );
}

export function getTransactionById(
    transactionId
) {
    const id =
        positiveInteger(
            transactionId,
            0
        );

    if (!id) {
        return null;
    }

    return db.prepare(`
        SELECT *
        FROM transactions
        WHERE id = ?
        LIMIT 1
    `).get(id) || null;
}

export function countTransactions(
    discordUserId
) {
    const id =
        normalizeDiscordId(discordUserId);

    if (!id) {
        return 0;
    }

    const row =
        db.prepare(`
            SELECT COUNT(*) AS count
            FROM transactions
            WHERE discord_user_id = ?
        `).get(id);

    return safeInteger(
        row?.count,
        0
    );
}

export function getLifetimeCoinStats(
    discordUserId
) {
    const user =
        getUser(discordUserId);

    if (!user) {
        return {
            balance: 0,
            lifetimeEarned: 0,
            lifetimeSpent: 0
        };
    }

    const row =
        ensureCoinsRow(user.id);

    return {
        balance: safeInteger(
            row.balance,
            0
        ),
        lifetimeEarned: safeInteger(
            row.lifetime_earned,
            0
        ),
        lifetimeSpent: safeInteger(
            row.lifetime_spent,
            0
        )
    };
}

/* ============================================================
 * RESOURCE BALANCE
 * ============================================================ */

export function getUserResources(
    discordUserId
) {
    const user =
        getUser(discordUserId);

    if (!user) {
        return normalizeResourceObject();
    }

    const row =
        ensureResourcesRow(
            user.id
        );

    return {
        user_id: row.user_id,
        ram: safeInteger(
            row.ram,
            0
        ),
        cpu: safeInteger(
            row.cpu,
            0
        ),
        disk: safeInteger(
            row.disk,
            0
        ),
        backups: safeInteger(
            row.backups,
            0
        ),
        allocations: safeInteger(
            row.allocations,
            0
        ),
        databases: safeInteger(
            row.databases,
            0
        ),
        server_slots: safeInteger(
            row.server_slots,
            0
        ),
        updated_at:
            row.updated_at
    };
}

export function getResources(
    discordUserId
) {
    return getUserResources(
        discordUserId
    );
}

export function setUserResources(
    discordUserId,
    resources = {},
    description = "Resources updated",
    type = "set",
    referenceId = null,
    metadata = {}
) {
    const id =
        normalizeDiscordId(discordUserId);

    if (!id) {
        throw new Error(
            "Invalid Discord user ID."
        );
    }

    let user =
        getUser(id);

    if (!user) {
        user =
            createUser(id);
    }

    const next =
        normalizeResourceObject(
            resources
        );

    return withTransaction(() => {
        const current =
            getUserResources(id);

        db.prepare(`
            UPDATE user_resources
            SET ram = ?,
                cpu = ?,
                disk = ?,
                backups = ?,
                allocations = ?,
                databases = ?,
                server_slots = ?,
                updated_at = ?
            WHERE user_id = ?
        `).run(
            next.ram,
            next.cpu,
            next.disk,
            next.backups,
            next.allocations,
            next.databases,
            next.server_slots,
            nowIso(),
            user.id
        );

        recordResourceTransactionInternal({
            userId: user.id,
            discordUserId: id,
            type,
            before: current,
            after: next,
            amount: subtractResourceObjects(
                next,
                current
            ),
            description,
            referenceId,
            metadata
        });

        return getUserResources(id);
    });
}

export function addResources(
    discordUserId,
    resources = {},
    description = "Resources added",
    type = "credit",
    referenceId = null,
    metadata = {}
) {
    const id =
        normalizeDiscordId(discordUserId);

    const amount =
        normalizeResourceObject(
            resources
        );

    if (!id) {
        throw new Error(
            "Invalid Discord user ID."
        );
    }

    if (
        resourceObjectHasNegativeValue(
            amount
        )
    ) {
        throw new Error(
            "Resource values cannot be negative."
        );
    }

    let user =
        getUser(id);

    if (!user) {
        user =
            createUser(id);
    }

    return withTransaction(() => {
        const current =
            getUserResources(id);

        const next =
            addResourceObjects(
                current,
                amount
            );

        db.prepare(`
            UPDATE user_resources
            SET ram = ?,
                cpu = ?,
                disk = ?,
                backups = ?,
                allocations = ?,
                databases = ?,
                server_slots = ?,
                updated_at = ?
            WHERE user_id = ?
        `).run(
            next.ram,
            next.cpu,
            next.disk,
            next.backups,
            next.allocations,
            next.databases,
            next.server_slots,
            nowIso(),
            user.id
        );

        recordResourceTransactionInternal({
            userId: user.id,
            discordUserId: id,
            type,
            before: current,
            after: next,
            amount,
            description,
            referenceId,
            metadata
        });

        return getUserResources(id);
    });
}

export function removeResources(
    discordUserId,
    resources = {},
    description = "Resources removed",
    type = "debit",
    referenceId = null,
    metadata = {}
) {
    const id =
        normalizeDiscordId(discordUserId);

    const amount =
        normalizeResourceObject(
            resources
        );

    if (!id) {
        throw new Error(
            "Invalid Discord user ID."
        );
    }

    let user =
        getUser(id);

    if (!user) {
        throw new Error(
            "User does not exist."
        );
    }

    return withTransaction(() => {
        const current =
            getUserResources(id);

        if (
            !resourcesAreSufficient(
                current,
                amount
            )
        ) {
            const missing =
                getMissingResources(
                    current,
                    amount
                );

            throw new Error(
                `Insufficient resources: ${jsonStringify(
                    missing
                )}`
            );
        }

        const next =
            subtractResourceObjects(
                current,
                amount
            );

        db.prepare(`
            UPDATE user_resources
            SET ram = ?,
                cpu = ?,
                disk = ?,
                backups = ?,
                allocations = ?,
                databases = ?,
                server_slots = ?,
                updated_at = ?
            WHERE user_id = ?
        `).run(
            next.ram,
            next.cpu,
            next.disk,
            next.backups,
            next.allocations,
            next.databases,
            next.server_slots,
            nowIso(),
            user.id
        );

        recordResourceTransactionInternal({
            userId: user.id,
            discordUserId: id,
            type,
            before: current,
            after: next,
            amount: {
                ram: -amount.ram,
                cpu: -amount.cpu,
                disk: -amount.disk,
                backups: -amount.backups,
                allocations: -amount.allocations,
                databases: -amount.databases,
                server_slots:
                    -amount.server_slots
            },
            description,
            referenceId,
            metadata
        });

        return getUserResources(id);
    });
}

export function hasEnoughResources(
    discordUserId,
    resources = {}
) {
    return resourcesAreSufficient(
        getUserResources(
            discordUserId
        ),
        resources
    );
}

export function getMissingUserResources(
    discordUserId,
    resources = {}
) {
    return getMissingResources(
        getUserResources(
            discordUserId
        ),
        resources
    );
}

/* ============================================================
 * RESOURCE TRANSACTION INTERNAL HANDLER
 * ============================================================ */

function recordResourceTransactionInternal({
    userId,
    discordUserId,
    type,
    before,
    after,
    amount,
    description,
    referenceId,
    metadata
}) {
    const oldResources =
        normalizeResourceObject(
            before
        );

    const newResources =
        normalizeResourceObject(
            after
        );

    const delta =
        normalizeResourceObject(
            amount
        );

    db.prepare(`
        INSERT INTO resource_transactions (
            user_id,
            discord_user_id,
            type,
            ram,
            cpu,
            disk,
            backups,
            allocations,
            databases,
            server_slots,
            before_ram,
            after_ram,
            before_cpu,
            after_cpu,
            before_disk,
            after_disk,
            before_backups,
            after_backups,
            before_allocations,
            after_allocations,
            before_databases,
            after_databases,
            before_server_slots,
            after_server_slots,
            description,
            reference_id,
            metadata,
            created_at
        )
        VALUES (
            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
            ?, ?, ?, ?, ?, ?, ?, ?
        )
    `).run(
        userId,
        discordUserId,
        safeString(type) || "unknown",
        delta.ram,
        delta.cpu,
        delta.disk,
        delta.backups,
        delta.allocations,
        delta.databases,
        delta.server_slots,
        oldResources.ram,
        newResources.ram,
        oldResources.cpu,
        newResources.cpu,
        oldResources.disk,
        newResources.disk,
        oldResources.backups,
        newResources.backups,
        oldResources.allocations,
        newResources.allocations,
        oldResources.databases,
        newResources.databases,
        oldResources.server_slots,
        newResources.server_slots,
        normalizeDescription(
            description
        ),
        referenceId,
        jsonStringify(metadata),
        nowIso()
    );
}

/* ============================================================
 * RESOURCE TRANSACTION HISTORY
 * ============================================================ */

export function getResourceTransactions(
    discordUserId,
    limit = DEFAULT_TRANSACTION_LIMIT,
    offset = 0
) {
    const id =
        normalizeDiscordId(discordUserId);

    if (!id) {
        return [];
    }

    return db.prepare(`
        SELECT *
        FROM resource_transactions
        WHERE discord_user_id = ?
        ORDER BY id DESC
        LIMIT ? OFFSET ?
    `).all(
        id,
        clampLimit(limit),
        Math.max(
            0,
            positiveInteger(offset, 0)
        )
    );
}

export function getResourceTransactionById(
    transactionId
) {
    const id =
        positiveInteger(
            transactionId,
            0
        );

    if (!id) {
        return null;
    }

    return db.prepare(`
        SELECT *
        FROM resource_transactions
        WHERE id = ?
        LIMIT 1
    `).get(id) || null;
}

/* ============================================================
 * SERVER RECORD MANAGEMENT
 * ============================================================ */

export function getUserServers(
    discordUserId,
    options = {}
) {
    const id =
        normalizeDiscordId(discordUserId);

    if (!id) {
        return [];
    }

    const includeInactive =
        options.includeInactive === true;

    if (includeInactive) {
        return db.prepare(`
            SELECT *
            FROM servers
            WHERE discord_user_id = ?
            ORDER BY id DESC
        `).all(id);
    }

    return db.prepare(`
        SELECT *
        FROM servers
        WHERE discord_user_id = ?
          AND active = 1
        ORDER BY id DESC
    `).all(id);
}

export function getServerById(
    serverId
) {
    const id =
        positiveInteger(
            serverId,
            0
        );

    if (!id) {
        return null;
    }

    return db.prepare(`
        SELECT *
        FROM servers
        WHERE id = ?
        LIMIT 1
    `).get(id) || null;
}

export function getServer(
    serverId
) {
    return getServerById(
        serverId
    );
}

export function getServerByPterodactylId(
    pterodactylServerId
) {
    const id =
        positiveInteger(
            pterodactylServerId,
            0
        );

    if (!id) {
        return null;
    }

    return db.prepare(`
        SELECT *
        FROM servers
        WHERE pterodactyl_server_id = ?
        LIMIT 1
    `).get(id) || null;
}

export function getServerByIdentifier(
    identifier
) {
    const value =
        safeString(identifier).trim();

    if (!value) {
        return null;
    }

    return db.prepare(`
        SELECT *
        FROM servers
        WHERE pterodactyl_identifier = ?
        LIMIT 1
    `).get(value) || null;
}

export function getServerForUser(
    discordUserId,
    serverId
) {
    const userId =
        normalizeDiscordId(
            discordUserId
        );

    const id =
        positiveInteger(
            serverId,
            0
        );

    if (!userId || !id) {
        return null;
    }

    return db.prepare(`
        SELECT *
        FROM servers
        WHERE id = ?
          AND discord_user_id = ?
        LIMIT 1
    `).get(
        id,
        userId
    ) || null;
}

export function addServer(
    data = {}
) {
    const discordUserId =
        normalizeDiscordId(
            data.discordUserId ??
            data.discord_user_id
        );

    if (!discordUserId) {
        throw new Error(
            "discordUserId is required."
        );
    }

    const name =
        normalizeServerName(
            data.name ||
            "Minecraft Server"
        );

    const description =
        normalizeDescription(
            data.description
        );

    const resources =
        normalizeResourceObject({
            ram:
                data.ram ??
                data.memory,
            cpu:
                data.cpu,
            disk:
                data.disk,
            backups:
                data.backups,
            allocations:
                data.allocations,
            databases:
                data.databases,
            server_slots:
                data.server_slots
        });

    const createdAt =
        data.createdAt ||
        data.created_at ||
        nowIso();

    const updatedAt =
        data.updatedAt ||
        data.updated_at ||
        nowIso();

    const result =
        db.prepare(`
            INSERT INTO servers (
                discord_user_id,
                pterodactyl_server_id,
                pterodactyl_identifier,
                pterodactyl_uuid,
                name,
                description,
                node_id,
                node_name,
                allocation_id,
                allocation_ip,
                allocation_port,
                ram,
                cpu,
                disk,
                backups,
                databases,
                allocations,
                status,
                plan_id,
                plan_name,
                active,
                created_at,
                updated_at,
                metadata
            )
            VALUES (
                ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
            )
        `).run(
            discordUserId,
            data.pterodactylServerId ??
                data.pterodactyl_server_id ??
                null,
            data.identifier ??
                data.pterodactylIdentifier ??
                data.pterodactyl_identifier ??
                null,
            data.uuid ??
                data.pterodactylUuid ??
                data.pterodactyl_uuid ??
                null,
            name,
            description || null,
            data.nodeId ??
                data.node_id ??
                null,
            data.nodeName ??
                data.node_name ??
                null,
            data.allocationId ??
                data.allocation_id ??
                null,
            data.allocationIp ??
                data.allocation_ip ??
                null,
            data.allocationPort ??
                data.allocation_port ??
                null,
            resources.ram,
            resources.cpu,
            resources.disk,
            resources.backups,
            resources.databases,
            resources.allocations,
            data.status ||
                "unknown",
            data.planId ??
                data.plan_id ??
                null,
            data.planName ??
                data.plan_name ??
                null,
            data.active === false
                ? 0
                : 1,
            createdAt,
            updatedAt,
            jsonStringify(
                data.metadata || {}
            )
        );

    return getServerById(
        result.lastInsertRowid
    );
}

export function updateServerRecord(
    serverId,
    updates = {}
) {
    const id =
        positiveInteger(
            serverId,
            0
        );

    if (!id) {
        return null;
    }

    const server =
        getServerById(id);

    if (!server) {
        return null;
    }

    const fields = [];
    const values = [];

    const mapping = {
        pterodactyl_server_id:
            updates.pterodactyl_server_id ??
            updates.pterodactylServerId,

        pterodactyl_identifier:
            updates.pterodactyl_identifier ??
            updates.pterodactylIdentifier ??
            updates.identifier,

        pterodactyl_uuid:
            updates.pterodactyl_uuid ??
            updates.pterodactylUuid ??
            updates.uuid,

        name:
            updates.name !== undefined
                ? normalizeServerName(
                    updates.name
                )
                : undefined,

        description:
            updates.description !== undefined
                ? normalizeDescription(
                    updates.description
                )
                : undefined,

        node_id:
            updates.node_id ??
            updates.nodeId,

        node_name:
            updates.node_name ??
            updates.nodeName,

        allocation_id:
            updates.allocation_id ??
            updates.allocationId,

        allocation_ip:
            updates.allocation_ip ??
            updates.allocationIp,

        allocation_port:
            updates.allocation_port ??
            updates.allocationPort,

        ram:
            updates.ram,

        cpu:
            updates.cpu,

        disk:
            updates.disk,

        backups:
            updates.backups,

        databases:
            updates.databases,

        allocations:
            updates.allocations,

        status:
            updates.status,

        plan_id:
            updates.plan_id ??
            updates.planId,

        plan_name:
            updates.plan_name ??
            updates.planName,

        active:
            updates.active !== undefined
                ? updates.active
                    ? 1
                    : 0
                : undefined,

        metadata:
            updates.metadata !== undefined
                ? (
                    typeof updates.metadata === "string"
                        ? updates.metadata
                        : jsonStringify(
                            updates.metadata
                        )
                )
                : undefined
    };

    for (const [
        field,
        value
    ] of Object.entries(mapping)) {
        if (value !== undefined) {
            fields.push(
                `${field} = ?`
            );

            values.push(
                value
            );
        }
    }

    if (!fields.length) {
        return server;
    }

    fields.push(
        "updated_at = ?"
    );

    values.push(
        nowIso()
    );

    values.push(id);

    db.prepare(`
        UPDATE servers
        SET ${fields.join(", ")}
        WHERE id = ?
    `).run(...values);

    return getServerById(id);
}

export function updateServer(
    serverId,
    updates = {}
) {
    return updateServerRecord(
        serverId,
        updates
    );
}

export function renameServer(
    serverId,
    name
) {
    return updateServerRecord(
        serverId,
        {
            name
        }
    );
}

export function deactivateServer(
    serverId
) {
    return updateServerRecord(
        serverId,
        {
            active: false
        }
    );
}

export function activateServer(
    serverId
) {
    return updateServerRecord(
        serverId,
        {
            active: true
        }
    );
}

export function deleteServer(
    serverId
) {
    const id =
        positiveInteger(
            serverId,
            0
        );

    if (!id) {
        return false;
    }

    const result =
        db.prepare(`
            DELETE FROM servers
            WHERE id = ?
        `).run(id);

    return result.changes > 0;
}

/* ============================================================
 * SERVER STATISTICS
 * ============================================================ */

export function countUserServers(
    discordUserId,
    includeInactive = false
) {
    const id =
        normalizeDiscordId(
            discordUserId
        );

    if (!id) {
        return 0;
    }

    const row =
        includeInactive
            ? db.prepare(`
                SELECT COUNT(*) AS count
                FROM servers
                WHERE discord_user_id = ?
            `).get(id)
            : db.prepare(`
                SELECT COUNT(*) AS count
                FROM servers
                WHERE discord_user_id = ?
                  AND active = 1
            `).get(id);

    return safeInteger(
        row?.count,
        0
    );
}

export function getServerStats(
    discordUserId
) {
    const id =
        normalizeDiscordId(
            discordUserId
        );

    if (!id) {
        return {
            count: 0,
            ram: 0,
            cpu: 0,
            disk: 0,
            backups: 0,
            allocations: 0,
            databases: 0
        };
    }

    const row =
        db.prepare(`
            SELECT
                COUNT(*) AS count,
                COALESCE(SUM(ram), 0) AS ram,
                COALESCE(SUM(cpu), 0) AS cpu,
                COALESCE(SUM(disk), 0) AS disk,
                COALESCE(SUM(backups), 0) AS backups,
                COALESCE(SUM(allocations), 0) AS allocations,
                COALESCE(SUM(databases), 0) AS databases
            FROM servers
            WHERE discord_user_id = ?
              AND active = 1
        `).get(id);

    return {
        count: safeInteger(
            row?.count,
            0
        ),
        ram: safeInteger(
            row?.ram,
            0
        ),
        cpu: safeInteger(
            row?.cpu,
            0
        ),
        disk: safeInteger(
            row?.disk,
            0
        ),
        backups: safeInteger(
            row?.backups,
            0
        ),
        allocations: safeInteger(
            row?.allocations,
            0
        ),
        databases: safeInteger(
            row?.databases,
            0
        )
    };
}

/* ============================================================
 * DEPLOYMENT ATTEMPTS
 * ============================================================ */

export function createDeploymentAttempt(
    data = {}
) {
    const discordUserId =
        normalizeDiscordId(
            data.discordUserId ??
            data.discord_user_id
        );

    if (!discordUserId) {
        throw new Error(
            "discordUserId is required."
        );
    }

    const user =
        getUser(
            discordUserId
        );

    const resources =
        normalizeResourceObject({
            ram:
                data.ram ??
                data.requestedRam ??
                data.requested_ram,
            cpu:
                data.cpu ??
                data.requestedCpu ??
                data.requested_cpu,
            disk:
                data.disk ??
                data.requestedDisk ??
                data.requested_disk,
            backups:
                data.backups ??
                data.requestedBackups ??
                data.requested_backups,
            allocations:
                data.allocations ??
                data.requestedAllocations ??
                data.requested_allocations,
            databases:
                data.databases ??
                data.requestedDatabases ??
                data.requested_databases,
            server_slots:
                data.server_slots ??
                data.requestedServerSlots ??
                data.requested_server_slots
        });

    const result =
        db.prepare(`
            INSERT INTO deployment_attempts (
                discord_user_id,
                user_id,
                requested_ram,
                requested_cpu,
                requested_disk,
                requested_backups,
                requested_databases,
                requested_allocations,
                requested_server_slots,
                node_id,
                allocation_id,
                pterodactyl_server_id,
                status,
                error_message,
                server_name,
                plan_id,
                metadata,
                created_at,
                updated_at
            )
            VALUES (
                ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                ?, ?, ?, ?, ?, ?, ?, ?
            )
        `).run(
            discordUserId,
            user?.id || null,
            resources.ram,
            resources.cpu,
            resources.disk,
            resources.backups,
            resources.databases,
            resources.allocations,
            resources.server_slots,
            data.nodeId ??
                data.node_id ??
                null,
            data.allocationId ??
                data.allocation_id ??
                null,
            data.pterodactylServerId ??
                data.pterodactyl_server_id ??
                null,
            data.status ||
                "pending",
            normalizeError(
                data.errorMessage ??
                data.error_message
            ) || null,
            data.serverName ??
                data.server_name ??
                null,
            data.planId ??
                data.plan_id ??
                null,
            jsonStringify(
                data.metadata || {}
            ),
            nowIso(),
            nowIso()
        );

    return getDeploymentAttempt(
        result.lastInsertRowid
    );
}

export function getDeploymentAttempt(
    attemptId
) {
    const id =
        positiveInteger(
            attemptId,
            0
        );

    if (!id) {
        return null;
    }

    return db.prepare(`
        SELECT *
        FROM deployment_attempts
        WHERE id = ?
        LIMIT 1
    `).get(id) || null;
}

export function updateDeploymentAttempt(
    attemptId,
    updates = {}
) {
    const id =
        positiveInteger(
            attemptId,
            0
        );

    if (!id) {
        return null;
    }

    const existing =
        getDeploymentAttempt(id);

    if (!existing) {
        return null;
    }

    const fields = [];
    const values = [];

    const aliases = {
        status:
            updates.status,

        error_message:
            updates.error_message ??
            updates.errorMessage,

        node_id:
            updates.node_id ??
            updates.nodeId,

        allocation_id:
            updates.allocation_id ??
            updates.allocationId,

        pterodactyl_server_id:
            updates.pterodactyl_server_id ??
            updates.pterodactylServerId,

        server_name:
            updates.server_name ??
            updates.serverName,

        plan_id:
            updates.plan_id ??
            updates.planId,

        metadata:
            updates.metadata !== undefined
                ? (
                    typeof updates.metadata === "string"
                        ? updates.metadata
                        : jsonStringify(
                            updates.metadata
                        )
                )
                : undefined
    };

    for (const [
        field,
        value
    ] of Object.entries(aliases)) {
        if (value !== undefined) {
            fields.push(
                `${field} = ?`
            );

            values.push(
                field === "error_message"
                    ? normalizeError(value)
                    : value
            );
        }
    }

    if (!fields.length) {
        return existing;
    }

    fields.push(
        "updated_at = ?"
    );

    values.push(
        nowIso()
    );

    values.push(id);

    db.prepare(`
        UPDATE deployment_attempts
        SET ${fields.join(", ")}
        WHERE id = ?
    `).run(...values);

    return getDeploymentAttempt(id);
}

export function listDeploymentAttempts(
    discordUserId,
    limit = DEFAULT_TRANSACTION_LIMIT
) {
    const id =
        normalizeDiscordId(
            discordUserId
        );

    if (!id) {
        return [];
    }

    return db.prepare(`
        SELECT *
        FROM deployment_attempts
        WHERE discord_user_id = ?
        ORDER BY id DESC
        LIMIT ?
    `).all(
        id,
        clampLimit(limit)
    );
}

/* ============================================================
 * REDEEM CODE HELPERS
 * ============================================================ */

function normalizeRedeemType(
    type
) {
    const value =
        safeString(type)
            .trim()
            .toLowerCase();

    if (
        value === "coins" ||
        value === "coin"
    ) {
        return "coins";
    }

    if (
        value === "resource" ||
        value === "resources"
    ) {
        return "resource";
    }

    return value;
}

export function createRedeemCode(
    data = {}
) {
    const type =
        normalizeRedeemType(
            data.type
        );

    if (
        type !== "coins" &&
        type !== "resource"
    ) {
        throw new Error(
            "Redeem code type must be coins or resource."
        );
    }

    let code =
        safeString(
            data.code
        )
            .trim()
            .toUpperCase();

    if (!code) {
        code =
            randomCode(16);
    }

    const value =
        positiveInteger(
            data.value,
            0
        );

    const resources =
        normalizeResourceObject(
            data
        );

    if (
        type === "coins" &&
        value <= 0
    ) {
        throw new Error(
            "Coin redeem code value must be greater than zero."
        );
    }

    if (
        type === "resource" &&
        RESOURCE_FIELDS.every(
            field =>
                resources[field] <= 0
        )
    ) {
        throw new Error(
            "Resource redeem code must contain at least one resource."
        );
    }

    const maxUses =
        Math.max(
            1,
            positiveInteger(
                data.maxUses ??
                data.max_uses,
                1
            )
        );

    const expiresAt =
        data.expiresAt ??
        data.expires_at ??
        null;

    const createdBy =
        data.createdBy ??
        data.created_by ??
        null;

    const description =
        normalizeDescription(
            data.description
        );

    const metadata =
        data.metadata || {};

    const result =
        db.prepare(`
            INSERT INTO redeem_codes (
                code,
                type,
                value,
                ram,
                cpu,
                disk,
                backups,
                allocations,
                databases,
                server_slots,
                max_uses,
                uses,
                active,
                created_by,
                description,
                expires_at,
                created_at,
                metadata
            )
            VALUES (
                ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                ?, 0, 1, ?, ?, ?, ?, ?
            )
        `).run(
            code,
            type,
            value,
            resources.ram,
            resources.cpu,
            resources.disk,
            resources.backups,
            resources.allocations,
            resources.databases,
            resources.server_slots,
            maxUses,
            createdBy,
            description || null,
            expiresAt,
            nowIso(),
            jsonStringify(metadata)
        );

    return getRedeemCodeById(
        result.lastInsertRowid
    );
}

export function getRedeemCode(
    code
) {
    const normalized =
        safeString(code)
            .trim()
            .toUpperCase();

    if (!normalized) {
        return null;
    }

    return db.prepare(`
        SELECT *
        FROM redeem_codes
        WHERE code = ?
        LIMIT 1
    `).get(normalized) || null;
}

export function getRedeemCodeById(
    codeId
) {
    const id =
        positiveInteger(
            codeId,
            0
        );

    if (!id) {
        return null;
    }

    return db.prepare(`
        SELECT *
        FROM redeem_codes
        WHERE id = ?
        LIMIT 1
    `).get(id) || null;
}

export function isRedeemCodeUsable(
    code
) {
    const redeemCode =
        typeof code === "object"
            ? code
            : getRedeemCode(code);

    if (!redeemCode) {
        return {
            usable: false,
            reason: "Code does not exist."
        };
    }

    if (!redeemCode.active) {
        return {
            usable: false,
            reason: "Code is inactive."
        };
    }

    if (
        redeemCode.uses >=
        redeemCode.max_uses
    ) {
        return {
            usable: false,
            reason: "Code has reached its maximum uses."
        };
    }

    if (
        redeemCode.expires_at
    ) {
        const expiry =
            new Date(
                redeemCode.expires_at
            );

        if (
            Number.isFinite(
                expiry.getTime()
            ) &&
            expiry.getTime() <= Date.now()
        ) {
            return {
                usable: false,
                reason: "Code has expired."
            };
        }
    }

    return {
        usable: true,
        reason: null
    };
}

export function hasUserRedeemedCode(
    discordUserId,
    code
) {
    const id =
        normalizeDiscordId(
            discordUserId
        );

    const normalizedCode =
        safeString(code)
            .trim()
            .toUpperCase();

    if (!id || !normalizedCode) {
        return false;
    }

    const row =
        db.prepare(`
            SELECT id
            FROM redeemed_codes
            WHERE discord_user_id = ?
              AND code = ?
            LIMIT 1
        `).get(
            id,
            normalizedCode
        );

    return Boolean(row);
}

/* ============================================================
 * REDEEM CODE REDEMPTION
 * ============================================================ */

export function redeemCode(
    discordUserId,
    code
) {
    const discordId =
        normalizeDiscordId(
            discordUserId
        );

    const normalizedCode =
        safeString(code)
            .trim()
            .toUpperCase();

    if (
        !discordId ||
        !normalizedCode
    ) {
        throw new Error(
            "Discord user ID and redeem code are required."
        );
    }

    let user =
        getUser(discordId);

    if (!user) {
        user =
            createUser(discordId);
    }

    return withTransaction(() => {
        const redeemCode =
            getRedeemCode(
                normalizedCode
            );

        const usability =
            isRedeemCodeUsable(
                redeemCode
            );

        if (!usability.usable) {
            throw new Error(
                usability.reason
            );
        }

        const alreadyRedeemed =
            hasUserRedeemedCode(
                discordId,
                normalizedCode
            );

        if (alreadyRedeemed) {
            throw new Error(
                "You have already redeemed this code."
            );
        }

        const type =
            normalizeRedeemType(
                redeemCode.type
            );

        if (type === "coins") {
            const before =
                ensureCoinsRow(
                    user.id
                );

            const balanceBefore =
                safeInteger(
                    before.balance,
                    0
                );

            const amount =
                positiveInteger(
                    redeemCode.value,
                    0
                );

            const balanceAfter =
                balanceBefore + amount;

            db.prepare(`
                UPDATE coins
                SET balance = ?,
                    lifetime_earned =
                        lifetime_earned + ?,
                    updated_at = ?
                WHERE user_id = ?
            `).run(
                balanceAfter,
                amount,
                nowIso(),
                user.id
            );

            db.prepare(`
                INSERT INTO transactions (
                    user_id,
                    discord_user_id,
                    type,
                    amount,
                    balance_before,
                    balance_after,
                    description,
                    reference_id,
                    metadata,
                    created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            `).run(
                user.id,
                discordId,
                "redeem",
                amount,
                balanceBefore,
                balanceAfter,
                `Redeemed code ${normalizedCode}`,
                normalizedCode,
                jsonStringify({
                    codeType: "coins"
                }),
                nowIso()
            );

            db.prepare(`
                UPDATE redeem_codes
                SET uses = uses + 1,
                    active = CASE
                        WHEN uses + 1 >= max_uses
                        THEN 0
                        ELSE active
                    END
                WHERE id = ?
            `).run(
                redeemCode.id
            );

            db.prepare(`
                INSERT INTO redeemed_codes (
                    code_id,
                    user_id,
                    discord_user_id,
                    code,
                    type,
                    value,
                    ram,
                    cpu,
                    disk,
                    backups,
                    allocations,
                    databases,
                    server_slots,
                    redeemed_at,
                    metadata
                )
                VALUES (
                    ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                    ?, ?, ?, ?, ?
                )
            `).run(
                redeemCode.id,
                user.id,
                discordId,
                normalizedCode,
                "coins",
                amount,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                nowIso(),
                jsonStringify({
                    description:
                        redeemCode.description
                })
            );

            return {
                success: true,
                type: "coins",
                amount,
                balanceBefore,
                balanceAfter,
                code: normalizedCode
            };
        }

        if (type === "resource") {
            const current =
                getUserResources(
                    discordId
                );

            const amount =
                normalizeResourceObject({
                    ram: redeemCode.ram,
                    cpu: redeemCode.cpu,
                    disk: redeemCode.disk,
                    backups:
                        redeemCode.backups,
                    allocations:
                        redeemCode.allocations,
                    databases:
                        redeemCode.databases,
                    server_slots:
                        redeemCode.server_slots
                });

            const next =
                addResourceObjects(
                    current,
                    amount
                );

            db.prepare(`
                UPDATE user_resources
                SET ram = ?,
                    cpu = ?,
                    disk = ?,
                    backups = ?,
                    allocations = ?,
                    databases = ?,
                    server_slots = ?,
                    updated_at = ?
                WHERE user_id = ?
            `).run(
                next.ram,
                next.cpu,
                next.disk,
                next.backups,
                next.allocations,
                next.databases,
                next.server_slots,
                nowIso(),
                user.id
            );

            recordResourceTransactionInternal({
                userId: user.id,
                discordUserId: discordId,
                type: "redeem",
                before: current,
                after: next,
                amount,
                description:
                    `Redeemed code ${normalizedCode}`,
                referenceId:
                    normalizedCode,
                metadata: {
                    codeType: "resource"
                }
            });

            db.prepare(`
                UPDATE redeem_codes
                SET uses = uses + 1,
                    active = CASE
                        WHEN uses + 1 >= max_uses
                        THEN 0
                        ELSE active
                    END
                WHERE id = ?
            `).run(
                redeemCode.id
            );

            db.prepare(`
                INSERT INTO redeemed_codes (
                    code_id,
                    user_id,
                    discord_user_id,
                    code,
                    type,
                    value,
                    ram,
                    cpu,
                    disk,
                    backups,
                    allocations,
                    databases,
                    server_slots,
                    redeemed_at,
                    metadata
                )
                VALUES (
                    ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                    ?, ?, ?, ?, ?
                )
            `).run(
                redeemCode.id,
                user.id,
                discordId,
                normalizedCode,
                "resource",
                0,
                amount.ram,
                amount.cpu,
                amount.disk,
                amount.backups,
                amount.allocations,
                amount.databases,
                amount.server_slots,
                nowIso(),
                jsonStringify({
                    description:
                        redeemCode.description
                })
            );

            return {
                success: true,
                type: "resource",
                resources: amount,
                balanceBefore: current,
                balanceAfter: next,
                code: normalizedCode
            };
        }

        throw new Error(
            `Unsupported redeem code type: ${type}`
        );
    });
}

/* ============================================================
 * REDEEM HISTORY
 * ============================================================ */

export function getRedeemedCodes(
    discordUserId,
    limit = DEFAULT_TRANSACTION_LIMIT,
    offset = 0
) {
    const id =
        normalizeDiscordId(
            discordUserId
        );

    if (!id) {
        return [];
    }

    return db.prepare(`
        SELECT *
        FROM redeemed_codes
        WHERE discord_user_id = ?
        ORDER BY id DESC
        LIMIT ? OFFSET ?
    `).all(
        id,
        clampLimit(limit),
        Math.max(
            0,
            positiveInteger(offset, 0)
        )
    );
}

export function getRedeemedCodeById(
    id
) {
    const value =
        positiveInteger(id, 0);

    if (!value) {
        return null;
    }

    return db.prepare(`
        SELECT *
        FROM redeemed_codes
        WHERE id = ?
        LIMIT 1
    `).get(value) || null;
}

/* ============================================================
 * PLAN SYSTEM
 * ============================================================ */

export const DEFAULT_PLANS = [
    {
        planId: "1",
        name: "Plan 1",
        description:
            "Starter Minecraft hosting plan",
        ram: 2048,
        cpu: 100,
        disk: 5120,
        backups: 1,
        allocations: 1,
        databases: 1,
        serverSlots: 1,
        price: 250,
        sortOrder: 1
    },
    {
        planId: "2",
        name: "Plan 2",
        description:
            "Balanced Minecraft hosting plan",
        ram: 4096,
        cpu: 200,
        disk: 10240,
        backups: 2,
        allocations: 1,
        databases: 2,
        serverSlots: 1,
        price: 500,
        sortOrder: 2
    },
    {
        planId: "3",
        name: "Plan 3",
        description:
            "High performance Minecraft hosting plan",
        ram: 8192,
        cpu: 300,
        disk: 20480,
        backups: 3,
        allocations: 2,
        databases: 3,
        serverSlots: 1,
        price: 1000,
        sortOrder: 3
    },
    {
        planId: "4",
        name: "Plan 4",
        description:
            "Advanced Minecraft hosting plan",
        ram: 16384,
        cpu: 400,
        disk: 40960,
        backups: 4,
        allocations: 2,
        databases: 4,
        serverSlots: 2,
        price: 2000,
        sortOrder: 4
    },
    {
        planId: "5",
        name: "Plan 5",
        description:
            "Extreme Minecraft hosting plan",
        ram: 32768,
        cpu: 600,
        disk: 81920,
        backups: 5,
        allocations: 3,
        databases: 5,
        serverSlots: 3,
        price: 4000,
        sortOrder: 5
    }
];

export function ensureDefaultPlans() {
    for (const plan of DEFAULT_PLANS) {
        db.prepare(`
            INSERT OR IGNORE INTO plans (
                plan_id,
                name,
                description,
                ram,
                cpu,
                disk,
                backups,
                allocations,
                databases,
                server_slots,
                price,
                active,
                sort_order,
                created_at,
                updated_at,
                metadata
            )
            VALUES (
                ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                ?, 1, ?, ?, ?, ?
            )
        `).run(
            plan.planId,
            plan.name,
            plan.description,
            plan.ram,
            plan.cpu,
            plan.disk,
            plan.backups,
            plan.allocations,
            plan.databases,
            plan.serverSlots,
            plan.price,
            plan.sortOrder,
            nowIso(),
            nowIso(),
            jsonStringify({})
        );
    }
}

ensureDefaultPlans();

/* ============================================================
 * PLAN LOOKUPS
 * ============================================================ */

export function getPlans(
    includeInactive = false
) {
    if (includeInactive) {
        return db.prepare(`
            SELECT *
            FROM plans
            ORDER BY sort_order ASC, id ASC
        `).all();
    }

    return db.prepare(`
        SELECT *
        FROM plans
        WHERE active = 1
        ORDER BY sort_order ASC, id ASC
    `).all();
}

export function getPlan(
    planId
) {
    const value =
        safeString(planId)
            .trim();

    if (!value) {
        return null;
    }

    return db.prepare(`
        SELECT *
        FROM plans
        WHERE plan_id = ?
        LIMIT 1
    `).get(value) || null;
}

export function getPlanById(
    planId
) {
    return getPlan(
        planId
    );
}

export function createPlan(
    data = {}
) {
    const planId =
        safeString(
            data.planId ??
            data.plan_id
        ).trim();

    if (!planId) {
        throw new Error(
            "planId is required."
        );
    }

    if (getPlan(planId)) {
        throw new Error(
            `Plan ${planId} already exists.`
        );
    }

    const resources =
        normalizeResourceObject(
            data
        );

    const result =
        db.prepare(`
            INSERT INTO plans (
                plan_id,
                name,
                description,
                ram,
                cpu,
                disk,
                backups,
                allocations,
                databases,
                server_slots,
                price,
                active,
                sort_order,
                created_at,
                updated_at,
                metadata
            )
            VALUES (
                ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                ?, ?, ?, ?, ?, ?
            )
        `).run(
            planId,
            normalizeServerName(
                data.name ||
                `Plan ${planId}`
            ),
            normalizeDescription(
                data.description
            ) || null,
            resources.ram,
            resources.cpu,
            resources.disk,
            resources.backups,
            resources.allocations,
            resources.databases,
            resources.server_slots || 1,
            positiveInteger(
                data.price,
                0
            ),
            data.active === false
                ? 0
                : 1,
            positiveInteger(
                data.sortOrder ??
                data.sort_order,
                0
            ),
            nowIso(),
            nowIso(),
            jsonStringify(
                data.metadata || {}
            )
        );

    return getPlan(
        planId
    );
}

export function updatePlan(
    planId,
    updates = {}
) {
    const current =
        getPlan(planId);

    if (!current) {
        return null;
    }

    const fields = [];
    const values = [];

    const map = {
        name:
            updates.name !== undefined
                ? normalizeServerName(
                    updates.name
                )
                : undefined,

        description:
            updates.description !== undefined
                ? normalizeDescription(
                    updates.description
                )
                : undefined,

        ram:
            updates.ram !== undefined
                ? positiveInteger(
                    updates.ram,
                    0
                )
                : undefined,

        cpu:
            updates.cpu !== undefined
                ? positiveInteger(
                    updates.cpu,
                    0
                )
                : undefined,

        disk:
            updates.disk !== undefined
                ? positiveInteger(
                    updates.disk,
                    0
                )
                : undefined,

        backups:
            updates.backups !== undefined
                ? positiveInteger(
                    updates.backups,
                    0
                )
                : undefined,

        allocations:
            updates.allocations !== undefined
                ? positiveInteger(
                    updates.allocations,
                    0
                )
                : undefined,

        databases:
            updates.databases !== undefined
                ? positiveInteger(
                    updates.databases,
                    0
                )
                : undefined,

        server_slots:
            updates.server_slots ??
            updates.serverSlots,

        price:
            updates.price !== undefined
                ? positiveInteger(
                    updates.price,
                    0
                )
                : undefined,

        active:
            updates.active !== undefined
                ? (
                    updates.active
                        ? 1
                        : 0
                )
                : undefined,

        sort_order:
            updates.sort_order ??
            updates.sortOrder,

        metadata:
            updates.metadata !== undefined
                ? (
                    typeof updates.metadata === "string"
                        ? updates.metadata
                        : jsonStringify(
                            updates.metadata
                        )
                )
                : undefined
    };

    for (const [
        field,
        value
    ] of Object.entries(map)) {
        if (value !== undefined) {
            fields.push(
                `${field} = ?`
            );

            values.push(
                value
            );
        }
    }

    if (!fields.length) {
        return current;
    }

    fields.push(
        "updated_at = ?"
    );

    values.push(
        nowIso()
    );

    values.push(
        current.plan_id
    );

    db.prepare(`
        UPDATE plans
        SET ${fields.join(", ")}
        WHERE plan_id = ?
    `).run(...values);

    return getPlan(
        current.plan_id
    );
}

/* ============================================================
 * PLAN PURCHASES
 * ============================================================ */

export function purchasePlan(
    discordUserId,
    planId,
    options = {}
) {
    const discordId =
        normalizeDiscordId(
            discordUserId
        );

    if (!discordId) {
        throw new Error(
            "Invalid Discord user ID."
        );
    }

    const plan =
        getPlan(planId);

    if (!plan) {
        throw new Error(
            `Plan ${planId} does not exist.`
        );
    }

    if (!plan.active) {
        throw new Error(
            "This plan is currently unavailable."
        );
    }

    let user =
        getUser(discordId);

    if (!user) {
        user =
            createUser(discordId);
    }

    return withTransaction(() => {
        const coins =
            ensureCoinsRow(
                user.id
            );

        const before =
            safeInteger(
                coins.balance,
                0
            );

        const price =
            positiveInteger(
                plan.price,
                0
            );

        if (before < price) {
            throw new Error(
                `Insufficient coins. Required ${price}, available ${before}.`
            );
        }

        const after =
            before - price;

        db.prepare(`
            UPDATE coins
            SET balance = ?,
                lifetime_spent =
                    lifetime_spent + ?,
                updated_at = ?
            WHERE user_id = ?
        `).run(
            after,
            price,
            nowIso(),
            user.id
        );

        const reference =
            options.referenceId ||
            createId("PLAN-");

        db.prepare(`
            INSERT INTO transactions (
                user_id,
                discord_user_id,
                type,
                amount,
                balance_before,
                balance_after,
                description,
                reference_id,
                metadata,
                created_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).run(
            user.id,
            discordId,
            "plan_purchase",
            -price,
            before,
            after,
            `Purchased ${plan.name}`,
            reference,
            jsonStringify({
                planId: plan.plan_id,
                ...options.metadata
            }),
            nowIso()
        );

        const resources =
            normalizeResourceObject({
                ram: plan.ram,
                cpu: plan.cpu,
                disk: plan.disk,
                backups: plan.backups,
                allocations:
                    plan.allocations,
                databases:
                    plan.databases,
                server_slots:
                    plan.server_slots
            });

        const currentResources =
            getUserResources(
                discordId
            );

        const nextResources =
            addResourceObjects(
                currentResources,
                resources
            );

        db.prepare(`
            UPDATE user_resources
            SET ram = ?,
                cpu = ?,
                disk = ?,
                backups = ?,
                allocations = ?,
                databases = ?,
                server_slots = ?,
                updated_at = ?
            WHERE user_id = ?
        `).run(
            nextResources.ram,
            nextResources.cpu,
            nextResources.disk,
            nextResources.backups,
            nextResources.allocations,
            nextResources.databases,
            nextResources.server_slots,
            nowIso(),
            user.id
        );

        recordResourceTransactionInternal({
            userId: user.id,
            discordUserId: discordId,
            type: "plan_purchase",
            before: currentResources,
            after: nextResources,
            amount: resources,
            description:
                `Resources granted by ${plan.name}`,
            referenceId: reference,
            metadata: {
                planId:
                    plan.plan_id
            }
        });

        const result =
            db.prepare(`
                INSERT INTO plan_purchases (
                    user_id,
                    discord_user_id,
                    plan_id,
                    plan_name,
                    price,
                    ram,
                    cpu,
                    disk,
                    backups,
                    allocations,
                    databases,
                    server_slots,
                    coins_before,
                    coins_after,
                    status,
                    reference_id,
                    metadata,
                    created_at
                )
                VALUES (
                    ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                    ?, ?, ?, ?, ?, ?, ?, ?
                )
            `).run(
                user.id,
                discordId,
                plan.plan_id,
                plan.name,
                price,
                resources.ram,
                resources.cpu,
                resources.disk,
                resources.backups,
                resources.allocations,
                resources.databases,
                resources.server_slots,
                before,
                after,
                "completed",
                reference,
                jsonStringify(
                    options.metadata || {}
                ),
                nowIso()
            );

        return {
            success: true,
            purchaseId:
                result.lastInsertRowid,
            referenceId:
                reference,
            plan,
            price,
            coinsBefore:
                before,
            coinsAfter:
                after,
            resources,
            resourcesBefore:
                currentResources,
            resourcesAfter:
                nextResources
        };
    });
}

/* ============================================================
 * PLAN PURCHASE HISTORY
 * ============================================================ */

export function getPlanPurchases(
    discordUserId,
    limit = DEFAULT_TRANSACTION_LIMIT,
    offset = 0
) {
    const id =
        normalizeDiscordId(
            discordUserId
        );

    if (!id) {
        return [];
    }

    return db.prepare(`
        SELECT *
        FROM plan_purchases
        WHERE discord_user_id = ?
        ORDER BY id DESC
        LIMIT ? OFFSET ?
    `).all(
        id,
        clampLimit(limit),
        Math.max(
            0,
            positiveInteger(offset, 0)
        )
    );
}

export function getPlanPurchaseById(
    purchaseId
) {
    const id =
        positiveInteger(
            purchaseId,
            0
        );

    if (!id) {
        return null;
    }

    return db.prepare(`
        SELECT *
        FROM plan_purchases
        WHERE id = ?
        LIMIT 1
    `).get(id) || null;
}

/* ============================================================
 * USER STATISTICS
 * ============================================================ */

export function getUserStats(
    discordUserId
) {
    const user =
        getUser(
            discordUserId
        );

    if (!user) {
        return {
            user: null,
            coins: {
                balance: 0,
                lifetimeEarned: 0,
                lifetimeSpent: 0
            },
            resources:
                normalizeResourceObject(),
            servers: {
                count: 0,
                ram: 0,
                cpu: 0,
                disk: 0,
                backups: 0,
                allocations: 0,
                databases: 0
            },
            transactions: 0,
            planPurchases: 0,
            redeemedCodes: 0
        };
    }

    const coins =
        getLifetimeCoinStats(
            discordUserId
        );

    const resources =
        getUserResources(
            discordUserId
        );

    const servers =
        getServerStats(
            discordUserId
        );

    const transactionCount =
        countTransactions(
            discordUserId
        );

    const planPurchaseRow =
        db.prepare(`
            SELECT COUNT(*) AS count
            FROM plan_purchases
            WHERE discord_user_id = ?
        `).get(
            discordUserId
        );

    const redeemedCodeRow =
        db.prepare(`
            SELECT COUNT(*) AS count
            FROM redeemed_codes
            WHERE discord_user_id = ?
        `).get(
            discordUserId
        );

    return {
        user,
        coins,
        resources,
        servers,
        transactions:
            safeInteger(
                transactionCount,
                0
            ),
        planPurchases:
            safeInteger(
                planPurchaseRow?.count,
                0
            ),
        redeemedCodes:
            safeInteger(
                redeemedCodeRow?.count,
                0
            )
    };
}

/* ============================================================
 * USER DELETE
 * ============================================================ */

export function deleteUser(
    discordUserId,
    options = {}
) {
    const id =
        normalizeDiscordId(
            discordUserId
        );

    if (!id) {
        return false;
    }

    const user =
        getUser(id);

    if (!user) {
        return false;
    }

    const hardDelete =
        options.hardDelete !== false;

    if (!hardDelete) {
        setUserActive(
            id,
            false
        );

        return true;
    }

    return withTransaction(() => {
        const result =
            db.prepare(`
                DELETE FROM users
                WHERE discord_id = ?
            `).run(id);

        return result.changes > 0;
    });
}

/* ============================================================
 * ADMIN AUDIT LOGGING
 * ============================================================ */

export function createAdminAuditLog(
    data = {}
) {
    const adminDiscordId =
        normalizeDiscordId(
            data.adminDiscordId ??
            data.admin_discord_id
        );

    if (!adminDiscordId) {
        throw new Error(
            "adminDiscordId is required."
        );
    }

    const result =
        db.prepare(`
            INSERT INTO admin_audit_logs (
                admin_discord_id,
                action,
                target_discord_id,
                target_type,
                target_id,
                details,
                metadata,
                created_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `).run(
            adminDiscordId,
            safeString(
                data.action
            ).trim() || "unknown",
            data.targetDiscordId ??
                data.target_discord_id ??
                null,
            data.targetType ??
                data.target_type ??
                null,
            data.targetId ??
                data.target_id ??
                null,
            normalizeAuditDetails(
                data.details
            ) || null,
            jsonStringify(
                data.metadata || {}
            ),
            nowIso()
        );

    return db.prepare(`
        SELECT *
        FROM admin_audit_logs
        WHERE id = ?
        LIMIT 1
    `).get(
        result.lastInsertRowid
    );
}

export function getAdminAuditLogs(
    options = {}
) {
    const limit =
        clampLimit(
            options.limit
        );

    const offset =
        Math.max(
            0,
            positiveInteger(
                options.offset,
                0
            )
        );

    if (
        options.adminDiscordId ||
        options.admin_discord_id
    ) {
        const adminId =
            normalizeDiscordId(
                options.adminDiscordId ??
                options.admin_discord_id
            );

        return db.prepare(`
            SELECT *
            FROM admin_audit_logs
            WHERE admin_discord_id = ?
            ORDER BY id DESC
            LIMIT ? OFFSET ?
        `).all(
            adminId,
            limit,
            offset
        );
    }

    if (
        options.targetDiscordId ||
        options.target_discord_id
    ) {
        const targetId =
            normalizeDiscordId(
                options.targetDiscordId ??
                options.target_discord_id
            );

        return db.prepare(`
            SELECT *
            FROM admin_audit_logs
            WHERE target_discord_id = ?
            ORDER BY id DESC
            LIMIT ? OFFSET ?
        `).all(
            targetId,
            limit,
            offset
        );
    }

    return db.prepare(`
        SELECT *
        FROM admin_audit_logs
        ORDER BY id DESC
        LIMIT ? OFFSET ?
    `).all(
        limit,
        offset
    );
}

/* ============================================================
 * BOT SETTINGS
 * ============================================================ */

export function getSetting(
    key,
    defaultValue = null
) {
    const normalizedKey =
        safeString(key)
            .trim();

    if (!normalizedKey) {
        return defaultValue;
    }

    const row =
        db.prepare(`
            SELECT value
            FROM bot_settings
            WHERE key = ?
            LIMIT 1
        `).get(
            normalizedKey
        );

    if (!row) {
        return defaultValue;
    }

    return row.value;
}

export function setSetting(
    key,
    value
) {
    const normalizedKey =
        safeString(key)
            .trim();

    if (!normalizedKey) {
        throw new Error(
            "Setting key is required."
        );
    }

    const serialized =
        typeof value === "string"
            ? value
            : jsonStringify(value);

    db.prepare(`
        INSERT INTO bot_settings (
            key,
            value,
            updated_at
        )
        VALUES (?, ?, ?)
        ON CONFLICT(key)
        DO UPDATE SET
            value = excluded.value,
            updated_at = excluded.updated_at
    `).run(
        normalizedKey,
        serialized,
        nowIso()
    );

    return getSetting(
        normalizedKey
    );
}

export function deleteSetting(
    key
) {
    const normalizedKey =
        safeString(key)
            .trim();

    if (!normalizedKey) {
        return false;
    }

    const result =
        db.prepare(`
            DELETE FROM bot_settings
            WHERE key = ?
        `).run(
            normalizedKey
        );

    return result.changes > 0;
}

export function getAllSettings() {
    const rows =
        db.prepare(`
            SELECT *
            FROM bot_settings
            ORDER BY key ASC
        `).all();

    return Object.fromEntries(
        rows.map(
            row => [
                row.key,
                row.value
            ]
        )
    );
}

/* ============================================================
 * DATABASE INFORMATION
 * ============================================================ */

export function getDatabasePath() {
    return databasePath;
}

export function getDatabaseVersion() {
    return DATABASE_VERSION;
}

export function getDatabaseStats() {
    const tables = [
        "users",
        "coins",
        "user_resources",
        "servers",
        "transactions",
        "deployment_attempts",
        "redeem_codes",
        "redeemed_codes",
        "plans",
        "plan_purchases",
        "resource_transactions",
        "admin_audit_logs",
        "bot_settings"
    ];

    const result = {};

    for (const table of tables) {
        if (!tableExists(table)) {
            result[table] = 0;
            continue;
        }

        const row =
            db.prepare(
                `SELECT COUNT(*) AS count FROM ${table}`
            ).get();

        result[table] =
            safeInteger(
                row?.count,
                0
            );
    }

    return result;
}

/* ============================================================
 * DATABASE HEALTH
 * ============================================================ */

export function checkDatabaseHealth() {
    try {
        const result =
            db.prepare(
                "SELECT 1 AS ok"
            ).get();

        return {
            healthy:
                result?.ok === 1,
            path:
                databasePath,
            version:
                DATABASE_VERSION,
            timestamp:
                nowIso()
        };
    } catch (error) {
        return {
            healthy: false,
            path:
                databasePath,
            version:
                DATABASE_VERSION,
            timestamp:
                nowIso(),
            error:
                normalizeError(
                    error?.message
                )
        };
    }
}

/* ============================================================
 * DATABASE VACUUM / OPTIMIZATION
 * ============================================================ */

export function optimizeDatabase() {
    db.exec(`
        PRAGMA wal_checkpoint(TRUNCATE);
        PRAGMA optimize;
    `);

    return checkDatabaseHealth();
}

export function vacuumDatabase() {
    db.exec(`
        VACUUM;
    `);

    return checkDatabaseHealth();
}

/* ============================================================
 * DATABASE CLOSE
 * ============================================================ */

export function closeDatabase() {
    try {
        db.close();

        return true;
    } catch {
        return false;
    }
}

/* ============================================================
 * COMPATIBILITY ALIASES
 * ============================================================ */

export const getBalance =
    getCoins;

export const addBalance =
    addCoins;

export const removeBalance =
    removeCoins;

export const getResourcesForUser =
    getUserResources;

export const addUserResources =
    addResources;

export const removeUserResources =
    removeResources;

export const getServers =
    getUserServers;

export const createServer =
    addServer;

export const createRedeem =
    createRedeemCode;

export const redeem =
    redeemCode;

/* ============================================================
 * DEFAULT DATABASE OBJECT
 * ============================================================ */

const database = {
    db,

    databasePath,
    databaseVersion:
        DATABASE_VERSION,

    getUser,
    getUserById,
    getUserByDiscordId,
    getUserByEmail,
    createUser,
    updateUsername,
    updateUser,
    updateUserById,

    linkPterodactylUser,
    unlinkPterodactylUser,
    getUserByPterodactylId,
    hasPterodactylAccount,

    touchUser,
    setUserActive,
    setUserRootAdmin,

    ensureCoinsRow,
    getCoins,
    getCoinBalance,
    getCoinRow,
    setCoins,
    addCoins,
    removeCoins,
    transferCoins,

    getTransactions,
    getTransactionHistory,
    getTransactionById,
    countTransactions,
    getLifetimeCoinStats,

    ensureResourcesRow,
    getUserResources,
    getResources,
    setUserResources,
    addResources,
    removeResources,
    hasEnoughResources,
    getMissingUserResources,

    getResourceTransactions,
    getResourceTransactionById,

    getUserServers,
    getServerById,
    getServer,
    getServerByPterodactylId,
    getServerByIdentifier,
    getServerForUser,
    addServer,
    updateServerRecord,
    updateServer,
    renameServer,
    deactivateServer,
    activateServer,
    deleteServer,

    countUserServers,
    getServerStats,

    createDeploymentAttempt,
    getDeploymentAttempt,
    updateDeploymentAttempt,
    listDeploymentAttempts,

    createRedeemCode,
    getRedeemCode,
    getRedeemCodeById,
    isRedeemCodeUsable,
    hasUserRedeemedCode,
    redeemCode,
    getRedeemedCodes,
    getRedeemedCodeById,

    DEFAULT_PLANS,
    ensureDefaultPlans,
    getPlans,
    getPlan,
    getPlanById,
    createPlan,
    updatePlan,
    purchasePlan,
    getPlanPurchases,
    getPlanPurchaseById,

    getUserStats,
    deleteUser,

    createAdminAuditLog,
    getAdminAuditLogs,

    getSetting,
    setSetting,
    deleteSetting,
    getAllSettings,

    getDatabasePath,
    getDatabaseVersion,
    getDatabaseStats,
    checkDatabaseHealth,
    optimizeDatabase,
    vacuumDatabase,
    closeDatabase,

    getBalance,
    addBalance,
    removeBalance,
    getResourcesForUser,
    addUserResources,
    removeUserResources,
    getServers,
    createServer,
    createRedeem,
    redeem
};

export default database;

/*
 * ============================================================
 * PetroBot V2 - Database Layer
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */