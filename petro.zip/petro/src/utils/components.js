/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */

import {
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    StringSelectMenuBuilder
} from "discord.js";

/*
 * ============================================================
 * MAIN DASHBOARD
 * ============================================================
 */

export function mainMenuButtons() {
    return [
        new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(
                        "menu_deploy"
                    )
                    .setLabel(
                        "Deploy Server"
                    )
                    .setEmoji(
                        "🚀"
                    )
                    .setStyle(
                        ButtonStyle.Primary
                    ),

                new ButtonBuilder()
                    .setCustomId(
                        "menu_servers"
                    )
                    .setLabel(
                        "My Servers"
                    )
                    .setEmoji(
                        "🖥️"
                    )
                    .setStyle(
                        ButtonStyle.Secondary
                    ),

                new ButtonBuilder()
                    .setCustomId(
                        "menu_economy"
                    )
                    .setLabel(
                        "Economy"
                    )
                    .setEmoji(
                        "🪙"
                    )
                    .setStyle(
                        ButtonStyle.Success
                    )
            ),

        new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(
                        "menu_redeem"
                    )
                    .setLabel(
                        "Redeem"
                    )
                    .setEmoji(
                        "🎟️"
                    )
                    .setStyle(
                        ButtonStyle.Secondary
                    ),

                new ButtonBuilder()
                    .setCustomId(
                        "menu_help"
                    )
                    .setLabel(
                        "Help"
                    )
                    .setEmoji(
                        "📖"
                    )
                    .setStyle(
                        ButtonStyle.Secondary
                    )
            )
    ];
}

/*
 * ============================================================
 * HOME BUTTONS
 * ============================================================
 */

export function homeButtons() {
    return [
        new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(
                        "menu_deploy"
                    )
                    .setLabel(
                        "Deploy"
                    )
                    .setEmoji(
                        "🚀"
                    )
                    .setStyle(
                        ButtonStyle.Primary
                    ),

                new ButtonBuilder()
                    .setCustomId(
                        "menu_servers"
                    )
                    .setLabel(
                        "Servers"
                    )
                    .setEmoji(
                        "🖥️"
                    )
                    .setStyle(
                        ButtonStyle.Secondary
                    ),

                new ButtonBuilder()
                    .setCustomId(
                        "menu_help"
                    )
                    .setLabel(
                        "Help"
                    )
                    .setEmoji(
                        "📖"
                    )
                    .setStyle(
                        ButtonStyle.Secondary
                    )
            )
    ];
}

/*
 * ============================================================
 * BACK BUTTON
 * ============================================================
 */

export function backButton(
    customId = "menu_home"
) {
    return new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId(
                    customId
                )
                .setLabel(
                    "Back"
                )
                .setEmoji(
                    "↩️"
                )
                .setStyle(
                    ButtonStyle.Secondary
                )
        );
}

/*
 * ============================================================
 * SERVER MANAGEMENT
 * ============================================================
 */

export function serverManagementButtons(
    serverId
) {
    return [
        new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(
                        `server_start:${serverId}`
                    )
                    .setLabel(
                        "Start"
                    )
                    .setEmoji(
                        "▶️"
                    )
                    .setStyle(
                        ButtonStyle.Success
                    ),

                new ButtonBuilder()
                    .setCustomId(
                        `server_stop:${serverId}`
                    )
                    .setLabel(
                        "Stop"
                    )
                    .setEmoji(
                        "⏹️"
                    )
                    .setStyle(
                        ButtonStyle.Danger
                    ),

                new ButtonBuilder()
                    .setCustomId(
                        `server_restart:${serverId}`
                    )
                    .setLabel(
                        "Restart"
                    )
                    .setEmoji(
                        "🔄"
                    )
                    .setStyle(
                        ButtonStyle.Primary
                    )
            ),

        new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(
                        `server_info:${serverId}`
                    )
                    .setLabel(
                        "Server Info"
                    )
                    .setEmoji(
                        "📊"
                    )
                    .setStyle(
                        ButtonStyle.Secondary
                    ),

                new ButtonBuilder()
                    .setCustomId(
                        `server_rename:${serverId}`
                    )
                    .setLabel(
                        "Rename"
                    )
                    .setEmoji(
                        "✏️"
                    )
                    .setStyle(
                        ButtonStyle.Secondary
                    ),

                new ButtonBuilder()
                    .setCustomId(
                        `server_delete:${serverId}`
                    )
                    .setLabel(
                        "Delete"
                    )
                    .setEmoji(
                        "🗑️"
                    )
                    .setStyle(
                        ButtonStyle.Danger
                    )
            ),

        new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(
                        "server_back"
                    )
                    .setLabel(
                        "Back"
                    )
                    .setEmoji(
                        "↩️"
                    )
                    .setStyle(
                        ButtonStyle.Secondary
                    )
            )
    ];
}

/*
 * ============================================================
 * SERVER SELECTION
 * ============================================================
 */

export function serverSelectMenu(
    servers = []
) {
    const options =
        servers
            .slice(0, 25)
            .map(
                server => ({
                    label:
                        String(
                            server.name ||
                            `Server ${server.id}`
                        ).slice(
                            0,
                            100
                        ),

                    description:
                        `Server ID: ${server.id}`
                            .slice(
                                0,
                                100
                            ),

                    value:
                        String(
                            server.id
                        ),

                    emoji:
                        "🖥️"
                })
            );

    if (!options.length) {
        return null;
    }

    return new ActionRowBuilder()
        .addComponents(
            new StringSelectMenuBuilder()
                .setCustomId(
                    "server_select"
                )
                .setPlaceholder(
                    "Select a server"
                )
                .addOptions(
                    options
                )
        );
}

/*
 * ============================================================
 * PLAN SELECTION
 * ============================================================
 */

export function planSelectMenu(
    plans = []
) {
    const options =
        plans
            .slice(0, 25)
            .map(
                plan => ({
                    label:
                        String(
                            plan.name ||
                            plan.id
                        ).slice(
                            0,
                            100
                        ),

                    description:
                        `${Number(
                            plan.price ||
                            0
                        ).toLocaleString()} coins`
                            .slice(
                                0,
                                100
                            ),

                    value:
                        String(
                            plan.id
                        ),

                    emoji:
                        plan.emoji ||
                        "📦"
                })
            );

    if (!options.length) {
        return null;
    }

    return new ActionRowBuilder()
        .addComponents(
            new StringSelectMenuBuilder()
                .setCustomId(
                    "plan_select"
                )
                .setPlaceholder(
                    "Choose your hosting plan"
                )
                .addOptions(
                    options
                )
        );
}

/*
 * ============================================================
 * DEPLOYMENT CONFIRMATION
 * ============================================================
 */

export function deploymentConfirmButtons() {
    return new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId(
                    "deploy_confirm"
                )
                .setLabel(
                    "Confirm Deployment"
                )
                .setEmoji(
                    "🚀"
                )
                .setStyle(
                    ButtonStyle.Success
                ),

            new ButtonBuilder()
                .setCustomId(
                    "deploy_cancel"
                )
                .setLabel(
                    "Cancel"
                )
                .setEmoji(
                    "✕"
                )
                .setStyle(
                    ButtonStyle.Danger
                )
        );
}

/*
 * ============================================================
 * DELETE CONFIRMATION
 * ============================================================
 */

export function deleteConfirmationButtons(
    serverId
) {
    return new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId(
                    `delete_confirm:${serverId}`
                )
                .setLabel(
                    "Delete Server"
                )
                .setEmoji(
                    "🗑️"
                )
                .setStyle(
                    ButtonStyle.Danger
                ),

            new ButtonBuilder()
                .setCustomId(
                    `delete_cancel:${serverId}`
                )
                .setLabel(
                    "Cancel"
                )
                .setEmoji(
                    "✕"
                )
                .setStyle(
                    ButtonStyle.Secondary
                )
        );
}

/*
 * ============================================================
 * ECONOMY
 * ============================================================
 */

export function economyButtons() {
    return [
        new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(
                        "economy_balance"
                    )
                    .setLabel(
                        "Balance"
                    )
                    .setEmoji(
                        "🪙"
                    )
                    .setStyle(
                        ButtonStyle.Primary
                    ),

                new ButtonBuilder()
                    .setCustomId(
                        "economy_pay"
                    )
                    .setLabel(
                        "Pay"
                    )
                    .setEmoji(
                        "💸"
                    )
                    .setStyle(
                        ButtonStyle.Success
                    ),

                new ButtonBuilder()
                    .setCustomId(
                        "economy_redeem"
                    )
                    .setLabel(
                        "Redeem"
                    )
                    .setEmoji(
                        "🎟️"
                    )
                    .setStyle(
                        ButtonStyle.Secondary
                    )
            ),

        backButton(
            "menu_home"
        )
    ];
}

/*
 * ============================================================
 * AI BUTTONS
 * ============================================================
 */

export function aiButtons() {
    return [
        new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(
                        "ai_status"
                    )
                    .setLabel(
                        "AI Status"
                    )
                    .setEmoji(
                        "🤖"
                    )
                    .setStyle(
                        ButtonStyle.Primary
                    ),

                new ButtonBuilder()
                    .setCustomId(
                        "ai_history"
                    )
                    .setLabel(
                        "History"
                    )
                    .setEmoji(
                        "📜"
                    )
                    .setStyle(
                        ButtonStyle.Secondary
                    ),

                new ButtonBuilder()
                    .setCustomId(
                        "ai_reset"
                    )
                    .setLabel(
                        "Reset"
                    )
                    .setEmoji(
                        "🔄"
                    )
                    .setStyle(
                        ButtonStyle.Danger
                    )
            )
    ];
}

/*
 * ============================================================
 * ACCOUNT BUTTONS
 * ============================================================
 */

export function accountButtons() {
    return [
        new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(
                        "account_info"
                    )
                    .setLabel(
                        "Account Info"
                    )
                    .setEmoji(
                        "👤"
                    )
                    .setStyle(
                        ButtonStyle.Primary
                    ),

                new ButtonBuilder()
                    .setCustomId(
                        "account_resources"
                    )
                    .setLabel(
                        "Resources"
                    )
                    .setEmoji(
                        "📊"
                    )
                    .setStyle(
                        ButtonStyle.Secondary
                    )
            ),

        backButton(
            "menu_home"
        )
    ];
}

/*
 * ============================================================
 * PAGINATION
 * ============================================================
 */

export function paginationButtons(
    prefix = "servers",
    page = 1,
    totalPages = 1
) {
    const current =
        Math.max(
            1,
            Number(page) || 1
        );

    const total =
        Math.max(
            1,
            Number(totalPages) || 1
        );

    return new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId(
                    `${prefix}_previous:${current}`
                )
                .setLabel(
                    "Previous"
                )
                .setEmoji(
                    "⬅️"
                )
                .setStyle(
                    ButtonStyle.Secondary
                )
                .setDisabled(
                    current <= 1
                ),

            new ButtonBuilder()
                .setCustomId(
                    `${prefix}_page:${current}`
                )
                .setLabel(
                    `Page ${current}/${total}`
                )
                .setStyle(
                    ButtonStyle.Secondary
                )
                .setDisabled(
                    true
                ),

            new ButtonBuilder()
                .setCustomId(
                    `${prefix}_next:${current}`
                )
                .setLabel(
                    "Next"
                )
                .setEmoji(
                    "➡️"
                )
                .setStyle(
                    ButtonStyle.Secondary
                )
                .setDisabled(
                    current >= total
                )
        );
}

/*
 * ============================================================
 * STATUS BUTTONS
 * ============================================================
 */

export function serverPowerButtons(
    serverId
) {
    return new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId(
                    `server_start:${serverId}`
                )
                .setLabel(
                    "Start"
                )
                .setEmoji(
                    "▶️"
                )
                .setStyle(
                    ButtonStyle.Success
                ),

            new ButtonBuilder()
                .setCustomId(
                    `server_stop:${serverId}`
                )
                .setLabel(
                    "Stop"
                )
                .setEmoji(
                    "⏹️"
                )
                .setStyle(
                    ButtonStyle.Danger
                ),

            new ButtonBuilder()
                .setCustomId(
                    `server_restart:${serverId}`
                )
                .setLabel(
                    "Restart"
                )
                .setEmoji(
                    "🔄"
                )
                .setStyle(
                    ButtonStyle.Primary
                )
        );
}

/*
 * ============================================================
 * DISABLE COMPONENTS
 * ============================================================
 */

export function disableComponents(
    components = []
) {
    return components.map(
        row => {
            const newRow =
                ActionRowBuilder.from(
                    row
                );

            newRow.components =
                newRow.components.map(
                    component => {
                        try {
                            const button =
                                ButtonBuilder.from(
                                    component
                                );

                            button.setDisabled(
                                true
                            );

                            return button;
                        } catch {
                            return component;
                        }
                    }
                );

            return newRow;
        }
    );
}

/*
 * ============================================================
 * DEFAULT EXPORT
 * ============================================================
 */

export default {
    mainMenuButtons,
    homeButtons,
    backButton,
    serverManagementButtons,
    serverSelectMenu,
    planSelectMenu,
    deploymentConfirmButtons,
    deleteConfirmationButtons,
    economyButtons,
    aiButtons,
    accountButtons,
    paginationButtons,
    serverPowerButtons,
    disableComponents
};

/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */