/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */

import {
    EmbedBuilder
} from "discord.js";

import {
    THEME,
    getStatusDisplay
} from "./theme.js";

/*
 * ============================================================
 * CORE EMBED
 * ============================================================
 */

export function createEmbed({
    title,
    description,
    color,
    fields = [],
    footer,
    timestamp = true,
    thumbnail,
    image,
    author
} = {}) {
    const embed =
        new EmbedBuilder()
            .setColor(
                color ??
                THEME.colors.primary
            );

    if (title) {
        embed.setTitle(
            String(title)
                .slice(0, 256)
        );
    }

    if (description) {
        embed.setDescription(
            String(description)
                .slice(0, 4096)
        );
    }

    if (
        Array.isArray(fields) &&
        fields.length
    ) {
        embed.addFields(
            fields
                .slice(0, 25)
                .map(field => ({
                    name: String(
                        field.name ??
                        "Information"
                    ).slice(0, 256),
                    value: String(
                        field.value ??
                        "-"
                    ).slice(0, 1024),
                    inline:
                        Boolean(
                            field.inline
                        )
                }))
        );
    }

    embed.setFooter({
        text:
            typeof footer === "string"
                ? footer
                : footer?.text ||
                  THEME.footer
    });

    if (author) {
        embed.setAuthor(author);
    }

    if (thumbnail) {
        embed.setThumbnail(
            thumbnail
        );
    }

    if (image) {
        embed.setImage(
            image
        );
    }

    if (timestamp) {
        embed.setTimestamp();
    }

    return embed;
}

/*
 * ============================================================
 * SUCCESS
 * ============================================================
 */

export function successEmbed(
    title,
    description
) {
    return createEmbed({
        title:
            `${THEME.emojis.success} ${title}`,
        description,
        color:
            THEME.colors.success
    });
}

/*
 * ============================================================
 * ERROR
 * ============================================================
 */

export function errorEmbed(
    title,
    description
) {
    return createEmbed({
        title:
            `${THEME.emojis.error} ${title}`,
        description,
        color:
            THEME.colors.danger
    });
}

/*
 * ============================================================
 * WARNING
 * ============================================================
 */

export function warningEmbed(
    title,
    description
) {
    return createEmbed({
        title:
            `${THEME.emojis.warning} ${title}`,
        description,
        color:
            THEME.colors.warning
    });
}

/*
 * ============================================================
 * INFORMATION
 * ============================================================
 */

export function infoEmbed(
    title,
    description
) {
    return createEmbed({
        title:
            `${THEME.emojis.info} ${title}`,
        description,
        color:
            THEME.colors.info
    });
}

/*
 * ============================================================
 * LOADING
 * ============================================================
 */

export function loadingEmbed(
    title,
    description
) {
    return createEmbed({
        title:
            `${THEME.emojis.loading} ${title}`,
        description,
        color:
            THEME.colors.primary
    });
}

/*
 * ============================================================
 * SERVER EMBED
 * ============================================================
 */

export function serverEmbed(
    serverOrName,
    options = {}
) {
    let server;
    let fields = [];

    if (
        typeof serverOrName ===
        "string"
    ) {
        server = {
            name:
                serverOrName,
            id:
                options.id ||
                options.serverId
        };

        fields =
            Object.entries(
                options
            )
                .filter(
                    ([key]) =>
                        ![
                            "id",
                            "serverId",
                            "title",
                            "description"
                        ].includes(key)
                )
                .map(
                    ([name, value]) => ({
                        name:
                            String(name),
                        value:
                            `\`${String(
                                value ??
                                "Unknown"
                            )}\``,
                        inline: true
                    })
                );
    } else {
        server =
            serverOrName ||
            {};

        fields = [
            {
                name: "🖥️ Server Name",
                value:
                    `\`${server.name || "Unknown"}\``,
                inline: true
            },
            {
                name: "🆔 Server ID",
                value:
                    `\`${server.id ??
                        server.pterodactyl_id ??
                        "Unknown"}\``,
                inline: true
            }
        ];

        if (
            server.identifier ||
            server.pterodactyl_identifier
        ) {
            fields.push({
                name:
                    "🔑 Identifier",
                value:
                    `\`${server.identifier ??
                        server.pterodactyl_identifier}\``,
                inline: true
            });
        }

        if (server.plan) {
            fields.push({
                name: "📦 Plan",
                value:
                    `\`${server.plan}\``,
                inline: true
            });
        }

        if (server.node) {
            fields.push({
                name: "🌐 Node",
                value:
                    `\`${server.node}\``,
                inline: true
            });
        }

        if (server.status) {
            fields.push({
                name: "📡 Status",
                value:
                    getStatusDisplay(
                        server.status
                    ),
                inline: true
            });
        }

        if (
            server.ram !==
            undefined
        ) {
            fields.push({
                name: "🧠 RAM",
                value:
                    `\`${server.ram} MB\``,
                inline: true
            });
        }

        if (
            server.cpu !==
            undefined
        ) {
            fields.push({
                name: "⚙️ CPU",
                value:
                    `\`${server.cpu}%\``,
                inline: true
            });
        }

        if (
            server.disk !==
            undefined
        ) {
            fields.push({
                name: "💾 Disk",
                value:
                    `\`${server.disk} MB\``,
                inline: true
            });
        }
    }

    return createEmbed({
        title:
            options.title ||
            `${THEME.emojis.server} Server Information`,
        description:
            server?.description ||
            options.description,
        color:
            THEME.colors.server,
        fields
    });
}

/*
 * ============================================================
 * SERVER RESOURCE EMBED
 * ============================================================
 */

export function resourceEmbed(
    serverOrName,
    resourcesOrId = {},
    status = null,
    legacyResources = null
) {
    let server;
    let resources;
    let liveStatus =
        status;

    if (
        typeof serverOrName ===
        "string"
    ) {
        server = {
            name:
                serverOrName,
            id:
                resourcesOrId
        };

        resources =
            legacyResources ||
            {};
    } else {
        server =
            serverOrName ||
            {};

        resources =
            resourcesOrId ||
            {};
    }

    const memory =
        Number(
            resources.memory_bytes ||
            resources.memory ||
            0
        );

    const cpu =
        Number(
            resources.cpu_absolute ||
            resources.cpu ||
            0
        );

    const disk =
        Number(
            resources.disk_bytes ||
            resources.disk ||
            0
        );

    const networkRx =
        Number(
            resources.network_rx_bytes ||
            0
        );

    const networkTx =
        Number(
            resources.network_tx_bytes ||
            0
        );

    liveStatus =
        liveStatus ||
        resources.current_state ||
        resources.state ||
        "Unknown";

    return createEmbed({
        title:
            `${THEME.emojis.resources} ${
                server.name ||
                "Server"
            } Resources`,
        color:
            THEME.colors.server,
        fields: [
            {
                name: "📡 Status",
                value:
                    getStatusDisplay(
                        liveStatus
                    ),
                inline: true
            },
            {
                name: "⚙️ CPU",
                value:
                    `${cpu.toFixed(2)}%`,
                inline: true
            },
            {
                name: "🧠 Memory",
                value:
                    formatBytes(
                        memory
                    ),
                inline: true
            },
            {
                name: "💾 Disk",
                value:
                    formatBytes(
                        disk
                    ),
                inline: true
            },
            {
                name: "📥 Network",
                value:
                    formatBytes(
                        networkRx
                    ),
                inline: true
            },
            {
                name: "📤 Upload",
                value:
                    formatBytes(
                        networkTx
                    ),
                inline: true
            }
        ]
    });
}

/*
 * ============================================================
 * USER PROFILE
 * ============================================================
 */

export function profileEmbed(
    user,
    discordUser = null
) {
    const username =
        user?.username ||
        discordUser?.username ||
        "User";

    const discordId =
        user?.discord_id ||
        discordUser?.id ||
        "Unknown";

    const coins =
        Number(
            user?.coins ||
            0
        );

    const pteroId =
        user?.pterodactyl_id ||
        user?.pterodactylId ||
        "Not linked";

    return createEmbed({
        title:
            `👤 ${username}`,
        description:
            "Your PetroBot account overview.",
        color:
            THEME.colors.primary,
        fields: [
            {
                name: "🪪 Discord ID",
                value:
                    `\`${discordId}\``,
                inline: true
            },
            {
                name: "🪙 Coins",
                value:
                    `\`${coins.toLocaleString()}\``,
                inline: true
            },
            {
                name: "🖥️ Pterodactyl",
                value:
                    `\`${pteroId}\``,
                inline: true
            }
        ]
    });
}

/*
 * ============================================================
 * BALANCE
 * ============================================================
 */

export function balanceEmbed(
    user,
    balance
) {
    const value =
        typeof balance ===
        "object"
            ? Number(
                balance?.balance ||
                0
            )
            : Number(
                balance ||
                0
            );

    return createEmbed({
        title:
            `${THEME.emojis.coins} Coin Balance`,
        description:
            [
                `**${user?.username || "User"}**`,
                "",
                `You currently have`,
                `# 🪙 ${value.toLocaleString()} coins`,
                "",
                "Use `!buy <planid>` to spend your coins on hosting."
            ].join("\n"),
        color:
            THEME.colors.economy
    });
}

/*
 * ============================================================
 * RESOURCES
 * ============================================================
 */

export function accountResourcesEmbed(
    resources = {}
) {
    return createEmbed({
        title:
            "📊 Available Resources",
        description:
            "Resources currently available on your PetroBot account.",
        color:
            THEME.colors.hosting,
        fields: [
            {
                name: "🧠 RAM",
                value:
                    `**${resources.ram ?? 0} GB**`,
                inline: true
            },
            {
                name: "⚙️ CPU",
                value:
                    `**${resources.cpu ?? 0}%**`,
                inline: true
            },
            {
                name: "💾 Disk",
                value:
                    `**${resources.disk ?? 0} GB**`,
                inline: true
            },
            {
                name: "🌐 Allocations",
                value:
                    `**${resources.allocations ?? 0}**`,
                inline: true
            },
            {
                name: "🗄️ Databases",
                value:
                    `**${resources.databases ?? 0}**`,
                inline: true
            },
            {
                name: "💾 Backups",
                value:
                    `**${resources.backups ?? 0}**`,
                inline: true
            },
            {
                name: "🖥️ Server Slots",
                value:
                    `**${resources.serverSlots ?? 0}**`,
                inline: true
            }
        ]
    });
}

/*
 * ============================================================
 * DEPLOYMENT SUCCESS
 * ============================================================
 */

export function deploymentSuccessEmbed(
    server
) {
    return createEmbed({
        title:
            "🚀 Server Deployed Successfully",
        description:
            [
                "Your Minecraft server has been created.",
                "",
                "The server resources have been allocated to this deployment."
            ].join("\n"),
        color:
            THEME.colors.success,
        fields: [
            {
                name: "🖥️ Server",
                value:
                    `\`${server.name || "Unknown"}\``,
                inline: true
            },
            {
                name: "🆔 Server ID",
                value:
                    `\`${server.id ??
                        server.pterodactyl_id ??
                        "Unknown"}\``,
                inline: true
            },
            {
                name: "🔑 Identifier",
                value:
                    `\`${server.pterodactyl_identifier ??
                        server.identifier ??
                        "Unknown"}\``,
                inline: true
            },
            {
                name: "🌐 Node",
                value:
                    `\`${server.node || "Unknown"}\``,
                inline: true
            }
        ]
    });
}

/*
 * ============================================================
 * DEPLOYMENT FAILED
 * ============================================================
 */

export function deploymentFailedEmbed(
    reason
) {
    return createEmbed({
        title:
            "🚨 Deployment Failed",
        description:
            [
                "The server could not be deployed.",
                "",
                "**Reason**",
                `> ${reason || "Unknown error"}`,
                "",
                "No resources should be consumed when deployment fails."
            ].join("\n"),
        color:
            THEME.colors.danger
    });
}

/*
 * ============================================================
 * CONFIRMATION
 * ============================================================
 */

export function confirmationEmbed(
    title,
    description
) {
    return createEmbed({
        title:
            `⚠️ ${title}`,
        description,
        color:
            THEME.colors.warning
    });
}

/*
 * ============================================================
 * AI EMBED
 * ============================================================
 */

export function aiEmbed(
    title,
    description
) {
    return createEmbed({
        title:
            `🤖 ${title || "PetroAI"}`,
        description,
        color:
            THEME.colors.ai
    });
}

/*
 * ============================================================
 * PLAN EMBED
 * ============================================================
 */

export function planEmbed(
    plan
) {
    const ram =
        Number(
            plan?.ram ||
            0
        ) / 1024;

    const disk =
        Number(
            plan?.disk ||
            0
        ) / 1024;

    return createEmbed({
        title:
            `${plan?.emoji || "📦"} ${plan?.name || "Hosting Plan"}`,
        description:
            plan?.description ||
            "Minecraft hosting plan.",
        color:
            THEME.colors.hosting,
        fields: [
            {
                name: "🧠 RAM",
                value:
                    `**${ram} GB**`,
                inline: true
            },
            {
                name: "⚙️ CPU",
                value:
                    `**${plan?.cpu || 0}%**`,
                inline: true
            },
            {
                name: "💾 Disk",
                value:
                    `**${disk} GB**`,
                inline: true
            },
            {
                name: "🌐 Allocations",
                value:
                    `**${plan?.allocations || 0}**`,
                inline: true
            },
            {
                name: "🗄️ Databases",
                value:
                    `**${plan?.databases || 0}**`,
                inline: true
            },
            {
                name: "💾 Backups",
                value:
                    `**${plan?.backups || 0}**`,
                inline: true
            },
            {
                name: "🖥️ Server Slots",
                value:
                    `**${plan?.serverSlots || 0}**`,
                inline: true
            },
            {
                name: "🪙 Price",
                value:
                    `# ${Number(
                        plan?.price ||
                        0
                    ).toLocaleString()} coins`,
                inline: false
            }
        ]
    });
}

/*
 * ============================================================
 * HELP
 * ============================================================
 */

export function helpEmbed(
    commands = []
) {
    const fields =
        commands
            .slice(0, 20)
            .map(command => ({
                name:
                    `\`${command.name}\``,
                value:
                    command.description ||
                    "No description provided.",
                inline: false
            }));

    return createEmbed({
        title:
            "📖 PetroBot Help",
        description:
            [
                "Welcome to **PetroBot**.",
                "",
                "Manage your Minecraft hosting, resources, economy and servers from Discord."
            ].join("\n"),
        color:
            THEME.colors.primary,
        fields
    });
}

/*
 * ============================================================
 * FORMATTERS
 * ============================================================
 */

export function formatBytes(
    bytes,
    decimals = 2
) {
    if (
        !Number.isFinite(
            Number(bytes)
        ) ||
        Number(bytes) <= 0
    ) {
        return "0 B";
    }

    const units = [
        "B",
        "KB",
        "MB",
        "GB",
        "TB",
        "PB"
    ];

    const index =
        Math.min(
            Math.floor(
                Math.log(
                    Number(bytes)
                ) /
                Math.log(1024)
            ),
            units.length - 1
        );

    const value =
        Number(bytes) /
        Math.pow(
            1024,
            index
        );

    return `${value.toFixed(
        decimals
    )} ${units[index]}`;
}

export function formatCoins(
    amount
) {
    return Number(
        amount || 0
    ).toLocaleString();
}

export function formatUser(
    user
) {
    if (!user) {
        return "Unknown User";
    }

    return user.username
        ? `${user.username} (${user.id})`
        : user.id;
}

/*
 * ============================================================
 * EXPORT
 * ============================================================
 */

export default {
    createEmbed,
    successEmbed,
    errorEmbed,
    warningEmbed,
    infoEmbed,
    loadingEmbed,
    serverEmbed,
    resourceEmbed,
    profileEmbed,
    balanceEmbed,
    accountResourcesEmbed,
    deploymentSuccessEmbed,
    deploymentFailedEmbed,
    confirmationEmbed,
    aiEmbed,
    planEmbed,
    helpEmbed,
    formatBytes,
    formatCoins,
    formatUser
};

/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */