/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */

import config from "../config.js";

function normalizeId(id) {
    return String(id || "").trim();
}

function getAdminIds() {
    const ids = config.BOT_ADMIN_IDS || "";

    if (Array.isArray(ids)) {
        return ids
            .map(normalizeId)
            .filter(Boolean);
    }

    return String(ids)
        .split(",")
        .map(normalizeId)
        .filter(Boolean);
}

export function isAdmin(userId) {
    const id = normalizeId(userId);

    if (!id) {
        return false;
    }

    return getAdminIds().includes(id);
}

export function requireAdmin(userId) {
    if (!isAdmin(userId)) {
        return {
            allowed: false,
            message: "❌ You do not have permission to use this command."
        };
    }

    return {
        allowed: true,
        message: null
    };
}

export function isOwner(userId) {
    const id = normalizeId(userId);
    const ownerId = normalizeId(config.OWNER_ID);

    return Boolean(id && ownerId && id === ownerId);
}

export function hasPermission(userId, permission) {
    if (isOwner(userId) || isAdmin(userId)) {
        return true;
    }

    const permissions = config.PERMISSIONS || {};

    if (!permission) {
        return false;
    }

    const allowedUsers = permissions[permission];

    if (!Array.isArray(allowedUsers)) {
        return false;
    }

    return allowedUsers
        .map(normalizeId)
        .includes(normalizeId(userId));
}

export default {
    isAdmin,
    requireAdmin,
    isOwner,
    hasPermission
};

/*
 * ============================================================
 * End of permissions.js
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */