/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */

export const THEME = {
    brand: "PetroBot",
    developer: "HyperForgeX",
    footer: "HyperForgeX • PetroBot",

    colors: {
        primary: 0x7C3AED,
        secondary: 0x5865F2,
        success: 0x57F287,
        danger: 0xED4245,
        warning: 0xFEE75C,
        info: 0x5865F2,
        neutral: 0x2B2D31,
        dark: 0x18181B,
        economy: 0xF59E0B,
        hosting: 0x8B5CF6,
        ai: 0x06B6D4,
        server: 0x3B82F6
    },

    emojis: {
        success: "✅",
        error: "❌",
        warning: "⚠️",
        info: "ℹ️",
        server: "🖥️",
        hosting: "🚀",
        resources: "📊",
        ram: "🧠",
        cpu: "⚙️",
        disk: "💾",
        network: "🌐",
        coins: "🪙",
        payment: "💸",
        redeem: "🎟️",
        plan: "📦",
        user: "👤",
        admin: "🛡️",
        settings: "⚙️",
        ai: "🤖",
        warning: "⚠️",
        delete: "🗑️",
        edit: "✏️",
        loading: "⏳",
        online: "🟢",
        offline: "🔴",
        pending: "🟡",
        start: "▶️",
        stop: "⏹️",
        restart: "🔄",
        back: "↩️",
        next: "➡️",
        previous: "⬅️",
        check: "✓",
        cross: "✕"
    },

    status: {
        online: "🟢 Online",
        offline: "🔴 Offline",
        starting: "🟡 Starting",
        stopping: "🟠 Stopping",
        restarting: "🔄 Restarting",
        suspended: "🔴 Suspended",
        installing: "🟡 Installing",
        reinstalling: "🟡 Reinstalling",
        unknown: "⚪ Unknown"
    }
};

export function getStatusDisplay(status) {
    const value =
        String(status || "")
            .toLowerCase()
            .trim();

    if (
        value === "running" ||
        value === "online"
    ) {
        return THEME.status.online;
    }

    if (
        value === "offline" ||
        value === "stopped"
    ) {
        return THEME.status.offline;
    }

    if (
        value === "starting"
    ) {
        return THEME.status.starting;
    }

    if (
        value === "stopping"
    ) {
        return THEME.status.stopping;
    }

    if (
        value === "restarting"
    ) {
        return THEME.status.restarting;
    }

    if (
        value === "suspended"
    ) {
        return THEME.status.suspended;
    }

    if (
        value === "installing"
    ) {
        return THEME.status.installing;
    }

    if (
        value === "reinstalling"
    ) {
        return THEME.status.reinstalling;
    }

    return THEME.status.unknown;
}

export function divider(length = 30) {
    return "─".repeat(
        Math.max(
            5,
            Math.min(length, 60)
        )
    );
}

export function box(title, lines = []) {
    const content = Array.isArray(lines)
        ? lines
        : [String(lines)];

    return [
        `╭${divider(30)}╮`,
        `│ ${String(title).slice(0, 28).padEnd(28)} │`,
        `├${divider(30)}┤`,
        ...content.map(
            line =>
                `│ ${String(line).slice(0, 28).padEnd(28)} │`
        ),
        `╰${divider(30)}╯`
    ].join("\n");
}

export default THEME;

/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */