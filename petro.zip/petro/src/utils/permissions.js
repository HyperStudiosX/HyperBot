/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */

import { PermissionFlagsBits } from "discord.js";
import { config } from "../config.js";

function getUserId(subject) {
    if (typeof subject === "string" || typeof subject === "number") return String(subject);
    return String(subject?.user?.id || subject?.author?.id || "");
}

export function isBotAdmin(subject) {
    const userId = getUserId(subject);
    if (userId && config.botAdminIds.includes(userId)) return true;
    return Boolean(subject?.member?.permissions?.has?.(PermissionFlagsBits.Administrator));
}

export function isAdmin(subject) {
    return isBotAdmin(subject);
}

export function requireBotAdmin(subject) {
    if (!isBotAdmin(subject)) {
        const error = new Error("You do not have permission to use this command.");
        error.code = "BOT_ADMIN_REQUIRED";
        throw error;
    }
    return true;
}

export function requireAdmin(subject) {
    return requireBotAdmin(subject);
}

export function isOwner(subject) {
    const userId = getUserId(subject);
    return Boolean(userId && config.OWNER_ID && userId === config.OWNER_ID);
}

export function hasPermission(subject) {
    return isOwner(subject) || isBotAdmin(subject);
}

export default { isBotAdmin, isAdmin, requireBotAdmin, requireAdmin, isOwner, hasPermission };

/*
 * ============================================================
 * End of permissions.js
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */
