/* ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================ */

export function formatMB(value) {
  const mb = Number(value);
  if (!Number.isFinite(mb) || mb < 0) return "Unknown";
  if (mb >= 1024) {
    const gb = mb / 1024;
    return `${Number.isInteger(gb) ? gb : gb.toFixed(1)} GB`;
  }
  return `${mb} MB`;
}

export function formatBytes(value) {
  const bytes = Number(value);
  if (!Number.isFinite(bytes) || bytes < 0) return "Unknown";
  const units = ["B", "KB", "MB", "GB", "TB"];
  let size = bytes;
  let index = 0;
  while (size >= 1024 && index < units.length - 1) {
    size /= 1024;
    index += 1;
  }
  return `${Number.isInteger(size) ? size : size.toFixed(1)} ${units[index]}`;
}

export function truncate(text, max = 1000) {
  const value = String(text ?? "");
  return value.length <= max ? value : `${value.slice(0, max - 3)}...`;
}

export function escapeCode(text) {
  return String(text ?? "").replaceAll("`", "\\`");
}

/* ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================ */
