/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */

const plans = [
    {
        id: "plan1",
        name: "Plan 1",
        price: 500,
        ram: 2048,
        cpu: 100,
        disk: 5120,
        allocations: 1,
        databases: 1,
        backups: 1,
        serverSlots: 1,
        description: "2 GB RAM • 100% CPU • 5 GB Disk"
    },
    {
        id: "plan2",
        name: "Plan 2",
        price: 900,
        ram: 4096,
        cpu: 200,
        disk: 10240,
        allocations: 2,
        databases: 2,
        backups: 2,
        serverSlots: 1,
        description: "4 GB RAM • 200% CPU • 10 GB Disk"
    },
    {
        id: "plan3",
        name: "Plan 3",
        price: 1600,
        ram: 8192,
        cpu: 300,
        disk: 20480,
        allocations: 3,
        databases: 3,
        backups: 3,
        serverSlots: 1,
        description: "8 GB RAM • 300% CPU • 20 GB Disk"
    },
    {
        id: "plan4",
        name: "Plan 4",
        price: 3000,
        ram: 16384,
        cpu: 400,
        disk: 40960,
        allocations: 4,
        databases: 4,
        backups: 4,
        serverSlots: 1,
        description: "16 GB RAM • 400% CPU • 40 GB Disk"
    },
    {
        id: "plan5",
        name: "Plan 5",
        price: 5500,
        ram: 32768,
        cpu: 500,
        disk: 81920,
        allocations: 5,
        databases: 5,
        backups: 5,
        serverSlots: 1,
        description: "32 GB RAM • 500% CPU • 80 GB Disk"
    }
];

export function getPlan(planId) {
    if (!planId) {
        return null;
    }

    return plans.find(
        plan =>
            String(plan.id).toLowerCase() ===
            String(planId).trim().toLowerCase()
    ) || null;
}

export function getAllPlans() {
    return [...plans];
}

export { plans };

export default plans;

/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */