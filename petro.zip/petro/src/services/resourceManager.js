/*
 * ============================================================
 * PetroBot V2 - Resource Manager
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 *
 * Central resource-management service for PetroBot V2.
 *
 * Supported resources:
 * - RAM
 * - CPU
 * - Disk
 * - Backups
 * - Allocations
 * - Databases
 * - Server Slots
 *
 * Units:
 * - RAM: MB
 * - CPU: percentage
 * - Disk: MB
 *
 * This service sits between commands/deployment logic and
 * database.js.
 *
 * ============================================================
 */

import database from "../database.js";

/* ============================================================
 * RESOURCE FIELDS
 * ============================================================ */

const RESOURCE_FIELDS = [
    "ram",
    "cpu",
    "disk",
    "backups",
    "allocations",
    "databases",
    "server_slots"
];

/* ============================================================
 * RESOURCE ALIASES
 * ============================================================ */

const RESOURCE_ALIASES = {
    ram: [
        "ram",
        "ramMb",
        "ram_mb",
        "memory"
    ],

    cpu: [
        "cpu",
        "cpuPercent",
        "cpu_percent"
    ],

    disk: [
        "disk",
        "diskMb",
        "disk_mb"
    ],

    backups: [
        "backups",
        "backup"
    ],

    allocations: [
        "allocations",
        "allocation"
    ],

    databases: [
        "databases",
        "database"
    ],

    server_slots: [
        "server_slots",
        "serverSlots",
        "slots",
        "servers"
    ]
};

/* ============================================================
 * RESOURCE LABELS
 * ============================================================ */

const RESOURCE_LABELS = {
    ram:
        "RAM",

    cpu:
        "CPU",

    disk:
        "Disk",

    backups:
        "Backups",

    allocations:
        "Allocations",

    databases:
        "Databases",

    server_slots:
        "Server Slots"
};

/* ============================================================
 * BASIC HELPERS
 * ============================================================ */

function normalizeUserId(
    userId
) {
    const id =
        String(
            userId ??
            ""
        ).trim();

    if (
        !id
    ) {
        throw new Error(
            "Discord user ID is required."
        );
    }

    return id;
}

/* ============================================================
 * READ RESOURCE ALIAS
 * ============================================================ */

function readResourceValue(
    resources,
    field
) {
    const aliases =
        RESOURCE_ALIASES[
            field
        ] ||
        [
            field
        ];

    for (
        const alias of
        aliases
    ) {
        if (
            resources &&
            resources[
                alias
            ] !==
                undefined &&
            resources[
                alias
            ] !==
                null
        ) {
            return resources[
                alias
            ];
        }
    }

    return 0;
}

/* ============================================================
 * RESOURCE NORMALIZATION
 * ============================================================ */

export function normalizeResources(
    resources = {}
) {
    if (
        !resources ||
        typeof resources !==
            "object"
    ) {
        throw new Error(
            "Resources must be an object."
        );
    }

    const output =
        {};

    for (
        const field of
        RESOURCE_FIELDS
    ) {
        const raw =
            readResourceValue(
                resources,
                field
            );

        const value =
            Number(
                raw
            );

        if (
            !Number.isFinite(
                value
            )
        ) {
            throw new Error(
                `Invalid resource value: ${field}`
            );
        }

        if (
            value <
            0
        ) {
            throw new Error(
                `${RESOURCE_LABELS[field]} cannot be negative.`
            );
        }

        if (
            !Number.isInteger(
                value
            )
        ) {
            throw new Error(
                `${RESOURCE_LABELS[field]} must be a whole number.`
            );
        }

        output[
            field
        ] =
            value;
    }

    return output;
}

/* ============================================================
 * NORMALIZE RESOURCE BALANCE
 * ============================================================ */

function normalizeBalance(
    resources = {}
) {
    const normalized =
        normalizeResources(
            resources
        );

    return {
        ram:
            normalized.ram,

        cpu:
            normalized.cpu,

        disk:
            normalized.disk,

        backups:
            normalized.backups,

        allocations:
            normalized.allocations,

        databases:
            normalized.databases,

        server_slots:
            normalized.server_slots,

        /*
         * Compatibility aliases.
         */
        ramMb:
            normalized.ram,

        cpuPercent:
            normalized.cpu,

        diskMb:
            normalized.disk,

        serverSlots:
            normalized.server_slots
    };
}

/* ============================================================
 * ENSURE RESOURCE ACCOUNT
 * ============================================================ */

export function ensureResourceAccount(
    userId,
    username = "User"
) {
    const id =
        normalizeUserId(
            userId
        );

    /*
     * database.createUser() also ensures the corresponding
     * resource row exists.
     */
    database.createUser({
        discordId:
            id,

        username:
            String(
                username ||
                "User"
            )
    });

    return normalizeBalance(
        database.getUserResources(
            id
        )
    );
}

/* ============================================================
 * GET RESOURCES
 * ============================================================ */

export function getResources(
    userId
) {
    const id =
        normalizeUserId(
            userId
        );

    ensureResourceAccount(
        id
    );

    return normalizeBalance(
        database.getUserResources(
            id
        )
    );
}

/* ============================================================
 * GET RAW DATABASE RESOURCES
 * ============================================================ */

export function getRawResources(
    userId
) {
    const id =
        normalizeUserId(
            userId
        );

    ensureResourceAccount(
        id
    );

    return normalizeResources(
        database.getUserResources(
            id
        )
    );
}

/* ============================================================
 * CALCULATE RESOURCE DIFFERENCE
 * ============================================================ */

export function calculateMissingResources(
    available = {},
    required = {}
) {
    const have =
        normalizeResources(
            available
        );

    const need =
        normalizeResources(
            required
        );

    const missing =
        {};

    for (
        const field of
        RESOURCE_FIELDS
    ) {
        if (
            need[field] >
            have[field]
        ) {
            missing[
                field
            ] = {
                required:
                    need[field],

                available:
                    have[field],

                extra:
                    need[field] -
                    have[field]
            };
        }
    }

    return {
        hasMissing:
            Object.keys(
                missing
            ).length >
            0,

        missing
    };
}

/* ============================================================
 * GET MISSING RESOURCES
 *
 * Supports both:
 *
 * getMissingResources(available, required)
 *
 * and:
 *
 * getMissingResources(userId, required)
 *
 * ============================================================
 */

export function getMissingResources(
    availableOrUserId,
    required = {}
) {
    /*
     * Discord IDs are strings. Resource objects are objects.
     */
    if (
        typeof availableOrUserId ===
        "string" ||
        typeof availableOrUserId ===
        "number"
    ) {
        const available =
            getRawResources(
                availableOrUserId
            );

        return calculateMissingResources(
            available,
            required
        );
    }

    return calculateMissingResources(
        availableOrUserId,
        required
    );
}

/* ============================================================
 * HAS ENOUGH RESOURCES
 * ============================================================ */

export function hasEnoughResources(
    userId,
    required = {}
) {
    const id =
        normalizeUserId(
            userId
        );

    const available =
        getRawResources(
            id
        );

    const needed =
        normalizeResources(
            required
        );

    const result =
        calculateMissingResources(
            available,
            needed
        );

    return {
        enough:
            !result.hasMissing,

        available:
            normalizeBalance(
                available
            ),

        required:
            normalizeBalance(
                needed
            ),

        missing:
            result.missing
    };
}

/* ============================================================
 * CHECK RESOURCES
 * ============================================================ */

export function checkResources(
    userId,
    required = {}
) {
    return hasEnoughResources(
        userId,
        required
    );
}

/* ============================================================
 * GET AVAILABLE AFTER RESOURCES
 * ============================================================ */

export function getAvailableAfterResources(
    userId,
    required = {}
) {
    const id =
        normalizeUserId(
            userId
        );

    const available =
        getRawResources(
            id
        );

    const needed =
        normalizeResources(
            required
        );

    const check =
        calculateMissingResources(
            available,
            needed
        );

    if (
        check.hasMissing
    ) {
        const error =
            new Error(
                "Insufficient resources."
            );

        error.code =
            "INSUFFICIENT_RESOURCES";

        error.details =
            check;

        throw error;
    }

    const output =
        {};

    for (
        const field of
        RESOURCE_FIELDS
    ) {
        output[
            field
        ] =
            available[field] -
            needed[field];
    }

    return normalizeBalance(
        output
    );
}

/* ============================================================
 * CONSUME RESOURCES
 * ============================================================ */

export function consumeResources(
    userId,
    required = {},
    description =
        "Resource consumption"
) {
    const id =
        normalizeUserId(
            userId
        );

    const needed =
        normalizeResources(
            required
        );

    /*
     * Never allow consumption without first checking the
     * complete resource balance.
     */
    const check =
        hasEnoughResources(
            id,
            needed
        );

    if (
        !check.enough
    ) {
        const error =
            new Error(
                "Extra resources demanded."
            );

        error.code =
            "INSUFFICIENT_RESOURCES";

        error.details =
            check;

        throw error;
    }

    /*
     * database.removeResources() performs the actual atomic
     * resource deduction and records the resource transaction.
     */
    const result =
        database.removeResources(
            id,
            needed,
            {
                description:
                    String(
                        description ||
                        "Resource consumption"
                    )
            }
        );

    return normalizeBalance(
        result
    );
}

/* ============================================================
 * REMOVE RESOURCES
 * ============================================================ */

export function removeResources(
    userId,
    resources = {},
    description =
        "Resource consumption"
) {
    return consumeResources(
        userId,
        resources,
        description
    );
}

/* ============================================================
 * ADD RESOURCES
 * ============================================================ */

export function addResources(
    userId,
    resources = {},
    description =
        "Resource grant"
) {
    const id =
        normalizeUserId(
            userId
        );

    const values =
        normalizeResources(
            resources
        );

    ensureResourceAccount(
        id
    );

    const result =
        database.addResources(
            id,
            values,
            {
                description:
                    String(
                        description ||
                        "Resource grant"
                    )
            }
        );

    return normalizeBalance(
        result
    );
}

/* ============================================================
 * GRANT RESOURCES
 * ============================================================ */

export function grantResources(
    userId,
    resources = {},
    description =
        "Resource grant"
) {
    return addResources(
        userId,
        resources,
        description
    );
}

/* ============================================================
 * REFUND RESOURCES
 * ============================================================ */

export function refundResources(
    userId,
    resources = {},
    description =
        "Deployment resource refund"
) {
    return addResources(
        userId,
        resources,
        description
    );
}

/* ============================================================
 * SPEND RESOURCES
 * ============================================================ */

export function spendResources(
    userId,
    resources = {},
    description =
        "Resource consumption"
) {
    return consumeResources(
        userId,
        resources,
        description
    );
}

/* ============================================================
 * RESOURCE DIFFERENCE
 * ============================================================ */

export function resourceDifference(
    required = {},
    available = {}
) {
    const need =
        normalizeResources(
            required
        );

    const have =
        normalizeResources(
            available
        );

    const difference =
        {};

    for (
        const field of
        RESOURCE_FIELDS
    ) {
        difference[
            field
        ] =
            Math.max(
                0,
                need[field] -
                have[field]
            );
    }

    return normalizeBalance(
        difference
    );
}

/* ============================================================
 * RESOURCE COMPARISON
 * ============================================================ */

export function resourcesWithin(
    available = {},
    required = {}
) {
    const have =
        normalizeResources(
            available
        );

    const need =
        normalizeResources(
            required
        );

    return RESOURCE_FIELDS.every(
        field =>
            have[field] >=
            need[field]
    );
}

/* ============================================================
 * HAS ANY RESOURCE
 * ============================================================ */

export function hasAnyResource(
    resources = {}
) {
    const normalized =
        normalizeResources(
            resources
        );

    return RESOURCE_FIELDS.some(
        field =>
            normalized[field] >
            0
    );
}

/* ============================================================
 * RESOURCE TOTAL
 * ============================================================ */

export function totalResourceUnits(
    resources = {}
) {
    const normalized =
        normalizeResources(
            resources
        );

    return RESOURCE_FIELDS.reduce(
        (
            total,
            field
        ) =>
            total +
            normalized[field],
        0
    );
}

/* ============================================================
 * FORMAT MB
 * ============================================================ */

export function formatMB(
    value
) {
    const mb =
        Number(
            value ||
            0
        );

    if (
        !Number.isFinite(
            mb
        ) ||
        mb < 0
    ) {
        return "0 MB";
    }

    if (
        mb >=
        1024
    ) {
        const gb =
            mb /
            1024;

        return (
            Number.isInteger(
                gb
            )
                ? `${gb} GB`
                : `${gb.toFixed(1)} GB`
        );
    }

    return `${mb} MB`;
}

/* ============================================================
 * FORMAT RAM
 * ============================================================ */

export function formatRAM(
    value
) {
    return formatMB(
        value
    );
}

/* ============================================================
 * FORMAT DISK
 * ============================================================ */

export function formatDisk(
    value
) {
    return formatMB(
        value
    );
}

/* ============================================================
 * FORMAT CPU
 * ============================================================ */

export function formatCPU(
    value
) {
    const cpu =
        Number(
            value ||
            0
        );

    return `${cpu}%`;
}

/* ============================================================
 * FORMAT RESOURCE LINE
 * ============================================================ */

export function formatResourceLine(
    field,
    value
) {
    switch (
        field
    ) {
        case "ram":
            return `🧠 **RAM:** ${formatRAM(value)}`;

        case "cpu":
            return `⚙️ **CPU:** ${formatCPU(value)}`;

        case "disk":
            return `💾 **Disk:** ${formatDisk(value)}`;

        case "backups":
            return `📦 **Backups:** ${value}`;

        case "allocations":
            return `🌐 **Allocations:** ${value}`;

        case "databases":
            return `🗄️ **Databases:** ${value}`;

        case "server_slots":
            return `🖥️ **Server Slots:** ${value}`;

        default:
            return `**${field}:** ${value}`;
    }
}

/* ============================================================
 * FORMAT RESOURCES
 * ============================================================ */

export function formatResources(
    resources = {}
) {
    const r =
        normalizeResources(
            resources
        );

    return [
        formatResourceLine(
            "ram",
            r.ram
        ),

        formatResourceLine(
            "cpu",
            r.cpu
        ),

        formatResourceLine(
            "disk",
            r.disk
        ),

        formatResourceLine(
            "backups",
            r.backups
        ),

        formatResourceLine(
            "allocations",
            r.allocations
        ),

        formatResourceLine(
            "databases",
            r.databases
        ),

        formatResourceLine(
            "server_slots",
            r.server_slots
        )
    ].join(
        "\n"
    );
}

/* ============================================================
 * FORMAT RESOURCE SHORT
 * ============================================================ */

export function formatResourceShort(
    resources = {}
) {
    const r =
        normalizeResources(
            resources
        );

    return (
        `RAM ${formatRAM(r.ram)} • ` +
        `CPU ${formatCPU(r.cpu)} • ` +
        `Disk ${formatDisk(r.disk)}`
    );
}

/* ============================================================
 * FORMAT RESOURCE BALANCE
 * ============================================================ */

export function formatResourceBalance(
    resources = {}
) {
    return formatResources(
        resources
    );
}

/* ============================================================
 * FORMAT MISSING RESOURCES
 * ============================================================ */

export function formatMissingResources(
    missingResult
) {
    if (
        !missingResult ||
        !missingResult.hasMissing
    ) {
        return "No additional resources are required.";
    }

    const missing =
        missingResult.missing ||
        {};

    const lines =
        [];

    for (
        const field of
        RESOURCE_FIELDS
    ) {
        const value =
            missing[
                field
            ];

        if (
            !value
        ) {
            continue;
        }

        let amount;

        if (
            field ===
            "ram" ||
            field ===
            "disk"
        ) {
            amount =
                formatMB(
                    value.extra
                );
        } else if (
            field ===
            "cpu"
        ) {
            amount =
                `${value.extra}%`;
        } else {
            amount =
                String(
                    value.extra
                );
        }

        lines.push(
            `• **${RESOURCE_LABELS[field]}:** ${amount} more required`
        );
    }

    return lines.length
        ? lines.join(
            "\n"
        )
        : "No additional resources are required.";
}

/* ============================================================
 * BUILD RESOURCE ERROR DETAILS
 * ============================================================ */

export function getResourceErrorDetails(
    userId,
    required = {}
) {
    const check =
        hasEnoughResources(
            userId,
            required
        );

    return {
        enough:
            check.enough,

        available:
            check.available,

        required:
            check.required,

        missing:
            check.missing,

        message:
            formatMissingResources(
                {
                    hasMissing:
                        !check.enough,

                    missing:
                        check.missing
                }
            )
    };
}

/* ============================================================
 * DEPLOYMENT RESOURCE VALIDATION
 * ============================================================ */

export function validateDeploymentResources(
    resources = {}
) {
    const normalized =
        normalizeResources(
            resources
        );

    if (
        normalized.ram <=
        0
    ) {
        throw new Error(
            "RAM must be greater than 0."
        );
    }

    if (
        normalized.cpu <=
        0
    ) {
        throw new Error(
            "CPU must be greater than 0."
        );
    }

    if (
        normalized.disk <=
        0
    ) {
        throw new Error(
            "Disk must be greater than 0."
        );
    }

    if (
        normalized.allocations <
        1
    ) {
        throw new Error(
            "At least 1 allocation is required."
        );
    }

    if (
        normalized.server_slots <
        1
    ) {
        throw new Error(
            "At least 1 server slot is required."
        );
    }

    return normalized;
}

/* ============================================================
 * RESOURCE TRANSACTION HISTORY
 * ============================================================ */

export function getResourceTransactions(
    userId,
    limit = 50
) {
    const id =
        normalizeUserId(
            userId
        );

    return database.getUserResourceTransactions(
        id,
        limit
    );
}

/* ============================================================
 * RESOURCE SUMMARY
 * ============================================================ */

export function getResourceSummary(
    userId
) {
    const id =
        normalizeUserId(
            userId
        );

    const resources =
        getResources(
            id
        );

    return {
        userId:
            id,

        resources,

        formatted:
            formatResources(
                resources
            ),

        short:
            formatResourceShort(
                resources
            )
    };
}

/* ============================================================
 * RESOURCE MANAGER OBJECT
 * ============================================================ */

const resourceManager = {
    normalizeResources,

    ensureResourceAccount,

    getResources,
    getRawResources,

    calculateMissingResources,
    getMissingResources,

    hasEnoughResources,
    checkResources,

    getAvailableAfterResources,

    consumeResources,
    removeResources,

    addResources,
    grantResources,
    refundResources,
    spendResources,

    resourceDifference,
    resourcesWithin,
    hasAnyResource,
    totalResourceUnits,

    formatMB,
    formatRAM,
    formatDisk,
    formatCPU,

    formatResourceLine,
    formatResources,
    formatResourceShort,
    formatResourceBalance,
    formatMissingResources,

    getResourceErrorDetails,
    validateDeploymentResources,

    getResourceTransactions,
    getResourceSummary
};

/* ============================================================
 * DEFAULT EXPORT
 * ============================================================ */

export default resourceManager;

/*
 * ============================================================
 * End of resourceManager.js
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */