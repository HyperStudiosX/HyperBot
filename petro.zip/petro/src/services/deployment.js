/*
 * ============================================================
 * PetroBot V2 - Deployment Service
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 *
 * This service controls the complete PetroBot V2 deployment flow.
 *
 * Deployment flow:
 *
 * 1. Validate Discord user
 * 2. Ensure local database user exists
 * 3. Validate requested resources
 * 4. Check user's available resources
 * 5. Create deployment attempt
 * 6. Consume/reserve user resources
 * 7. Find/create the user's Pterodactyl account
 * 8. Find a usable Pterodactyl node
 * 9. Check node RAM/disk capacity
 * 10. Find a free allocation
 * 11. Create the Pterodactyl server
 * 12. Save the local server record
 * 13. Mark deployment attempt completed
 *
 * Failure handling:
 *
 * - Resources are returned when deployment fails.
 * - Failed deployment attempts are recorded.
 * - If Pterodactyl created a server but a later local step
 *   fails, the newly created Pterodactyl server is removed.
 *
 * Resource units:
 *
 * - RAM: MB
 * - CPU: percentage
 * - Disk: MB
 * - Backups: count
 * - Allocations: count
 * - Databases: count
 * - Server slots: count
 *
 * ============================================================
 */

import database from "../database.js";
import config from "../config.js";
import resourceManager from "./resourceManager.js";
import pterodactyl from "./pterodactyl.js";

/* ============================================================
 * DEFAULT DEPLOYMENT RESOURCE VALUES
 * ============================================================ */

const DEFAULT_REQUEST = {
    ram: 0,
    cpu: 0,
    disk: 0,
    backups: 0,
    allocations: 1,
    databases: 0,
    server_slots: 1
};

/* ============================================================
 * RESOURCE FIELDS
 * ============================================================ */

const RESOURCE_FIELDS = [
    "ram",
    "cpu",
    "disk",
    "backups",
    "allocations",
    "databases",
    "server_slots"
];

/* ============================================================
 * RESOURCE ALIASES
 * ============================================================ */

const RESOURCE_ALIASES = {
    ram: [
        "ram",
        "ramMb",
        "ram_mb",
        "memory"
    ],

    cpu: [
        "cpu",
        "cpuPercent",
        "cpu_percent"
    ],

    disk: [
        "disk",
        "diskMb",
        "disk_mb"
    ],

    backups: [
        "backups",
        "backup"
    ],

    allocations: [
        "allocations",
        "allocation"
    ],

    databases: [
        "databases",
        "database"
    ],

    server_slots: [
        "server_slots",
        "serverSlots",
        "slots",
        "servers"
    ]
};

/* ============================================================
 * BASIC HELPERS
 * ============================================================ */

function asString(
    value,
    fallback = ""
) {
    if (
        value ===
            null ||
        value ===
            undefined
    ) {
        return fallback;
    }

    return String(
        value
    );
}

function getDiscordId(
    data = {}
) {
    return asString(
        data.discordId ??
        data.discord_id ??
        data.userId ??
        data.user_id ??
        data.discordUserId ??
        data.discord_user_id,
        ""
    ).trim();
}

function getUsername(
    data = {}
) {
    return asString(
        data.username ??
        data.user?.username ??
        data.name ??
        "User",
        "User"
    ).trim();
}

function getServerName(
    data = {}
) {
    return asString(
        data.serverName ??
        data.server_name ??
        data.name ??
        "",
        ""
    ).trim();
}

/* ============================================================
 * RESOURCE NORMALIZATION
 * ============================================================ */

function readResourceValue(
    resources,
    field,
    fallback = 0
) {
    const aliases =
        RESOURCE_ALIASES[
            field
        ] || [
            field
        ];

    for (
        const alias of aliases
    ) {
        if (
            resources &&
            resources[alias] !==
                undefined &&
            resources[alias] !==
                null
        ) {
            return resources[alias];
        }
    }

    return fallback;
}

function normalizeResources(
    resources = {}
) {
    const normalized =
        {};

    for (
        const field of
        RESOURCE_FIELDS
    ) {
        const value =
            Number(
                readResourceValue(
                    resources,
                    field,
                    field ===
                        "allocations" ||
                    field ===
                        "server_slots"
                        ? 1
                        : 0
                )
            );

        if (
            !Number.isFinite(
                value
            )
        ) {
            throw new Error(
                `Invalid resource value for ${field}.`
            );
        }

        if (
            value <
            0
        ) {
            throw new Error(
                `Resource value cannot be negative: ${field}.`
            );
        }

        if (
            !Number.isInteger(
                value
            )
        ) {
            throw new Error(
                `Resource value must be a whole number: ${field}.`
            );
        }

        normalized[
            field
        ] = value;
    }

    return normalized;
}

/* ============================================================
 * RESOURCE VALIDATION
 * ============================================================ */

function validateDeploymentResources(
    resources
) {
    if (
        resources.ram <=
        0
    ) {
        throw new Error(
            "RAM must be greater than 0."
        );
    }

    if (
        resources.cpu <=
        0
    ) {
        throw new Error(
            "CPU must be greater than 0."
        );
    }

    if (
        resources.disk <=
        0
    ) {
        throw new Error(
            "Disk must be greater than 0."
        );
    }

    if (
        resources.allocations <
        1
    ) {
        throw new Error(
            "At least 1 allocation is required."
        );
    }

    if (
        resources.server_slots <
        1
    ) {
        throw new Error(
            "At least 1 server slot is required."
        );
    }

    return true;
}

/* ============================================================
 * CONFIGURATION
 * ============================================================ */

function getConfigValue(
    upperName,
    lowerName,
    fallback = undefined
) {
    const upper =
        config?.[
            upperName
        ];

    if (
        upper !==
            undefined &&
        upper !==
            null &&
        String(
            upper
        ).trim() !==
            ""
    ) {
        return upper;
    }

    const lower =
        config?.[
            lowerName
        ];

    if (
        lower !==
            undefined &&
        lower !==
            null &&
        String(
            lower
        ).trim() !==
            ""
    ) {
        return lower;
    }

    return fallback;
}

function getPterodactylConfig() {
    return {
        nodeId:
            Number(
                getConfigValue(
                    "PTERODACTYL_NODE_ID",
                    "pterodactylNodeId",
                    0
                )
            ),

        locationId:
            Number(
                getConfigValue(
                    "PTERODACTYL_LOCATION_ID",
                    "pterodactylLocationId",
                    0
                )
            ),

        nestId:
            Number(
                getConfigValue(
                    "PTERODACTYL_NEST_ID",
                    "pterodactylNestId",
                    0
                )
            ),

        eggId:
            Number(
                getConfigValue(
                    "PTERODACTYL_EGG_ID",
                    "pterodactylEggId",
                    0
                )
            )
    };
}

/* ============================================================
 * PTERODACTYL USERNAME NORMALIZATION
 * ============================================================ */

function buildPterodactylUsername(
    username,
    discordId
) {
    let value =
        asString(
            username,
            "user"
        )
            .trim()
            .replace(
                /[^a-zA-Z0-9_-]/g,
                ""
            )
            .slice(
                0,
                20
            );

    if (
        !value
    ) {
        value =
            `user${discordId.slice(
                -6
            )}`;
    }

    return value;
}

/* ============================================================
 * PTERODACTYL EMAIL
 * ============================================================ */

function buildPterodactylEmail(
    discordId
) {
    const domain =
        asString(
            getConfigValue(
                "PTERODACTYL_USER_EMAIL_DOMAIN",
                "pterodactylUserEmailDomain",
                ""
            )
        ).trim();

    if (
        !domain
    ) {
        const error =
            new Error(
                "PTERODACTYL_USER_EMAIL_DOMAIN is not configured."
            );

        error.code =
            "PTERODACTYL_USER";

        throw error;
    }

    return `${discordId}@${domain}`;
}

/* ============================================================
 * PTERODACTYL USER RESOLUTION
 * ============================================================ */

async function getPterodactylUser(
    discordId,
    username
) {
    const localUser =
        database.getUser(
            discordId
        );

    if (
        localUser?.pterodactyl_id
    ) {
        return Number(
            localUser.pterodactyl_id
        );
    }

    const email =
        buildPterodactylEmail(
            discordId
        );

    try {
        /*
         * Search Pterodactyl first.
         *
         * This prevents duplicate Pterodactyl accounts when
         * the local database does not contain the linked ID.
         */
        const result =
            await pterodactyl.listUsers();

        const users =
            Array.isArray(
                result
            )
                ? result
                : Array.isArray(
                    result?.data
                )
                    ? result.data
                    : [];

        const found =
            users.find(
                user => {
                    const attributes =
                        user?.attributes ??
                        user ??
                        {};

                    return (
                        String(
                            attributes.email ??
                            ""
                        ).toLowerCase() ===
                        email.toLowerCase()
                    );
                }
            );

        if (
            found
        ) {
            const attributes =
                found?.attributes ??
                found;

            const pterodactylId =
                Number(
                    attributes?.id
                );

            if (
                !pterodactylId
            ) {
                throw new Error(
                    "Existing Pterodactyl user has no valid ID."
                );
            }

            database.linkPterodactylUser({
                discordId,
                pterodactylId,
                email,
                username:
                    attributes.username ??
                    buildPterodactylUsername(
                        username,
                        discordId
                    )
            });

            return pterodactylId;
        }

        /*
         * No existing account was found, so create one.
         */
        const pterodactylUsername =
            buildPterodactylUsername(
                username,
                discordId
            );

        const created =
            await pterodactyl.createUser({
                username:
                    pterodactylUsername,

                email,

                firstName:
                    asString(
                        username,
                        "User"
                    )
                        .slice(
                            0,
                            50
                        ) ||
                    "User",

                lastName:
                    "User",

                rootAdmin:
                    false,

                language:
                    "en"
            });

        const attributes =
            created?.attributes ??
            created ??
            {};

        const pterodactylId =
            Number(
                attributes?.id
            );

        if (
            !pterodactylId
        ) {
            const error =
                new Error(
                    "Pterodactyl user creation returned no user ID."
                );

            error.code =
                "PTERODACTYL_USER";

            throw error;
        }

        database.linkPterodactylUser({
            discordId,
            pterodactylId,
            email,
            username:
                attributes.username ??
                pterodactylUsername
        });

        return pterodactylId;
    } catch (
        error
    ) {
        if (
            error?.code ===
            "PTERODACTYL_USER"
        ) {
            throw error;
        }

        const wrapped =
            new Error(
                `Unable to create/find Pterodactyl user: ${
                    error?.message ||
                    error
                }`
            );

        wrapped.code =
            "PTERODACTYL_USER";

        wrapped.cause =
            error;

        throw wrapped;
    }
}

/* ============================================================
 * NODE NORMALIZATION
 * ============================================================ */

function normalizeNode(
    node
) {
    const attributes =
        node?.attributes ??
        node ??
        {};

    const id =
        Number(
            attributes.id ??
            node?.id ??
            0
        );

    const memory =
        Number(
            attributes.memory ??
            node?.memory ??
            0
        );

    const disk =
        Number(
            attributes.disk ??
            node?.disk ??
            0
        );

    return {
        id,

        name:
            asString(
                attributes.name ??
                node?.name ??
                `Node ${id || "Unknown"}`
            ),

        memory:
            Number.isFinite(
                memory
            )
                ? memory
                : 0,

        disk:
            Number.isFinite(
                disk
            )
                ? disk
                : 0,

        maintenanceMode:
            Boolean(
                attributes.maintenance_mode ??
                attributes.maintenanceMode ??
                node?.maintenance_mode ??
                node?.maintenanceMode ??
                false
            ),

        fqdn:
            attributes.fqdn ??
            node?.fqdn ??
            null,

        scheme:
            attributes.scheme ??
            node?.scheme ??
            "https"
    };
}

/* ============================================================
 * ALLOCATION NORMALIZATION
 * ============================================================ */

function normalizeAllocation(
    allocation
) {
    const attributes =
        allocation?.attributes ??
        allocation ??
        {};

    const assignedValue =
        attributes.assigned;

    return {
        id:
            Number(
                attributes.id ??
                allocation?.id ??
                0
            ),

        ip:
            attributes.ip ??
            null,

        alias:
            attributes.alias ??
            null,

        port:
            Number(
                attributes.port ??
                0
            ),

        assigned:
            Boolean(
                assignedValue
            )
    };
}

/* ============================================================
 * SERVER NORMALIZATION
 * ============================================================ */

function normalizePterodactylServer(
    server
) {
    return (
        server?.attributes ??
        server ??
        {}
    );
}

/* ============================================================
 * GET NODES
 * ============================================================ */

async function getNodes() {
    const configured =
        getPterodactylConfig();

    /*
     * If a specific node was configured, try it first.
     */
    if (
        Number.isInteger(
            configured.nodeId
        ) &&
        configured.nodeId >
            0
    ) {
        try {
            const node =
                await pterodactyl.getNode(
                    configured.nodeId
                );

            if (
                node
            ) {
                return [
                    normalizeNode(
                        node
                    )
                ];
            }
        } catch (
            error
        ) {
            console.warn(
                `[Deployment] Configured node ${configured.nodeId} could not be loaded:`,
                error?.message ||
                error
            );
        }
    }

    /*
     * If the configured node was unavailable, discover all nodes.
     */
    const result =
        await pterodactyl.listNodes();

    const nodes =
        Array.isArray(
            result
        )
            ? result
            : Array.isArray(
                result?.data
            )
                ? result.data
                : [];

    return nodes
        .map(
            normalizeNode
        )
        .filter(
            node =>
                node.id >
                0
        );
}

/* ============================================================
 * GET NODE ALLOCATIONS
 * ============================================================ */

async function getAllocations(
    nodeId
) {
    const result =
        await pterodactyl.getNodeAllocations(
            nodeId
        );

    const allocations =
        Array.isArray(
            result
        )
            ? result
            : Array.isArray(
                result?.data
            )
                ? result.data
                : [];

    return allocations
        .map(
            normalizeAllocation
        )
        .filter(
            allocation =>
                allocation.id >
                0
        );
}

/* ============================================================
 * GET NODE SERVERS
 * ============================================================ */

async function getNodeServers(
    nodeId
) {
    const result =
        await pterodactyl.getNodeServers(
            nodeId
        );

    const servers =
        Array.isArray(
            result
        )
            ? result
            : Array.isArray(
                result?.data
            )
                ? result.data
                : [];

    return servers.map(
        normalizePterodactylServer
    );
}

/* ============================================================
 * NODE RESOURCE USAGE
 * ============================================================ */

function getUsedNodeResources(
    servers
) {
    let memory =
        0;

    let disk =
        0;

    let cpu =
        0;

    for (
        const server of
        servers
    ) {
        memory +=
            Number(
                server?.limits?.memory ??
                0
            );

        disk +=
            Number(
                server?.limits?.disk ??
                0
            );

        cpu +=
            Number(
                server?.limits?.cpu ??
                0
            );
    }

    return {
        memory,
        disk,
        cpu
    };
}

/* ============================================================
 * FIND TARGET NODE + ALLOCATION
 * ============================================================ */

async function findTarget(
    resources
) {
    const nodes =
        await getNodes();

    if (
        !nodes.length
    ) {
        const error =
            new Error(
                "No usable Pterodactyl nodes were found."
            );

        error.code =
            "NODE_CAPACITY";

        throw error;
    }

    let foundFreeAllocation =
        false;

    let checkedNodes =
        0;

    let capacityFailures =
        0;

    for (
        const node of
        nodes
    ) {
        checkedNodes++;

        if (
            node.maintenanceMode
        ) {
            continue;
        }

        let allocations;

        try {
            allocations =
                await getAllocations(
                    node.id
                );
        } catch (
            error
        ) {
            console.warn(
                `[Deployment] Failed to read allocations for node ${node.id}:`,
                error?.message ||
                error
            );

            continue;
        }

        /*
         * The deployment requires one free allocation for the
         * server's default port.
         */
        const freeAllocation =
            allocations.find(
                allocation =>
                    !allocation.assigned
            );

        if (
            !freeAllocation
        ) {
            continue;
        }

        foundFreeAllocation =
            true;

        let servers =
            [];

        try {
            servers =
                await getNodeServers(
                    node.id
                );
        } catch (
            error
        ) {
            console.warn(
                `[Deployment] Failed to read servers for node ${node.id}:`,
                error?.message ||
                error
            );

            /*
             * Do not assume the node is empty when the API
             * request failed.
             */
            continue;
        }

        const used =
            getUsedNodeResources(
                servers
            );

        const availableMemory =
            Math.max(
                0,
                node.memory -
                used.memory
            );

        const availableDisk =
            Math.max(
                0,
                node.disk -
                used.disk
            );

        /*
         * CPU is generally not a physical node-capacity value
         * in the same way RAM/disk are represented by Pterodactyl.
         * RAM and disk therefore determine node capacity here.
         */
        if (
            availableMemory <
                resources.ram ||
            availableDisk <
                resources.disk
        ) {
            capacityFailures++;

            continue;
        }

        return {
            node,
            allocation:
                freeAllocation,

            availableMemory,
            availableDisk,

            usedMemory:
                used.memory,

            usedDisk:
                used.disk,

            usedCpu:
                used.cpu
        };
    }

    if (
        !foundFreeAllocation
    ) {
        const error =
            new Error(
                "No free Pterodactyl allocation is available."
            );

        error.code =
            "NO_ALLOCATION";

        throw error;
    }

    const error =
        new Error(
            "No node has enough available capacity for this server."
        );

    error.code =
        "NODE_CAPACITY";

    error.checkedNodes =
        checkedNodes;

    error.capacityFailures =
        capacityFailures;

    throw error;
}

/* ============================================================
 * EGG RESOLUTION
 * ============================================================ */

async function resolveEgg() {
    const {
        nestId,
        eggId
    } =
        getPterodactylConfig();

    if (
        !nestId ||
        nestId <=
            0
    ) {
        throw new Error(
            "PTERODACTYL_NEST_ID must be configured."
        );
    }

    if (
        !eggId ||
        eggId <=
            0
    ) {
        throw new Error(
            "PTERODACTYL_EGG_ID must be configured."
        );
    }

    return {
        nestId,
        eggId
    };
}

/* ============================================================
 * BUILD ENVIRONMENT
 * ============================================================ */

function buildEnvironment(
    overrides = {}
) {
    const environment =
        {};

    const serverJar =
        getConfigValue(
            "PTERODACTYL_SERVER_JARFILE",
            "pterodactylServerJarfile",
            "server.jar"
        );

    const minecraftVersion =
        getConfigValue(
            "PTERODACTYL_MINECRAFT_VERSION",
            "pterodactylMinecraftVersion",
            "latest"
        );

    const timezone =
        getConfigValue(
            "PTERODACTYL_TIMEZONE",
            "pterodactylTimezone",
            "Asia/Kolkata"
        );

    environment.SERVER_JARFILE =
        String(
            serverJar
        );

    environment.MINECRAFT_VERSION =
        String(
            minecraftVersion
        );

    environment.TZ =
        String(
            timezone
        );

    /*
     * Environment variables from config.js:
     *
     * PTERODACTYL_EGG_VAR_<VARIABLE>=value
     *
     * are already exposed through config.eggEnvironment.
     */
    if (
        config?.eggEnvironment &&
        typeof config.eggEnvironment ===
            "object"
    ) {
        Object.assign(
            environment,
            config.eggEnvironment
        );
    }

    /*
     * Explicit deployment environment values have the highest
     * priority and therefore override defaults.
     */
    if (
        overrides &&
        typeof overrides ===
            "object"
    ) {
        for (
            const [
                key,
                value
            ] of Object.entries(
                overrides
            )
        ) {
            if (
                value !==
                    undefined &&
                value !==
                    null
            ) {
                environment[
                    key
                ] =
                    String(
                        value
                    );
            }
        }
    }

    return environment;
}

/* ============================================================
 * BUILD DOCKER IMAGE
 * ============================================================ */

function buildDockerImage() {
    const image =
        getConfigValue(
            "PTERODACTYL_DOCKER_IMAGE",
            "pterodactylDockerImage",
            ""
        );

    if (
        image
    ) {
        return String(
            image
        );
    }

    /*
     * Default Java 21 image.
     */
    return (
        "ghcr.io/pterodactyl/yolks:java_21"
    );
}

/* ============================================================
 * BUILD STARTUP
 * ============================================================ */

function buildStartup() {
    const startup =
        getConfigValue(
            "PTERODACTYL_STARTUP",
            "pterodactylStartup",
            ""
        );

    if (
        startup
    ) {
        return String(
            startup
        );
    }

    return (
        "java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}}"
    );
}

/* ============================================================
 * BUILD RESOURCE LIMITS
 * ============================================================ */

function buildLimits(
    resources
) {
    return {
        memory:
            resources.ram,

        swap:
            0,

        disk:
            resources.disk,

        io:
            500,

        cpu:
            resources.cpu
    };
}

/* ============================================================
 * BUILD FEATURE LIMITS
 * ============================================================ */

function buildFeatureLimits(
    resources
) {
    return {
        databases:
            resources.databases,

        allocations:
            resources.allocations,

        backups:
            resources.backups
    };
}

/* ============================================================
 * RESOURCE CHECK
 * ============================================================ */

function checkUserResources(
    discordId,
    requested
) {
    const available =
        resourceManager.getResources(
            discordId
        );

    const result =
        resourceManager.getMissingResources(
            available,
            requested
        );

    return {
        available,
        requested,
        missing:
            result
    };
}

/* ============================================================
 * DEPLOYMENT ATTEMPT CREATION
 * ============================================================ */

function createDeploymentAttempt(
    discordId,
    serverName,
    resources,
    planId = null
) {
    return database.createDeploymentAttempt({
        discordId,

        planId,

        serverName,

        ram:
            resources.ram,

        cpu:
            resources.cpu,

        disk:
            resources.disk,

        status:
            "pending"
    });
}

/* ============================================================
 * RESOURCE ERROR
 * ============================================================ */

function createResourceError(
    check
) {
    const error =
        new Error(
            "Extra resources demanded."
        );

    error.code =
        "INSUFFICIENT_RESOURCES";

    error.available =
        check.available;

    error.required =
        check.requested;

    error.missing =
        check.missing;

    return error;
}

/* ============================================================
 * DEPLOY
 * ============================================================ */

export async function deploy(
    data = {}
) {
    const discordId =
        getDiscordId(
            data
        );

    const username =
        getUsername(
            data
        );

    const serverName =
        getServerName(
            data
        );

    if (
        !discordId
    ) {
        throw new Error(
            "Discord user ID is required."
        );
    }

    if (
        !serverName
    ) {
        throw new Error(
            "Server name is required."
        );
    }

    /*
     * Ensure the local user exists before any resource
     * operation is attempted.
     */
    database.createUser({
        discordId,
        username
    });

    /*
     * Accept resources from either:
     *
     * data.resources
     *
     * or directly from data:
     *
     * data.ram
     * data.cpu
     * data.disk
     */
    const rawResources =
        {
            ...DEFAULT_REQUEST,

            ...(data.resources &&
            typeof data.resources ===
                "object"
                ? data.resources
                : {}),

            ...(data.ram !==
                undefined
                ? {
                    ram:
                        data.ram
                }
                : {}),

            ...(data.cpu !==
                undefined
                ? {
                    cpu:
                        data.cpu
                }
                : {}),

            ...(data.disk !==
                undefined
                ? {
                    disk:
                        data.disk
                }
                : {}),

            ...(data.backups !==
                undefined
                ? {
                    backups:
                        data.backups
                }
                : {}),

            ...(data.allocations !==
                undefined
                ? {
                    allocations:
                        data.allocations
                }
                : {}),

            ...(data.databases !==
                undefined
                ? {
                    databases:
                        data.databases
                }
                : {}),

            ...(data.server_slots !==
                undefined
                ? {
                    server_slots:
                        data.server_slots
                }
                : {}),

            ...(data.serverSlots !==
                undefined
                ? {
                    server_slots:
                        data.serverSlots
                }
                : {})
        };

    const requested =
        normalizeResources(
            rawResources
        );

    validateDeploymentResources(
        requested
    );

    /*
     * Check resources BEFORE consuming anything.
     */
    const resourceCheck =
        checkUserResources(
            discordId,
            requested
        );

    if (
        resourceCheck.missing
            .hasMissing
    ) {
        throw createResourceError(
            resourceCheck
        );
    }

    const planId =
        data.planId ??
        data.plan_id ??
        null;

    const attempt =
        createDeploymentAttempt(
            discordId,
            serverName,
            requested,
            planId
        );

    const attemptId =
        attempt?.id ??
        attempt?.deployment_id ??
        null;

    let resourcesConsumed =
        false;

    let createdPterodactylServer =
        null;

    let localServerRecord =
        null;

    try {
        /*
         * Consume the exact resources requested by the
         * deployment.
         */
        resourceManager.consumeResources(
            discordId,
            requested
        );

        resourcesConsumed =
            true;

        /*
         * Resolve the Pterodactyl account.
         */
        const pterodactylUserId =
            await getPterodactylUser(
                discordId,
                username
            );

        /*
         * Find a node and free allocation.
         *
         * The function automatically tries the next node
         * when the current node is full or has no allocation.
         */
        const target =
            await findTarget(
                requested
            );

        const egg =
            await resolveEgg();

        const environment =
            buildEnvironment(
                data.environment ??
                data.env ??
                {}
            );

        /*
         * IMPORTANT:
         *
         * allocationId is explicitly passed here.
         *
         * This ensures the allocation discovered by
         * findTarget() is actually used by Pterodactyl.
         */
        const serverPayload =
            {
                name:
                    serverName,

                userId:
                    pterodactylUserId,

                nodeId:
                    target.node.id,

                locationId:
                    getPterodactylConfig()
                        .locationId,

                nestId:
                    egg.nestId,

                eggId:
                    egg.eggId,

                allocationId:
                    target.allocation.id,

                dockerImage:
                    buildDockerImage(),

                startup:
                    buildStartup(),

                environment,

                ram:
                    requested.ram,

                memory:
                    requested.ram,

                cpu:
                    requested.cpu,

                disk:
                    requested.disk,

                backups:
                    requested.backups,

                allocations:
                    requested.allocations,

                databases:
                    requested.databases,

                swap:
                    0,

                io:
                    500,

                startOnCompletion:
                    Boolean(
                        data.startOnCompletion ??
                        data.start_on_completion ??
                        true
                    )
            };

        /*
         * Create the Pterodactyl server.
         */
        const created =
            await pterodactyl.createServer(
                serverPayload
            );

        createdPterodactylServer =
            created?.attributes ??
            created ??
            null;

        const pterodactylServerId =
            Number(
                createdPterodactylServer?.id
            );

        if (
            !pterodactylServerId
        ) {
            throw new Error(
                "Pterodactyl did not return a valid server ID."
            );
        }

        /*
         * Save the local server record.
         */
        localServerRecord =
            database.addServer({
                discordId,

                pterodactylId:
                    pterodactylServerId,

                identifier:
                    createdPterodactylServer
                        ?.identifier ??
                    null,

                name:
                    createdPterodactylServer
                        ?.name ??
                    serverName,

                ram:
                    requested.ram,

                cpu:
                    requested.cpu,

                disk:
                    requested.disk,

                backups:
                    requested.backups,

                allocations:
                    requested.allocations,

                databases:
                    requested.databases,

                nodeId:
                    target.node.id,

                allocationId:
                    target.allocation.id,

                status:
                    "running"
            });

        /*
         * Link the plan purchase to the newly created server
         * when a plan ID was supplied.
         */
        if (
            planId
        ) {
            try {
                const purchases =
                    database.getUserPlanPurchases(
                        discordId
                    );

                const latestPurchase =
                    Array.isArray(
                        purchases
                    )
                        ? purchases.find(
                            purchase =>
                                String(
                                    purchase.plan_id ??
                                    ""
                                ) ===
                                String(
                                    planId
                                ) &&
                                !purchase
                                    .pterodactyl_server_id
                        )
                        : null;

                if (
                    latestPurchase?.id
                ) {
                    if (
                        typeof database
                            .linkPlanPurchaseToServer ===
                        "function"
                    ) {
                        database.linkPlanPurchaseToServer(
                            latestPurchase.id,
                            pterodactylServerId
                        );
                    }
                }
            } catch (
                planLinkError
            ) {
                /*
                 * Plan linking is secondary bookkeeping.
                 * Do not destroy a successfully deployed server
                 * only because historical plan linking failed.
                 */
                console.warn(
                    "[Deployment] Unable to link plan purchase to server:",
                    planLinkError?.message ||
                    planLinkError
                );
            }
        }

        /*
         * Mark the deployment attempt as completed.
         */
        if (
            attemptId
        ) {
            database.updateDeploymentAttempt(
                attemptId,
                {
                    node_id:
                        target.node.id,

                    allocation_id:
                        target.allocation.id,

                    status:
                        "completed",

                    pterodactyl_id:
                        pterodactylServerId
                }
            );
        }

        /*
         * Return a normalized deployment result.
         */
        return {
            success:
                true,

            server:
                localServerRecord,

            pterodactyl:
                createdPterodactylServer,

            node:
                target.node,

            allocation:
                target.allocation,

            resources:
                requested,

            attempt:
                attemptId
                    ? database.getDeploymentAttempt(
                        attemptId
                    )
                    : attempt,

            resourceBalance:
                resourceManager.getResources(
                    discordId
                )
        };
    } catch (
        error
    ) {
        /*
         * ====================================================
         * PTERODACTYL ROLLBACK
         * ====================================================
         *
         * If Pterodactyl successfully created the server but
         * local database processing failed afterwards, remove
         * the orphaned Pterodactyl server.
         */
        if (
            createdPterodactylServer
                ?.id
        ) {
            try {
                await pterodactyl.deleteServer(
                    Number(
                        createdPterodactylServer.id
                    )
                );
            } catch (
                cleanupError
            ) {
                console.error(
                    "[Deployment] CRITICAL: failed to remove orphaned Pterodactyl server:",
                    cleanupError
                );
            }
        }

        /*
         * ====================================================
         * RESOURCE ROLLBACK
         * ====================================================
         *
         * Return all resources consumed by this deployment.
         */
        if (
            resourcesConsumed
        ) {
            try {
                resourceManager.refundResources(
                    discordId,
                    requested
                );
            } catch (
                refundError
            ) {
                console.error(
                    "[Deployment] CRITICAL: resource refund failed:",
                    refundError
                );
            }
        }

        /*
         * ====================================================
         * LOCAL SERVER CLEANUP
         * ====================================================
         *
         * If a local record was inserted before a later step
         * failed, remove it as well.
         */
        if (
            localServerRecord?.id
        ) {
            try {
                database.deleteServerById(
                    localServerRecord.id
                );
            } catch (
                cleanupError
            ) {
                console.error(
                    "[Deployment] Failed to remove local server record:",
                    cleanupError
                );
            }
        }

        /*
         * ====================================================
         * DEPLOYMENT ATTEMPT UPDATE
         * ====================================================
         */
        if (
            attemptId
        ) {
            try {
                database.updateDeploymentAttempt(
                    attemptId,
                    {
                        status:
                            "failed",

                        error:
                            error?.message ??
                            String(
                                error
                            )
                    }
                );
            } catch (
                attemptError
            ) {
                console.error(
                    "[Deployment] Failed to update deployment attempt:",
                    attemptError
                );
            }
        }

        throw error;
    }
}

/* ============================================================
 * CHECK RESOURCES
 * ============================================================ */

export async function checkResources(
    discordId,
    resources = {}
) {
    const id =
        getDiscordId({
            discordId
        });

    if (
        !id
    ) {
        throw new Error(
            "Discord user ID is required."
        );
    }

    database.createUser(
        id
    );

    const requested =
        normalizeResources(
            resources
        );

    const available =
        resourceManager.getResources(
            id
        );

    const result =
        resourceManager.getMissingResources(
            available,
            requested
        );

    return {
        available,

        requested,

        missing:
            result
    };
}

/* ============================================================
 * CAN DEPLOY
 * ============================================================ */

export async function canDeploy(
    discordId,
    resources = {}
) {
    const result =
        await checkResources(
            discordId,
            resources
        );

    return (
        !result.missing.hasMissing
    );
}

/* ============================================================
 * REQUEST RESOURCE CHECK
 * ============================================================ */

export async function requestResources(
    resources = {}
) {
    return normalizeResources(
        resources
    );
}

/* ============================================================
 * FIND DEPLOYMENT TARGET
 * ============================================================ */

export async function findDeploymentTarget(
    resources = {}
) {
    const normalized =
        normalizeResources(
            resources
        );

    validateDeploymentResources(
        normalized
    );

    return findTarget(
        normalized
    );
}

/* ============================================================
 * GET USER PTERODACTYL ID
 * ============================================================ */

export async function getUserPterodactylId(
    discordId,
    username = "User"
) {
    const id =
        getDiscordId({
            discordId
        });

    if (
        !id
    ) {
        throw new Error(
            "Discord user ID is required."
        );
    }

    database.createUser({
        discordId:
            id,

        username
    });

    return getPterodactylUser(
        id,
        username
    );
}

/* ============================================================
 * DEPLOYMENT SERVICE OBJECT
 * ============================================================ */

const deployment = {
    deploy,

    checkResources,

    canDeploy,

    requestResources,

    findDeploymentTarget,

    getUserPterodactylId
};

/* ============================================================
 * DEFAULT EXPORT
 * ============================================================ */

export default deployment;

/*
 * ============================================================
 * End of deployment.js
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */