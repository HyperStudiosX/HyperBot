/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */

import database from "../database.js";
import pterodactyl from "./pterodactyl.js";

/*
 * ============================================================
 * SERVER MANAGER ERROR
 * ============================================================
 */

export class ServerManagerError extends Error {
    constructor(
        message,
        code = "SERVER_MANAGER_ERROR"
    ) {
        super(message);
        this.name = "ServerManagerError";
        this.code = code;
    }
}

/*
 * ============================================================
 * NORMALIZATION HELPERS
 * ============================================================
 */

function normalizeId(
    value
) {
    return String(
        value ?? ""
    ).trim();
}

function getPterodactylId(
    server
) {
    return Number(
        server?.pterodactyl_id ??
        server?.pterodactylId ??
        0
    );
}

function getIdentifier(
    server
) {
    return String(
        server?.identifier ??
        ""
    ).trim();
}

/*
 * ============================================================
 * USER SERVER LIST
 * ============================================================
 */

export function getUserServers(
    discordId
) {
    const userId =
        normalizeId(
            discordId
        );

    return database.getUserServers(
        userId
    );
}

/*
 * ============================================================
 * GET SERVER BY LOCAL DATABASE ID
 * ============================================================
 */

export function getServer(
    serverId
) {
    return database.getServerById(
        serverId
    );
}

/*
 * ============================================================
 * GET SERVER BY PTERODACTYL ID
 * ============================================================
 */

export function getServerByPterodactylId(
    pterodactylId
) {
    return database.getServerByPterodactylId(
        pterodactylId
    );
}

/*
 * ============================================================
 * GET SERVER OWNED BY USER
 * ============================================================
 *
 * A user can reference:
 *
 * - Local database server ID
 * - Pterodactyl server ID
 * - Pterodactyl identifier
 *
 * The ownership check is always performed against the
 * Discord user's locally stored servers.
 */

export function getOwnedServer(
    discordId,
    serverId
) {
    const userId =
        normalizeId(
            discordId
        );

    const wanted =
        normalizeId(
            serverId
        );

    if (
        !userId ||
        !wanted
    ) {
        return null;
    }

    /*
     * First try the local server ID with the database's
     * built-in ownership check.
     */
    const localId =
        Number(
            wanted
        );

    if (
        Number.isInteger(
            localId
        ) &&
        localId > 0
    ) {
        const owned =
            database.getServerForUser(
                userId,
                localId
            );

        if (owned) {
            return owned;
        }
    }

    /*
     * Fallback to Pterodactyl ID or identifier.
     */
    const servers =
        getUserServers(
            userId
        );

    return (
        servers.find(
            server =>
                normalizeId(
                    server.pterodactyl_id
                ) === wanted ||
                normalizeId(
                    server.identifier
                ) === wanted
        ) ||
        null
    );
}

/*
 * ============================================================
 * REQUIRE SERVER
 * ============================================================
 */

export function requireServer(
    serverId
) {
    const server =
        getServer(
            serverId
        );

    if (!server) {
        throw new ServerManagerError(
            "Server not found.",
            "SERVER_NOT_FOUND"
        );
    }

    return server;
}

/*
 * ============================================================
 * REQUIRE SERVER OWNER
 * ============================================================
 */

export function requireServerOwner(
    discordId,
    serverId
) {
    const server =
        getOwnedServer(
            discordId,
            serverId
        );

    if (!server) {
        throw new ServerManagerError(
            "Server not found or you do not own this server.",
            "SERVER_NOT_OWNED"
        );
    }

    return server;
}

/*
 * ============================================================
 * OWNERSHIP CHECK
 * ============================================================
 */

export function userOwnsServer(
    discordId,
    serverId
) {
    return Boolean(
        getOwnedServer(
            discordId,
            serverId
        )
    );
}

/*
 * ============================================================
 * ADD SERVER RECORD
 * ============================================================
 */

export function addServerRecord(
    data
) {
    return database.addServer(
        data
    );
}

/*
 * ============================================================
 * UPDATE SERVER
 * ============================================================
 */

export function updateServer(
    serverId,
    updates = {}
) {
    return database.updateServerRecord(
        serverId,
        updates
    );
}

/*
 * ============================================================
 * RENAME SERVER
 * ============================================================
 *
 * Supported forms:
 *
 * renameServer(
 *     discordId,
 *     serverId,
 *     newName
 * )
 *
 * OR:
 *
 * renameServer(
 *     serverObject,
 *     newName
 * )
 */

export async function renameServer(
    first,
    second,
    third
) {
    let discordId;
    let serverId;
    let newName;

    if (
        first &&
        typeof first === "object"
    ) {
        discordId =
            first.discordId ??
            first.discord_id;

        serverId =
            first.id ??
            first.serverId;

        newName =
            second ??
            first.name;
    } else {
        discordId =
            first;

        serverId =
            second;

        newName =
            third;
    }

    const server =
        requireServerOwner(
            discordId,
            serverId
        );

    newName =
        String(
            newName ?? ""
        ).trim();

    if (!newName) {
        throw new ServerManagerError(
            "Server name cannot be empty.",
            "INVALID_SERVER_NAME"
        );
    }

    if (
        newName.length > 191
    ) {
        throw new ServerManagerError(
            "Server name cannot be longer than 191 characters.",
            "INVALID_SERVER_NAME"
        );
    }

    const panelId =
        getPterodactylId(
            server
        );

    if (!panelId) {
        throw new ServerManagerError(
            "Invalid Pterodactyl server ID.",
            "INVALID_PTERODACTYL_ID"
        );
    }

    /*
     * Rename the actual Pterodactyl server first.
     */
    const updated =
        await pterodactyl.renameServer(
            panelId,
            newName
        );

    /*
     * Only update the local database after the panel
     * operation succeeds.
     */
    database.renameServer(
        discordId,
        server.id,
        newName
    );

    return (
        updated ||
        database.getServerById(
            server.id
        )
    );
}

/*
 * ============================================================
 * GET SERVER INFORMATION
 * ============================================================
 */

export async function getServerInfo(
    server
) {
    const target =
        typeof server === "string" ||
        typeof server === "number"
            ? requireServer(
                server
            )
            : server;

    const panelId =
        getPterodactylId(
            target
        );

    if (!panelId) {
        throw new ServerManagerError(
            "Invalid Pterodactyl server ID.",
            "INVALID_PTERODACTYL_ID"
        );
    }

    return pterodactyl.getServer(
        panelId
    );
}

/*
 * ============================================================
 * GET SERVER STATUS / RESOURCES
 * ============================================================
 */

export async function getServerStatus(
    server
) {
    const target =
        typeof server === "string" ||
        typeof server === "number"
            ? requireServer(
                server
            )
            : server;

    const serverIdentifier =
        getIdentifier(
            target
        );

    if (!serverIdentifier) {
        throw new ServerManagerError(
            "This server has no Pterodactyl identifier.",
            "INVALID_IDENTIFIER"
        );
    }

    return pterodactyl.getServerResources(
        serverIdentifier
    );
}

/*
 * ============================================================
 * SERVER RESOURCES ALIAS
 * ============================================================
 */

export const getServerResources =
    getServerStatus;

/*
 * ============================================================
 * POWER ACTION
 * ============================================================
 */

export async function powerAction(
    discordId,
    serverId,
    action
) {
    const server =
        requireServerOwner(
            discordId,
            serverId
        );

    return powerServer(
        server,
        action
    );
}

/*
 * ============================================================
 * POWER SERVER
 * ============================================================
 */

export async function powerServer(
    server,
    action
) {
    const key =
        String(
            action ?? ""
        )
        .trim()
        .toLowerCase();

    const serverIdentifier =
        getIdentifier(
            server
        );

    if (!serverIdentifier) {
        throw new ServerManagerError(
            "This server has no Pterodactyl identifier.",
            "INVALID_IDENTIFIER"
        );
    }

    if (
        ![
            "start",
            "stop",
            "restart",
            "kill"
        ].includes(key)
    ) {
        throw new ServerManagerError(
            "Invalid power action.",
            "INVALID_POWER_ACTION"
        );
    }

    return pterodactyl.powerServer(
        serverIdentifier,
        key
    );
}

/*
 * ============================================================
 * START SERVER
 * ============================================================
 */

export const startServer =
    server =>
        powerServer(
            server,
            "start"
        );

/*
 * ============================================================
 * STOP SERVER
 * ============================================================
 */

export const stopServer =
    server =>
        powerServer(
            server,
            "stop"
        );

/*
 * ============================================================
 * RESTART SERVER
 * ============================================================
 */

export const restartServer =
    server =>
        powerServer(
            server,
            "restart"
        );

/*
 * ============================================================
 * KILL SERVER
 * ============================================================
 */

export const killServer =
    server =>
        powerServer(
            server,
            "kill"
        );

/*
 * ============================================================
 * SUSPEND SERVER
 * ============================================================
 */

export async function suspendServer(
    server
) {
    const target =
        typeof server === "string" ||
        typeof server === "number"
            ? requireServer(
                server
            )
            : server;

    const panelId =
        getPterodactylId(
            target
        );

    if (!panelId) {
        throw new ServerManagerError(
            "Invalid Pterodactyl server ID.",
            "INVALID_PTERODACTYL_ID"
        );
    }

    return pterodactyl.suspendServer(
        panelId
    );
}

/*
 * ============================================================
 * UNSUSPEND SERVER
 * ============================================================
 */

export async function unsuspendServer(
    server
) {
    const target =
        typeof server === "string" ||
        typeof server === "number"
            ? requireServer(
                server
            )
            : server;

    const panelId =
        getPterodactylId(
            target
        );

    if (!panelId) {
        throw new ServerManagerError(
            "Invalid Pterodactyl server ID.",
            "INVALID_PTERODACTYL_ID"
        );
    }

    return pterodactyl.unsuspendServer(
        panelId
    );
}

/*
 * ============================================================
 * REINSTALL SERVER
 * ============================================================
 */

export async function reinstallServer(
    server
) {
    const target =
        typeof server === "string" ||
        typeof server === "number"
            ? requireServer(
                server
            )
            : server;

    const panelId =
        getPterodactylId(
            target
        );

    if (!panelId) {
        throw new ServerManagerError(
            "Invalid Pterodactyl server ID.",
            "INVALID_PTERODACTYL_ID"
        );
    }

    return pterodactyl.reinstallServer(
        panelId
    );
}

/*
 * ============================================================
 * RESOURCE REFUND CALCULATION
 * ============================================================
 *
 * Deleting a server returns the resources originally reserved
 * for that server to the user's resource balance.
 */

function getRefundResources(
    server
) {
    return {
        ram:
            Number(
                server?.ram || 0
            ),

        cpu:
            Number(
                server?.cpu || 0
            ),

        disk:
            Number(
                server?.disk || 0
            ),

        backups:
            Number(
                server?.backups || 0
            ),

        allocations:
            Number(
                server?.allocations || 0
            ),

        databases:
            Number(
                server?.databases || 0
            ),

        server_slots:
            Number(
                server?.server_slots ??
                1
            )
    };
}

/*
 * ============================================================
 * DELETE SERVER
 * ============================================================
 *
 * Supported forms:
 *
 * deleteServer(
 *     discordId,
 *     serverId
 * )
 *
 * OR:
 *
 * deleteServer(
 *     serverObject
 * )
 */

export async function deleteServer(
    first,
    second
) {
    let discordId;
    let serverId;
    let server;

    if (
        first &&
        typeof first === "object"
    ) {
        server =
            first;

        discordId =
            first.discordId ??
            first.discord_id;

        serverId =
            first.id ??
            first.serverId;
    } else {
        discordId =
            first;

        serverId =
            second;
    }

    /*
     * If a server object was supplied, still verify that the
     * Discord user owns the server. Never trust the object alone.
     */
    if (
        !discordId &&
        server
    ) {
        discordId =
            server.discordId ??
            server.discord_id;
    }

    if (
        !discordId
    ) {
        throw new ServerManagerError(
            "Discord user ID is required.",
            "INVALID_USER"
        );
    }

    if (
        !server
    ) {
        server =
            requireServerOwner(
                discordId,
                serverId
            );
    } else {
        server =
            requireServerOwner(
                discordId,
                server.id ??
                serverId
            );
    }

    const panelId =
        getPterodactylId(
            server
        );

    if (!panelId) {
        throw new ServerManagerError(
            "Invalid Pterodactyl server ID.",
            "INVALID_PTERODACTYL_ID"
        );
    }

    /*
     * Delete from Pterodactyl first.
     *
     * If Pterodactyl refuses the deletion, the local database
     * and resource balance remain unchanged.
     */
    await pterodactyl.deleteServer(
        panelId
    );

    /*
     * Calculate the resources to return.
     */
    const refunded =
        getRefundResources(
            server
        );

    /*
     * Return resources to the user's account.
     */
    database.addResources(
        discordId,
        refunded
    );

    /*
     * Remove the local server record.
     */
    database.deleteServer(
        discordId,
        server.id
    );

    return {
        success: true,

        server,

        refunded
    };
}

/*
 * ============================================================
 * FIND SERVER FOR USER
 * ============================================================
 */

export const findServerForUser =
    getOwnedServer;

/*
 * ============================================================
 * REQUIRE USER SERVER
 * ============================================================
 */

export const requireUserServer =
    requireServerOwner;

/*
 * ============================================================
 * GET SERVER COUNT
 * ============================================================
 */

export function getServerCount(
    discordId
) {
    return getUserServers(
        discordId
    ).length;
}

/*
 * ============================================================
 * GET RESOURCES USED BY A SERVER
 * ============================================================
 */

export function getResourcesForServer(
    server
) {
    if (!server) {
        return {
            ram: 0,
            cpu: 0,
            disk: 0,
            backups: 0,
            allocations: 0,
            databases: 0,
            server_slots: 0
        };
    }

    return {
        ram:
            Number(
                server.ram || 0
            ),

        cpu:
            Number(
                server.cpu || 0
            ),

        disk:
            Number(
                server.disk || 0
            ),

        backups:
            Number(
                server.backups || 0
            ),

        allocations:
            Number(
                server.allocations || 0
            ),

        databases:
            Number(
                server.databases || 0
            ),

        server_slots:
            Number(
                server.server_slots ??
                1
            )
    };
}

/*
 * ============================================================
 * SERVER MANAGER OBJECT
 * ============================================================
 */

const serverManager = {
    getUserServers,
    getServer,
    getServerByPterodactylId,

    getOwnedServer,
    requireServer,
    requireServerOwner,
    userOwnsServer,

    addServerRecord,
    updateServer,

    renameServer,

    getServerInfo,
    getServerStatus,
    getServerResources,

    powerAction,
    powerServer,

    startServer,
    stopServer,
    restartServer,
    killServer,

    suspendServer,
    unsuspendServer,
    reinstallServer,

    deleteServer,

    findServerForUser,
    requireUserServer,

    getServerCount,
    getResourcesForServer
};

export {
    serverManager
};

export default serverManager;

/*
 * ============================================================
 * End of serverManager.js
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */