/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */

import database from "../database.js";

/*
 * ============================================================
 * USER SERVICE ERROR
 * ============================================================
 */

export class UserServiceError extends Error {
    constructor(
        message,
        code = "USER_SERVICE_ERROR"
    ) {
        super(message);
        this.name = "UserServiceError";
        this.code = code;
    }
}

/*
 * ============================================================
 * NORMALIZE DISCORD ID
 * ============================================================
 */

function normalizeDiscordId(
    discordId
) {
    const id =
        String(
            discordId ?? ""
        ).trim();

    if (!id) {
        throw new UserServiceError(
            "Discord user ID is required.",
            "INVALID_USER_ID"
        );
    }

    return id;
}

/*
 * ============================================================
 * NORMALIZE USERNAME
 * ============================================================
 */

function normalizeUsername(
    username
) {
    if (
        username === null ||
        username === undefined
    ) {
        return null;
    }

    const value =
        String(
            username
        ).trim();

    return value || null;
}

/*
 * ============================================================
 * GET USER
 * ============================================================
 */

export function getUser(
    discordId
) {
    const id =
        normalizeDiscordId(
            discordId
        );

    return database.getUser(
        id
    );
}

/*
 * ============================================================
 * GET OR CREATE USER
 * ============================================================
 */

export function ensureUser(
    discordId,
    username = null
) {
    const id =
        normalizeDiscordId(
            discordId
        );

    let user =
        database.getUser(
            id
        );

    if (!user) {
        user =
            database.createUser({
                discordId: id,
                username:
                    normalizeUsername(
                        username
                    )
            });

        return user;
    }

    const normalizedUsername =
        normalizeUsername(
            username
        );

    /*
     * Keep the username current without creating unnecessary
     * database writes when nothing changed.
     */
    if (
        normalizedUsername &&
        user.username !==
            normalizedUsername &&
        typeof database.updateUsername ===
            "function"
    ) {
        database.updateUsername(
            id,
            normalizedUsername
        );

        user =
            database.getUser(
                id
            );
    }

    return user;
}

/*
 * ============================================================
 * CREATE USER
 * ============================================================
 */

export function createUser(
    discordId,
    username = null
) {
    const id =
        normalizeDiscordId(
            discordId
        );

    const existing =
        database.getUser(
            id
        );

    if (existing) {
        return existing;
    }

    return database.createUser({
        discordId: id,
        username:
            normalizeUsername(
                username
            )
    });
}

/*
 * ============================================================
 * CREATE USER FROM OBJECT
 * ============================================================
 *
 * Compatibility helper for callers that already have a
 * complete user object.
 */

export function createUserFromData(
    data = {}
) {
    if (
        !data ||
        typeof data !== "object"
    ) {
        throw new UserServiceError(
            "User data must be an object.",
            "INVALID_USER_DATA"
        );
    }

    const discordId =
        data.discordId ??
        data.discord_id ??
        data.id;

    const id =
        normalizeDiscordId(
            discordId
        );

    return database.createUser(
        {
            ...data,
            discordId: id
        }
    );
}

/*
 * ============================================================
 * UPDATE USERNAME
 * ============================================================
 */

export function updateUsername(
    discordId,
    username
) {
    const id =
        normalizeDiscordId(
            discordId
        );

    const value =
        normalizeUsername(
            username
        );

    if (!value) {
        throw new UserServiceError(
            "Username cannot be empty.",
            "INVALID_USERNAME"
        );
    }

    ensureUser(
        id
    );

    if (
        typeof database.updateUsername !==
        "function"
    ) {
        throw new UserServiceError(
            "The database does not support username updates.",
            "UNSUPPORTED_OPERATION"
        );
    }

    const result =
        database.updateUsername(
            id,
            value
        );

    return (
        database.getUser(
            id
        ) ||
        result
    );
}

/*
 * ============================================================
 * UPDATE USER
 * ============================================================
 */

export function updateUser(
    discordId,
    updates = {}
) {
    const id =
        normalizeDiscordId(
            discordId
        );

    if (
        !updates ||
        typeof updates !== "object"
    ) {
        throw new UserServiceError(
            "User updates must be an object.",
            "INVALID_USER_DATA"
        );
    }

    ensureUser(
        id
    );

    /*
     * The current database exposes specific update helpers
     * instead of allowing arbitrary column updates.
     */
    let user =
        database.getUser(
            id
        );

    if (
        updates.username !==
            undefined
    ) {
        user =
            updateUsername(
                id,
                updates.username
            );
    }

    return user;
}

/*
 * ============================================================
 * GET USER STATS
 * ============================================================
 */

export function getUserStats(
    discordId
) {
    const id =
        normalizeDiscordId(
            discordId
        );

    ensureUser(
        id
    );

    if (
        typeof database.getUserStats !==
        "function"
    ) {
        const servers =
            typeof database.getUserServers ===
                "function"
                ? database.getUserServers(
                    id
                )
                : [];

        return {
            coins:
                typeof database.getCoins ===
                    "function"
                    ? Number(
                        database.getCoins(
                            id
                        ) || 0
                    )
                    : 0,

            servers: {
                count:
                    servers.length,
                items:
                    servers
            }
        };
    }

    return database.getUserStats(
        id
    );
}

/*
 * ============================================================
 * GET SERVER COUNT
 * ============================================================
 */

export function getServerCount(
    discordId
) {
    const id =
        normalizeDiscordId(
            discordId
        );

    const stats =
        getUserStats(
            id
        );

    /*
     * Correct database structure:
     *
     * stats.servers.count
     *
     * Keep compatibility with older structures as well.
     */
    if (
        stats?.servers &&
        typeof stats.servers ===
            "object"
    ) {
        return Number(
            stats.servers.count ??
            stats.servers.total ??
            0
        );
    }

    return Number(
        stats?.serverCount ??
        stats?.server_count ??
        stats?.servers ??
        0
    );
}

/*
 * ============================================================
 * GET USER SERVERS
 * ============================================================
 */

export function getUserServers(
    discordId
) {
    const id =
        normalizeDiscordId(
            discordId
        );

    ensureUser(
        id
    );

    return database.getUserServers(
        id
    );
}

/*
 * ============================================================
 * GET USER PROFILE
 * ============================================================
 */

export function getProfile(
    discordId
) {
    const id =
        normalizeDiscordId(
            discordId
        );

    const user =
        ensureUser(
            id
        );

    const stats =
        getUserStats(
            id
        );

    const serverCount =
        getServerCount(
            id
        );

    const coins =
        Number(
            stats?.coins ??
            database.getCoins(
                id
            ) ??
            0
        );

    return {
        user,

        discordId:
            id,

        username:
            user?.username ??
            null,

        coins,

        serverCount,

        servers:
            stats?.servers ??
            {
                count:
                    serverCount
            },

        resources:
            stats?.resources ??
            null,

        pterodactyl:
            {
                id:
                    user?.pterodactyl_id ??
                    user?.pterodactylId ??
                    null,

                username:
                    user?.pterodactyl_username ??
                    user?.pterodactylUsername ??
                    null,

                email:
                    user?.pterodactyl_email ??
                    user?.pterodactylEmail ??
                    null
            }
    };
}

/*
 * ============================================================
 * GET PTERODACTYL USER INFORMATION
 * ============================================================
 */

export function getPterodactylUser(
    discordId
) {
    const id =
        normalizeDiscordId(
            discordId
        );

    const user =
        getUser(
            id
        );

    if (!user) {
        return null;
    }

    return {
        id:
            user.pterodactyl_id ??
            user.pterodactylId ??
            null,

        username:
            user.pterodactyl_username ??
            user.pterodactylUsername ??
            null,

        email:
            user.pterodactyl_email ??
            user.pterodactylEmail ??
            null,

        clientKey:
            user.pterodactyl_client_key ??
            user.pterodactylClientKey ??
            null
    };
}

/*
 * ============================================================
 * LINK PTERODACTYL USER
 * ============================================================
 */

export function linkPterodactylUser(
    discordId,
    pterodactylData = {}
) {
    const id =
        normalizeDiscordId(
            discordId
        );

    if (
        !pterodactylData ||
        typeof pterodactylData !==
            "object"
    ) {
        throw new UserServiceError(
            "Pterodactyl user data must be an object.",
            "INVALID_PTERODACTYL_DATA"
        );
    }

    const pterodactylId =
        pterodactylData.pterodactylId ??
        pterodactylData.pterodactyl_id ??
        pterodactylData.id;

    if (
        pterodactylId ===
            null ||
        pterodactylId ===
            undefined
    ) {
        throw new UserServiceError(
            "Pterodactyl user ID is required.",
            "INVALID_PTERODACTYL_ID"
        );
    }

    ensureUser(
        id,
        pterodactylData.username ??
            null
    );

    if (
        typeof database.linkPterodactylUser !==
        "function"
    ) {
        throw new UserServiceError(
            "The database does not support Pterodactyl account linking.",
            "UNSUPPORTED_OPERATION"
        );
    }

    return database.linkPterodactylUser({
        discordId: id,

        pterodactylId:
            Number(
                pterodactylId
            ),

        email:
            pterodactylData.email ??
            null,

        username:
            pterodactylData.username ??
            null,

        pterodactylClientKey:
            pterodactylData.pterodactylClientKey ??
            pterodactylData.pterodactyl_client_key ??
            pterodactylData.clientKey ??
            null
    });
}

/*
 * ============================================================
 * CHECK PTERODACTYL LINK
 * ============================================================
 */

export function hasPterodactylUser(
    discordId
) {
    const data =
        getPterodactylUser(
            discordId
        );

    return Boolean(
        data?.id
    );
}

/*
 * ============================================================
 * GET COINS
 * ============================================================
 */

export function getCoins(
    discordId
) {
    const id =
        normalizeDiscordId(
            discordId
        );

    ensureUser(
        id
    );

    return Number(
        database.getCoins(
            id
        ) || 0
    );
}

/*
 * ============================================================
 * DELETE USER
 * ============================================================
 */

export function deleteUser(
    discordId
) {
    const id =
        normalizeDiscordId(
            discordId
        );

    const existing =
        database.getUser(
            id
        );

    if (!existing) {
        return false;
    }

    /*
     * Do not silently delete a user who still has servers.
     *
     * The database itself should enforce its own deletion
     * constraints as well.
     */
    const servers =
        database.getUserServers(
            id
        );

    if (
        servers &&
        servers.length > 0
    ) {
        throw new UserServiceError(
            `Cannot delete user while they still own ${servers.length} server${servers.length === 1 ? "" : "s"}.`,
            "USER_HAS_SERVERS"
        );
    }

    return database.deleteUser(
        id
    );
}

/*
 * ============================================================
 * CHECK USER EXISTS
 * ============================================================
 */

export function userExists(
    discordId
) {
    const id =
        normalizeDiscordId(
            discordId
        );

    return Boolean(
        database.getUser(
            id
        )
    );
}

/*
 * ============================================================
 * GET USER ID FROM OBJECT
 * ============================================================
 */

export function getDiscordId(
    user
) {
    if (
        typeof user === "string" ||
        typeof user === "number"
    ) {
        return normalizeDiscordId(
            user
        );
    }

    if (
        user &&
        typeof user === "object"
    ) {
        return normalizeDiscordId(
            user.discordId ??
            user.discord_id ??
            user.id
        );
    }

    throw new UserServiceError(
        "Unable to determine Discord user ID.",
        "INVALID_USER"
    );
}

/*
 * ============================================================
 * GET COMPLETE USER SUMMARY
 * ============================================================
 */

export function getUserSummary(
    discordId
) {
    const id =
        normalizeDiscordId(
            discordId
        );

    const profile =
        getProfile(
            id
        );

    const servers =
        getUserServers(
            id
        );

    const pterodactyl =
        getPterodactylUser(
            id
        );

    return {
        ...profile,

        serversList:
            servers,

        pterodactyl
    };
}

/*
 * ============================================================
 * USER SERVICE OBJECT
 * ============================================================
 */

const userService = {
    UserServiceError,

    normalizeDiscordId,

    getUser,
    ensureUser,
    createUser,
    createUserFromData,

    updateUsername,
    updateUser,

    getUserStats,
    getServerCount,
    getUserServers,

    getProfile,
    getUserSummary,

    getPterodactylUser,
    linkPterodactylUser,
    hasPterodactylUser,

    getCoins,

    deleteUser,
    userExists,

    getDiscordId
};

export {
    userService
};

export default userService;

/*
 * ============================================================
 * End of userService.js
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * PetroBot V2 User Service.
 * ============================================================
 */