/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */

import database from "../database.js";

/*
 * ============================================================
 * ECONOMY ERROR
 * ============================================================
 */

export class EconomyError extends Error {
    constructor(
        message,
        code = "ECONOMY_ERROR"
    ) {
        super(message);
        this.name = "EconomyError";
        this.code = code;
    }
}

/*
 * ============================================================
 * USER VALIDATION
 * ============================================================
 */

function normalizeUserId(
    discordUserId
) {
    const userId =
        String(
            discordUserId ?? ""
        ).trim();

    if (!userId) {
        throw new EconomyError(
            "Discord user ID is required.",
            "INVALID_USER"
        );
    }

    return userId;
}

/*
 * ============================================================
 * ENSURE USER
 * ============================================================
 */

export function ensureUser(
    discordUserId,
    username = null
) {
    const userId =
        normalizeUserId(
            discordUserId
        );

    let user =
        database.getUser(
            userId
        );

    /*
     * Create the user if the account does not exist.
     */
    if (!user) {
        user =
            database.createUser({
                discordId: userId,
                username:
                    username ||
                    null
            });

        return user;
    }

    /*
     * Keep the stored Discord username updated.
     */
    if (
        username &&
        user.username !== username &&
        typeof database.updateUsername === "function"
    ) {
        database.updateUsername(
            userId,
            username
        );

        user =
            database.getUser(
                userId
            );
    }

    return user;
}

/*
 * ============================================================
 * GET BALANCE
 * ============================================================
 */

export function getBalance(
    discordUserId
) {
    const userId =
        normalizeUserId(
            discordUserId
        );

    ensureUser(
        userId
    );

    return Number(
        database.getCoins(
            userId
        ) || 0
    );
}

/*
 * ============================================================
 * GET BALANCE INFORMATION
 * ============================================================
 */

export function getBalanceInfo(
    discordUserId
) {
    const balance =
        getBalance(
            discordUserId
        );

    return {
        balance,

        formatted:
            balance.toLocaleString(),

        canAfford(
            amount
        ) {
            const value =
                Number(
                    amount
                );

            return (
                Number.isFinite(
                    value
                ) &&
                Number.isInteger(
                    value
                ) &&
                value >= 0 &&
                balance >= value
            );
        }
    };
}

/*
 * ============================================================
 * ADD COINS
 * ============================================================
 */

export function addCoins(
    discordUserId,
    amount,
    reason = "Coins added"
) {
    const userId =
        normalizeUserId(
            discordUserId
        );

    const value =
        validateAmount(
            amount
        );

    ensureUser(
        userId
    );

    const balance =
        database.addCoins(
            userId,
            value,
            String(
                reason ||
                "Coins added"
            )
        );

    return {
        userId,

        amount:
            value,

        balance:
            Number(
                balance || 0
            ),

        reason:
            String(
                reason ||
                "Coins added"
            )
    };
}

/*
 * ============================================================
 * REMOVE COINS
 * ============================================================
 */

export function removeCoins(
    discordUserId,
    amount,
    reason = "Coins removed"
) {
    const userId =
        normalizeUserId(
            discordUserId
        );

    const value =
        validateAmount(
            amount
        );

    ensureUser(
        userId
    );

    try {
        const balance =
            database.removeCoins(
                userId,
                value,
                String(
                    reason ||
                    "Coins removed"
                )
            );

        return {
            userId,

            amount:
                value,

            balance:
                Number(
                    balance || 0
                ),

            reason:
                String(
                    reason ||
                    "Coins removed"
                )
        };
    } catch (error) {
        const message =
            String(
                error?.message ||
                ""
            ).toLowerCase();

        if (
            message.includes(
                "insufficient"
            )
        ) {
            const currentBalance =
                getBalance(
                    userId
                );

            throw new EconomyError(
                `Insufficient coins. You have ${currentBalance.toLocaleString()} coins, but ${value.toLocaleString()} are required.`,
                "INSUFFICIENT_COINS"
            );
        }

        throw error;
    }
}

/*
 * ============================================================
 * SPEND COINS
 * ============================================================
 *
 * This is intentionally an alias around removeCoins().
 *
 * Plan purchases, shop purchases and other paid actions can
 * use spendCoins() without duplicating economy logic.
 */

export function spendCoins(
    discordUserId,
    amount,
    reason = "Purchase"
) {
    return removeCoins(
        discordUserId,
        amount,
        reason
    );
}

/*
 * ============================================================
 * TRANSFER COINS
 * ============================================================
 */

export function transferCoins(
    fromUserId,
    toUserId,
    amount,
    reason = "Coin transfer"
) {
    const from =
        normalizeUserId(
            fromUserId
        );

    const to =
        normalizeUserId(
            toUserId
        );

    const value =
        validateAmount(
            amount
        );

    if (
        from === to
    ) {
        throw new EconomyError(
            "You cannot transfer coins to yourself.",
            "SELF_TRANSFER"
        );
    }

    /*
     * Make sure both users exist before the transfer.
     */
    ensureUser(
        from
    );

    ensureUser(
        to
    );

    try {
        const result =
            database.transferCoins(
                from,
                to,
                value,
                reason
            );

        /*
         * The corrected database transferCoins() returns:
         *
         * {
         *     referenceId,
         *     amount,
         *     sender: {
         *         discordId,
         *         before,
         *         after
         *     },
         *     receiver: {
         *         discordId,
         *         before,
         *         after
         *     }
         * }
         *
         * Keep compatibility with older return formats as well.
         */

        const senderBalance =
            Number(
                result?.sender?.after ??
                result?.from?.after ??
                result?.senderBalance ??
                result?.from ??
                getBalance(from)
            );

        const receiverBalance =
            Number(
                result?.receiver?.after ??
                result?.to?.after ??
                result?.receiverBalance ??
                result?.to ??
                getBalance(to)
            );

        return {
            from,

            to,

            amount:
                value,

            reason:
                String(
                    reason ||
                    "Coin transfer"
                ),

            referenceId:
                result?.referenceId ??
                null,

            senderBalance,

            receiverBalance,

            sender: {
                discordId:
                    from,

                balance:
                    senderBalance
            },

            receiver: {
                discordId:
                    to,

                balance:
                    receiverBalance
            }
        };
    } catch (error) {
        const message =
            String(
                error?.message ||
                ""
            ).toLowerCase();

        if (
            message.includes(
                "insufficient"
            )
        ) {
            const currentBalance =
                getBalance(
                    from
                );

            throw new EconomyError(
                `Insufficient coins. You have ${currentBalance.toLocaleString()} coins, but ${value.toLocaleString()} are required.`,
                "INSUFFICIENT_COINS"
            );
        }

        if (
            message.includes(
                "yourself"
            )
        ) {
            throw new EconomyError(
                "You cannot transfer coins to yourself.",
                "SELF_TRANSFER"
            );
        }

        throw error;
    }
}

/*
 * ============================================================
 * CAN AFFORD
 * ============================================================
 */

export function canAfford(
    discordUserId,
    amount
) {
    const value =
        validateAmount(
            amount
        );

    return (
        getBalance(
            discordUserId
        ) >= value
    );
}

/*
 * ============================================================
 * REQUIRE AFFORDABILITY
 * ============================================================
 *
 * Useful when a command needs to stop before performing an
 * expensive operation.
 */

export function requireAfford(
    discordUserId,
    amount
) {
    const userId =
        normalizeUserId(
            discordUserId
        );

    const value =
        validateAmount(
            amount
        );

    const balance =
        getBalance(
            userId
        );

    if (
        balance < value
    ) {
        throw new EconomyError(
            `Insufficient coins. You have ${balance.toLocaleString()} coins, but ${value.toLocaleString()} are required.`,
            "INSUFFICIENT_COINS"
        );
    }

    return {
        userId,

        required:
            value,

        balance,

        remaining:
            balance - value
    };
}

/*
 * ============================================================
 * VALIDATE COIN AMOUNT
 * ============================================================
 */

export function validateAmount(
    amount
) {
    const value =
        Number(
            amount
        );

    if (
        !Number.isFinite(
            value
        )
    ) {
        throw new EconomyError(
            "Coin amount must be a valid number.",
            "INVALID_AMOUNT"
        );
    }

    if (
        !Number.isInteger(
            value
        )
    ) {
        throw new EconomyError(
            "Coin amount must be a whole number.",
            "INVALID_AMOUNT"
        );
    }

    if (
        value <= 0
    ) {
        throw new EconomyError(
            "Coin amount must be greater than zero.",
            "INVALID_AMOUNT"
        );
    }

    return value;
}

/*
 * ============================================================
 * FORMAT COINS
 * ============================================================
 */

export function formatCoins(
    amount
) {
    const value =
        Number(
            amount
        );

    if (
        !Number.isFinite(
            value
        )
    ) {
        return "0";
    }

    return Math.trunc(
        value
    ).toLocaleString();
}

/*
 * ============================================================
 * COIN DISPLAY
 * ============================================================
 */

export function formatCoinBalance(
    discordUserId
) {
    const balance =
        getBalance(
            discordUserId
        );

    return `🪙 ${balance.toLocaleString()} coins`;
}

/*
 * ============================================================
 * GET TRANSACTION HISTORY
 * ============================================================
 */

export function getTransactions(
    discordUserId,
    limit = 20
) {
    const userId =
        normalizeUserId(
            discordUserId
        );

    ensureUser(
        userId
    );

    if (
        typeof database.getTransactions !==
        "function"
    ) {
        return [];
    }

    return database.getTransactions(
        userId,
        limit
    );
}

/*
 * ============================================================
 * GET TRANSACTION HISTORY ALIAS
 * ============================================================
 */

export function getTransactionHistory(
    discordUserId,
    limit = 20
) {
    return getTransactions(
        discordUserId,
        limit
    );
}

/*
 * ============================================================
 * GET COIN TRANSACTION COUNT
 * ============================================================
 */

export function countTransactions(
    discordUserId
) {
    const userId =
        normalizeUserId(
            discordUserId
        );

    ensureUser(
        userId
    );

    if (
        typeof database.countTransactions !==
        "function"
    ) {
        return 0;
    }

    return Number(
        database.countTransactions(
            userId
        ) || 0
    );
}

/*
 * ============================================================
 * GET USER ECONOMY SUMMARY
 * ============================================================
 */

export function getEconomySummary(
    discordUserId
) {
    const userId =
        normalizeUserId(
            discordUserId
        );

    const user =
        ensureUser(
            userId
        );

    const balance =
        getBalance(
            userId
        );

    return {
        userId,

        username:
            user?.username ??
            null,

        balance,

        formattedBalance:
            balance.toLocaleString(),

        transactionCount:
            countTransactions(
                userId
            )
    };
}

/*
 * ============================================================
 * ADD COINS WITH REFERENCE
 * ============================================================
 *
 * Useful for systems such as:
 *
 * - Rewards
 * - Admin grants
 * - Refunds
 * - Redeem systems
 * - Server deletion refunds
 */

export function creditCoins(
    discordUserId,
    amount,
    reason = "Coins credited",
    referenceId = null,
    metadata = {}
) {
    const userId =
        normalizeUserId(
            discordUserId
        );

    const value =
        validateAmount(
            amount
        );

    ensureUser(
        userId
    );

    const balance =
        database.addCoins(
            userId,
            value,
            reason,
            metadata,
            referenceId
        );

    return {
        userId,

        amount:
            value,

        balance:
            Number(
                balance || 0
            ),

        reason,

        referenceId
    };
}

/*
 * ============================================================
 * DEBIT COINS WITH REFERENCE
 * ============================================================
 */

export function debitCoins(
    discordUserId,
    amount,
    reason = "Coins debited",
    referenceId = null,
    metadata = {}
) {
    const userId =
        normalizeUserId(
            discordUserId
        );

    const value =
        validateAmount(
            amount
        );

    ensureUser(
        userId
    );

    try {
        const balance =
            database.removeCoins(
                userId,
                value,
                reason,
                metadata,
                referenceId
            );

        return {
            userId,

            amount:
                value,

            balance:
                Number(
                    balance || 0
                ),

            reason,

            referenceId
        };
    } catch (error) {
        const message =
            String(
                error?.message ||
                ""
            ).toLowerCase();

        if (
            message.includes(
                "insufficient"
            )
        ) {
            const currentBalance =
                getBalance(
                    userId
                );

            throw new EconomyError(
                `Insufficient coins. You have ${currentBalance.toLocaleString()} coins, but ${value.toLocaleString()} are required.`,
                "INSUFFICIENT_COINS"
            );
        }

        throw error;
    }
}

/*
 * ============================================================
 * SAFE BALANCE CHECK
 * ============================================================
 */

export function getSafeBalance(
    discordUserId
) {
    try {
        return getBalance(
            discordUserId
        );
    } catch {
        return 0;
    }
}

/*
 * ============================================================
 * ECONOMY OBJECT
 * ============================================================
 */

const economy = {
    EconomyError,

    ensureUser,

    getBalance,
    getBalanceInfo,
    getEconomySummary,
    getSafeBalance,

    addCoins,
    creditCoins,

    removeCoins,
    debitCoins,

    spendCoins,

    transferCoins,

    canAfford,
    requireAfford,

    validateAmount,

    formatCoins,
    formatCoinBalance,

    getTransactions,
    getTransactionHistory,
    countTransactions
};

export default economy;

/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * PetroBot V2 Economy Service.
 * ============================================================
 */