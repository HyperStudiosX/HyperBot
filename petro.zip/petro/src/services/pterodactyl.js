/*
 * ============================================================
 * PetroBot V2 - Pterodactyl API Service
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 *
 * This service is the central Pterodactyl API layer for PetroBot V2.
 *
 * Responsibilities:
 * - Pterodactyl Application API
 * - Pterodactyl Client API
 * - User management
 * - Server management
 * - Server creation
 * - Server deletion
 * - Server renaming
 * - Power controls
 * - Server resource/status information
 * - Node management
 * - Allocation management
 * - Location management
 * - Nest management
 * - Egg management
 * - Egg environment handling
 * - API error normalization
 *
 * API units:
 * - RAM: MB
 * - Disk: MB
 * - CPU: percentage
 * - Backups: count
 * - Databases: count
 * - Allocations: count
 *
 * The database layer is intentionally kept separate from this file.
 * This service only communicates with Pterodactyl.
 * ============================================================
 */

import axios from "axios";
import { config } from "../config.js";

/* ============================================================
 * CONFIGURATION HELPERS
 * ============================================================ */

const PTERODACTYL_URL =
    String(
        config.pterodactylUrl ??
        config.PTERODACTYL_URL ??
        ""
    )
        .trim()
        .replace(/\/+$/, "");

const APPLICATION_API_KEY =
    String(
        config.pterodactylApiKey ??
        config.PTERODACTYL_API_KEY ??
        ""
    ).trim();

const CLIENT_API_KEY =
    String(
        config.pterodactylClientApiKey ??
        config.PTERODACTYL_CLIENT_API_KEY ??
        ""
    ).trim();

const API_VERSION =
    "Application/vnd.pterodactyl.v1+json";

const REQUEST_TIMEOUT =
    30000;

const DEFAULT_PAGE_SIZE =
    100;

const MAX_PAGINATION_PAGES =
    1000;

/* ============================================================
 * API CLIENTS
 * ============================================================ */

const applicationApi =
    axios.create({
        baseURL:
            `${PTERODACTYL_URL}/api/application`,
        headers: {
            Authorization:
                `Bearer ${APPLICATION_API_KEY}`,
            Accept:
                API_VERSION,
            "Content-Type":
                "application/json"
        },
        timeout:
            REQUEST_TIMEOUT
    });

const clientApi =
    axios.create({
        baseURL:
            `${PTERODACTYL_URL}/api/client`,
        headers: {
            Authorization:
                CLIENT_API_KEY
                    ? `Bearer ${CLIENT_API_KEY}`
                    : undefined,
            Accept:
                API_VERSION,
            "Content-Type":
                "application/json"
        },
        timeout:
            REQUEST_TIMEOUT
    });

/* ============================================================
 * VALIDATION HELPERS
 * ============================================================ */

function positiveInteger(
    value,
    name
) {
    const number =
        Number(value);

    if (
        !Number.isInteger(number) ||
        number <= 0
    ) {
        throw new Error(
            `${name} must be a positive integer.`
        );
    }

    return number;
}

function nonNegativeInteger(
    value,
    name,
    fallback = 0
) {
    if (
        value === undefined ||
        value === null ||
        value === ""
    ) {
        return fallback;
    }

    const number =
        Number(value);

    if (
        !Number.isInteger(number) ||
        number < 0
    ) {
        throw new Error(
            `${name} must be a non-negative integer.`
        );
    }

    return number;
}

function cleanString(
    value,
    name
) {
    const result =
        String(
            value ?? ""
        ).trim();

    if (!result) {
        throw new Error(
            `${name} is required.`
        );
    }

    return result;
}

function optionalString(
    value
) {
    if (
        value === undefined ||
        value === null
    ) {
        return null;
    }

    return String(value);
}

function requireApplicationApiKey() {
    if (!PTERODACTYL_URL) {
        const error =
            new Error(
                "PTERODACTYL_URL is not configured."
            );

        error.code =
            "MISSING_PTERODACTYL_URL";

        throw error;
    }

    if (!APPLICATION_API_KEY) {
        const error =
            new Error(
                "PTERODACTYL_API_KEY is not configured."
            );

        error.code =
            "MISSING_PTERODACTYL_API_KEY";

        throw error;
    }
}

function requireClientApiKey(
    apiKey = CLIENT_API_KEY
) {
    const key =
        String(
            apiKey || ""
        ).trim();

    if (!PTERODACTYL_URL) {
        const error =
            new Error(
                "PTERODACTYL_URL is not configured."
            );

        error.code =
            "MISSING_PTERODACTYL_URL";

        throw error;
    }

    if (!key) {
        const error =
            new Error(
                "PTERODACTYL_CLIENT_API_KEY is not configured."
            );

        error.code =
            "MISSING_CLIENT_API_KEY";

        throw error;
    }

    return key;
}

/* ============================================================
 * RESPONSE NORMALIZATION
 * ============================================================ */

function normalizeResponse(
    response
) {
    const data =
        response?.data?.data ??
        response?.data;

    if (
        !data
    ) {
        return null;
    }

    const attributes =
        data?.attributes ||
        {};

    return {
        ...attributes,

        id:
            attributes.id ??
            data?.id,

        relationships:
            data?.relationships ||
            attributes.relationships ||
            {}
    };
}

function normalizeCollection(
    response
) {
    const items =
        Array.isArray(
            response?.data?.data
        )
            ? response.data.data
            : Array.isArray(
                response?.data
            )
                ? response.data
                : [];

    return items.map(
        item => {
            const attributes =
                item?.attributes ||
                item ||
                {};

            return {
                ...attributes,

                id:
                    attributes.id ??
                    item?.id,

                relationships:
                    item?.relationships ||
                    attributes.relationships ||
                    {}
            };
        }
    );
}

/* ============================================================
 * ERROR HANDLING
 * ============================================================ */

function extractApiErrorMessage(
    error
) {
    const errors =
        error?.response?.data?.errors;

    if (
        Array.isArray(errors) &&
        errors.length
    ) {
        const messages =
            errors
                .map(
                    item =>
                        item?.detail ||
                        item?.title ||
                        item?.code
                )
                .filter(Boolean);

        if (
            messages.length
        ) {
            return messages.join(
                " | "
            );
        }
    }

    const message =
        error?.response?.data?.message;

    if (
        message
    ) {
        return String(message);
    }

    return (
        error?.message ||
        "Unknown Pterodactyl API error."
    );
}

function wrapError(
    error,
    action
) {
    if (
        error?.pterodactyl
    ) {
        return error;
    }

    const status =
        error?.response?.status;

    const detail =
        extractApiErrorMessage(
            error
        );

    const wrapped =
        new Error(
            `${action}: ${detail}`
        );

    wrapped.name =
        "PterodactylApiError";

    wrapped.status =
        status;

    wrapped.code =
        error?.code;

    wrapped.response =
        error?.response;

    wrapped.cause =
        error;

    wrapped.pterodactyl =
        true;

    wrapped.action =
        action;

    console.error(
        `[Pterodactyl] ${action}`,
        {
            status,
            detail
        }
    );

    return wrapped;
}

async function request(
    promise,
    action
) {
    try {
        return await promise;
    } catch (error) {
        throw wrapError(
            error,
            action
        );
    }
}

/* ============================================================
 * CLIENT API CONFIGURATION
 * ============================================================ */

function clientConfig(
    apiKey = CLIENT_API_KEY
) {
    const key =
        requireClientApiKey(
            apiKey
        );

    return {
        headers: {
            Authorization:
                `Bearer ${key}`,
            Accept:
                API_VERSION,
            "Content-Type":
                "application/json"
        }
    };
}

/* ============================================================
 * APPLICATION API CHECK
 * ============================================================ */

export function isConfigured() {
    return Boolean(
        PTERODACTYL_URL &&
        APPLICATION_API_KEY
    );
}

export function isClientApiConfigured() {
    return Boolean(
        PTERODACTYL_URL &&
        CLIENT_API_KEY
    );
}

export function getApiUrl() {
    return PTERODACTYL_URL;
}

/* ============================================================
 * PAGINATED COLLECTION HELPER
 * ============================================================ */

async function listCollection(
    path,
    action,
    params = {}
) {
    requireApplicationApiKey();

    const all =
        [];

    let page =
        1;

    while (
        page <=
        MAX_PAGINATION_PAGES
    ) {
        const response =
            await request(
                applicationApi.get(
                    path,
                    {
                        params: {
                            ...params,
                            page,
                            per_page:
                                DEFAULT_PAGE_SIZE
                        }
                    }
                ),
                action
            );

        const items =
            normalizeCollection(
                response
            );

        all.push(
            ...items
        );

        const pagination =
            response?.data
                ?.meta
                ?.pagination;

        if (
            !pagination
        ) {
            break;
        }

        const totalPages =
            Number(
                pagination.total_pages ||
                1
            );

        if (
            page >=
            totalPages
        ) {
            break;
        }

        page++;
    }

    return all;
}

/* ============================================================
 * USERS
 * ============================================================ */

export async function listUsers(
    params = {}
) {
    return listCollection(
        "/users",
        "List Pterodactyl users",
        params
    );
}

export async function getUser(
    userId
) {
    requireApplicationApiKey();

    const id =
        positiveInteger(
            userId,
            "Pterodactyl user ID"
        );

    const response =
        await request(
            applicationApi.get(
                `/users/${id}`
            ),
            `Get Pterodactyl user ${id}`
        );

    return normalizeResponse(
        response
    );
}

export async function findUserByEmail(
    email
) {
    const target =
        cleanString(
            email,
            "Email"
        ).toLowerCase();

    const users =
        await listCollection(
            "/users",
            "Find Pterodactyl user",
            {
                "filter[email]":
                    target
            }
        );

    return (
        users.find(
            user =>
                String(
                    user?.email ||
                    ""
                ).toLowerCase() ===
                target
        ) ||
        null
    );
}

export async function findUser(
    email
) {
    return findUserByEmail(
        email
    );
}

export async function createUser(
    options = {}
) {
    requireApplicationApiKey();

    const email =
        cleanString(
            options.email,
            "Email"
        );

    const username =
        cleanString(
            options.username,
            "Username"
        );

    const firstName =
        cleanString(
            options.firstName ??
            options.first_name ??
            "User",
            "First name"
        );

    const lastName =
        cleanString(
            options.lastName ??
            options.last_name ??
            "User",
            "Last name"
        );

    const payload = {
        email,
        username,
        first_name:
            firstName,
        last_name:
            lastName,
        root_admin:
            Boolean(
                options.rootAdmin ??
                options.root_admin ??
                false
            ),
        language:
            String(
                options.language ||
                "en"
            )
    };

    if (
        options.password !==
        undefined &&
        options.password !==
        null &&
        String(
            options.password
        ) !== ""
    ) {
        payload.password =
            String(
                options.password
            );
    }

    const response =
        await request(
            applicationApi.post(
                "/users",
                payload
            ),
            "Create Pterodactyl user"
        );

    return normalizeResponse(
        response
    );
}

export async function updateUser(
    userId,
    fields = {}
) {
    requireApplicationApiKey();

    const id =
        positiveInteger(
            userId,
            "Pterodactyl user ID"
        );

    const payload =
        {};

    if (
        fields.email !==
        undefined
    ) {
        payload.email =
            cleanString(
                fields.email,
                "Email"
            );
    }

    if (
        fields.username !==
        undefined
    ) {
        payload.username =
            cleanString(
                fields.username,
                "Username"
            );
    }

    if (
        fields.firstName !==
        undefined ||
        fields.first_name !==
        undefined
    ) {
        payload.first_name =
            cleanString(
                fields.firstName ??
                fields.first_name,
                "First name"
            );
    }

    if (
        fields.lastName !==
        undefined ||
        fields.last_name !==
        undefined
    ) {
        payload.last_name =
            cleanString(
                fields.lastName ??
                fields.last_name,
                "Last name"
            );
    }

    if (
        fields.password !==
        undefined
    ) {
        payload.password =
            String(
                fields.password
            );
    }

    if (
        fields.rootAdmin !==
        undefined ||
        fields.root_admin !==
        undefined
    ) {
        payload.root_admin =
            Boolean(
                fields.rootAdmin ??
                fields.root_admin
            );
    }

    if (
        fields.language !==
        undefined
    ) {
        payload.language =
            String(
                fields.language
            );
    }

    if (
        !Object.keys(
            payload
        ).length
    ) {
        throw new Error(
            "No user fields were provided."
        );
    }

    const response =
        await request(
            applicationApi.patch(
                `/users/${id}`,
                payload
            ),
            `Update Pterodactyl user ${id}`
        );

    return normalizeResponse(
        response
    );
}

export const makeUserAdmin =
    (
        userId,
        rootAdmin = true
    ) =>
        updateUser(
            userId,
            {
                rootAdmin
            }
        );

export async function deleteUser(
    userId
) {
    requireApplicationApiKey();

    const id =
        positiveInteger(
            userId,
            "Pterodactyl user ID"
        );

    await request(
        applicationApi.delete(
            `/users/${id}`
        ),
        `Delete Pterodactyl user ${id}`
    );

    return true;
}

/* ============================================================
 * SERVERS - READ
 * ============================================================ */

export async function listServers(
    params = {}
) {
    return listCollection(
        "/servers",
        "List Pterodactyl servers",
        params
    );
}

export const listAllServers =
    listServers;

export async function getServer(
    serverId,
    include = ""
) {
    requireApplicationApiKey();

    const id =
        positiveInteger(
            serverId,
            "Pterodactyl server ID"
        );

    const params =
        include
            ? {
                include:
                    String(
                        include
                    )
            }
            : {};

    const response =
        await request(
            applicationApi.get(
                `/servers/${id}`,
                {
                    params
                }
            ),
            `Get Pterodactyl server ${id}`
        );

    return normalizeResponse(
        response
    );
}

export async function getServerByExternalId(
    externalId,
    include = ""
) {
    requireApplicationApiKey();

    const value =
        cleanString(
            externalId,
            "External server ID"
        );

    const params =
        include
            ? {
                include:
                    String(
                        include
                    )
            }
            : {};

    const response =
        await request(
            applicationApi.get(
                `/servers/external/${encodeURIComponent(value)}`,
                {
                    params
                }
            ),
            `Get server by external ID ${value}`
        );

    return normalizeResponse(
        response
    );
}

/* ============================================================
 * SERVERS - NODE FILTER
 * ============================================================ */

export async function getNodeServers(
    nodeId
) {
    const id =
        positiveInteger(
            nodeId,
            "Node ID"
        );

    return listServers({
        "filter[node]":
            id
    });
}

/* ============================================================
 * SERVERS - DELETE
 * ============================================================ */

export async function deleteServer(
    serverId,
    force = false
) {
    requireApplicationApiKey();

    const id =
        positiveInteger(
            serverId,
            "Pterodactyl server ID"
        );

    const endpoint =
        force
            ? `/servers/${id}/force`
            : `/servers/${id}`;

    await request(
        applicationApi.delete(
            endpoint
        ),
        `Delete Pterodactyl server ${id}`
    );

    return true;
}

/* ============================================================
 * SERVERS - DETAILS
 * ============================================================ */

export async function updateServerDetails(
    serverId,
    options = {}
) {
    requireApplicationApiKey();

    const id =
        positiveInteger(
            serverId,
            "Pterodactyl server ID"
        );

    const payload =
        {};

    if (
        options.name !==
        undefined
    ) {
        payload.name =
            cleanString(
                options.name,
                "Server name"
            );
    }

    if (
        options.user !==
        undefined
    ) {
        payload.user =
            positiveInteger(
                options.user,
                "Pterodactyl user ID"
            );
    }

    if (
        options.description !==
        undefined
    ) {
        payload.description =
            String(
                options.description
            );
    }

    if (
        options.externalId !==
        undefined ||
        options.external_id !==
        undefined
    ) {
        const value =
            options.externalId ??
            options.external_id;

        payload.external_id =
            value === null
                ? null
                : String(
                    value
                );
    }

    if (
        !Object.keys(
            payload
        ).length
    ) {
        throw new Error(
            "No server details were provided."
        );
    }

    const response =
        await request(
            applicationApi.patch(
                `/servers/${id}/details`,
                payload
            ),
            `Update Pterodactyl server ${id} details`
        );

    return normalizeResponse(
        response
    );
}

export const renameServer =
    (
        serverId,
        name
    ) =>
        updateServerDetails(
            serverId,
            {
                name
            }
        );

/* ============================================================
 * SERVER BUILD / RESOURCE UPDATE
 * ============================================================ */

export async function updateServerBuild(
    serverId,
    options = {}
) {
    requireApplicationApiKey();

    const id =
        positiveInteger(
            serverId,
            "Pterodactyl server ID"
        );

    const payload =
        {};

    if (
        options.memory !==
        undefined ||
        options.ram !==
        undefined
    ) {
        payload.memory =
            nonNegativeInteger(
                options.memory ??
                options.ram,
                "RAM"
            );
    }

    if (
        options.swap !==
        undefined
    ) {
        payload.swap =
            Number(
                options.swap
            );
    }

    if (
        options.disk !==
        undefined
    ) {
        payload.disk =
            nonNegativeInteger(
                options.disk,
                "Disk"
            );
    }

    if (
        options.io !==
        undefined
    ) {
        payload.io =
            nonNegativeInteger(
                options.io,
                "IO"
            );
    }

    if (
        options.cpu !==
        undefined
    ) {
        payload.cpu =
            nonNegativeInteger(
                options.cpu,
                "CPU"
            );
    }

    if (
        options.threads !==
        undefined
    ) {
        payload.threads =
            String(
                options.threads
            );
    }

    if (
        options.oomDisabled !==
        undefined ||
        options.oom_disabled !==
        undefined
    ) {
        payload.oom_disabled =
            Boolean(
                options.oomDisabled ??
                options.oom_disabled
            );
    }

    if (
        options.featureLimits
    ) {
        payload.feature_limits =
            {
                ...options.featureLimits
            };
    }

    if (
        options.databases !==
        undefined
    ) {
        payload.feature_limits =
            {
                ...(
                    payload.feature_limits ||
                    {}
                ),
                databases:
                    nonNegativeInteger(
                        options.databases,
                        "Databases"
                    )
            };
    }

    if (
        options.allocations !==
        undefined
    ) {
        payload.feature_limits =
            {
                ...(
                    payload.feature_limits ||
                    {}
                ),
                allocations:
                    nonNegativeInteger(
                        options.allocations,
                        "Allocations"
                    )
            };
    }

    if (
        options.backups !==
        undefined
    ) {
        payload.feature_limits =
            {
                ...(
                    payload.feature_limits ||
                    {}
                ),
                backups:
                    nonNegativeInteger(
                        options.backups,
                        "Backups"
                    )
            };
    }

    if (
        !Object.keys(
            payload
        ).length
    ) {
        throw new Error(
            "No build settings were provided."
        );
    }

    const response =
        await request(
            applicationApi.patch(
                `/servers/${id}/build`,
                payload
            ),
            `Update build settings for server ${id}`
        );

    return normalizeResponse(
        response
    );
}

/* ============================================================
 * POWER
 * ============================================================ */

export async function powerServer(
    identifier,
    signal,
    apiKey
) {
    const server =
        cleanString(
            identifier,
            "Server identifier"
        );

    const action =
        String(
            signal ?? ""
        )
            .trim()
            .toLowerCase();

    if (
        ![
            "start",
            "stop",
            "restart",
            "kill"
        ].includes(
            action
        )
    ) {
        throw new Error(
            `Invalid power signal: ${signal}.`
        );
    }

    const response =
        await request(
            clientApi.post(
                `/servers/${encodeURIComponent(server)}/power`,
                {
                    signal:
                        action
                },
                clientConfig(
                    apiKey
                )
            ),
            `Power ${action} on ${server}`
        );

    return (
        response?.data ??
        true
    );
}

export const sendPowerAction =
    powerServer;

export const startServer =
    (
        identifier,
        apiKey
    ) =>
        powerServer(
            identifier,
            "start",
            apiKey
        );

export const stopServer =
    (
        identifier,
        apiKey
    ) =>
        powerServer(
            identifier,
            "stop",
            apiKey
        );

export const restartServer =
    (
        identifier,
        apiKey
    ) =>
        powerServer(
            identifier,
            "restart",
            apiKey
        );

export const killServer =
    (
        identifier,
        apiKey
    ) =>
        powerServer(
            identifier,
            "kill",
            apiKey
        );

/* ============================================================
 * LIVE SERVER RESOURCES
 * ============================================================ */

export async function getServerResources(
    identifier,
    apiKey
) {
    const server =
        cleanString(
            identifier,
            "Server identifier"
        );

    const response =
        await request(
            clientApi.get(
                `/servers/${encodeURIComponent(server)}/resources`,
                clientConfig(
                    apiKey
                )
            ),
            `Get live resources for ${server}`
        );

    return (
        response?.data
            ?.attributes ||
        {}
    );
}

export const getServerStatus =
    getServerResources;

/* ============================================================
 * NODES
 * ============================================================ */

export async function getNode(
    nodeId
) {
    requireApplicationApiKey();

    const id =
        positiveInteger(
            nodeId,
            "Node ID"
        );

    const response =
        await request(
            applicationApi.get(
                `/nodes/${id}`
            ),
            `Get Pterodactyl node ${id}`
        );

    return normalizeResponse(
        response
    );
}

export async function getNodes(
    params = {}
) {
    return listCollection(
        "/nodes",
        "List Pterodactyl nodes",
        params
    );
}

export const listNodes =
    getNodes;

/* ============================================================
 * NODE ALLOCATIONS
 * ============================================================ */

export async function getNodeAllocations(
    nodeId,
    params = {}
) {
    const id =
        positiveInteger(
            nodeId,
            "Node ID"
        );

    return listCollection(
        `/nodes/${id}/allocations`,
        `List allocations for node ${id}`,
        params
    );
}

export async function getAllocation(
    allocationId
) {
    requireApplicationApiKey();

    const id =
        positiveInteger(
            allocationId,
            "Allocation ID"
        );

    const response =
        await request(
            applicationApi.get(
                `/allocations/${id}`
            ),
            `Get allocation ${id}`
        );

    return normalizeResponse(
        response
    );
}

export async function getAvailableAllocation(
    nodeId
) {
    const allocations =
        await getNodeAllocations(
            nodeId
        );

    const free =
        allocations.find(
            allocation => {
                const serverId =
                    allocation?.server_id ??
                    allocation?.serverId ??
                    null;

                const assigned =
                    allocation?.assigned;

                return (
                    serverId ===
                        null &&
                    assigned !==
                        true
                );
            }
        );

    if (
        !free
    ) {
        const error =
            new Error(
                `No free allocation is available on node ${nodeId}.`
            );

        error.code =
            "NO_ALLOCATION";

        throw error;
    }

    return free;
}

/* ============================================================
 * LOCATION MANAGEMENT
 * ============================================================ */

export async function listLocations(
    params = {}
) {
    return listCollection(
        "/locations",
        "List Pterodactyl locations",
        params
    );
}

export async function getLocation(
    locationId
) {
    requireApplicationApiKey();

    const id =
        positiveInteger(
            locationId,
            "Location ID"
        );

    const response =
        await request(
            applicationApi.get(
                `/locations/${id}`
            ),
            `Get Pterodactyl location ${id}`
        );

    return normalizeResponse(
        response
    );
}

/* ============================================================
 * NEST MANAGEMENT
 * ============================================================ */

export async function listNests(
    params = {}
) {
    return listCollection(
        "/nests",
        "List Pterodactyl nests",
        params
    );
}

export async function getNest(
    nestId
) {
    requireApplicationApiKey();

    const id =
        positiveInteger(
            nestId,
            "Nest ID"
        );

    const response =
        await request(
            applicationApi.get(
                `/nests/${id}`
            ),
            `Get Pterodactyl nest ${id}`
        );

    return normalizeResponse(
        response
    );
}

/* ============================================================
 * EGG MANAGEMENT
 * ============================================================ */

export async function listEggs(
    nestId,
    params = {}
) {
    const id =
        positiveInteger(
            nestId,
            "Nest ID"
        );

    return listCollection(
        `/nests/${id}/eggs`,
        `List eggs for nest ${id}`,
        params
    );
}

export async function getEgg(
    nestId =
        config.pterodactylNestId ??
        config.PTERODACTYL_NEST_ID,
    eggId =
        config.pterodactylEggId ??
        config.PTERODACTYL_EGG_ID
) {
    requireApplicationApiKey();

    const nest =
        positiveInteger(
            nestId,
            "Nest ID"
        );

    const egg =
        positiveInteger(
            eggId,
            "Egg ID"
        );

    const response =
        await request(
            applicationApi.get(
                `/nests/${nest}/eggs/${egg}`,
                {
                    params: {
                        include:
                            "variables,nest,config,script"
                    }
                }
            ),
            `Get Pterodactyl egg ${egg}`
        );

    return normalizeResponse(
        response
    );
}

/* ============================================================
 * EGG VARIABLE HELPERS
 * ============================================================ */

function variablesFromEgg(
    egg
) {
    const relationshipData =
        egg?.relationships
            ?.variables
            ?.data;

    if (
        Array.isArray(
            relationshipData
        )
    ) {
        return relationshipData.map(
            item =>
                item?.attributes ||
                item
        );
    }

    if (
        Array.isArray(
            egg?.variables
        )
    ) {
        return egg.variables.map(
            item =>
                item?.attributes ||
                item
        );
    }

    return [];
}

function variableKey(
    variable
) {
    return String(
        variable?.env_variable ??
        variable?.envVariable ??
        ""
    ).trim();
}

function variableRequired(
    variable
) {
    const rules =
        String(
            variable?.rules ||
            ""
        );

    return rules
        .split("|")
        .some(
            rule =>
                rule
                    .trim()
                    .toLowerCase() ===
                "required"
        );
}

/* ============================================================
 * EGG ENVIRONMENT BUILDER
 * ============================================================ */

export function buildEggEnvironment(
    egg,
    overrides = {}
) {
    const environment =
        {};

    const configuredEnvironment =
        config.eggEnvironment &&
        typeof config.eggEnvironment ===
            "object"
            ? config.eggEnvironment
            : {};

    for (
        const variable of
        variablesFromEgg(
            egg
        )
    ) {
        const key =
            variableKey(
                variable
            );

        if (
            !key
        ) {
            continue;
        }

        const configured =
            configuredEnvironment[
                key
            ];

        const override =
            overrides[
                key
            ];

        let value =
            override ??
            configured ??
            variable.default_value ??
            variable.defaultValue;

        if (
            value ===
                null ||
            value ===
                undefined ||
            String(
                value
            ) === ""
        ) {
            const upper =
                key.toUpperCase();

            const variableName =
                String(
                    variable.name ||
                    ""
                )
                    .toLowerCase();

            if (
                upper ===
                    "MINECRAFT_VERSION" ||
                variableName.includes(
                    "minecraft version"
                )
            ) {
                value =
                    config.pterodactylMinecraftVersion ??
                    config.PTERODACTYL_MINECRAFT_VERSION;
            }

            if (
                upper ===
                    "SERVER_JARFILE" ||
                variableName.includes(
                    "server jar"
                )
            ) {
                value =
                    config.pterodactylServerJarfile ??
                    config.PTERODACTYL_SERVER_JARFILE;
            }

            if (
                upper ===
                    "TZ" ||
                variableName ===
                    "timezone" ||
                variableName.includes(
                    "time zone"
                )
            ) {
                value =
                    config.pterodactylTimezone ??
                    config.PTERODACTYL_TIMEZONE;
            }
        }

        if (
            value !==
                null &&
            value !==
                undefined &&
            String(
                value
            ) !== ""
        ) {
            environment[key] =
                String(
                    value
                );
        }
    }

    for (
        const [
            key,
            value
        ] of Object.entries(
            configuredEnvironment
        )
    ) {
        if (
            value !==
                null &&
            value !==
                undefined
        ) {
            environment[key] =
                String(
                    value
                );
        }
    }

    for (
        const [
            key,
            value
        ] of Object.entries(
            overrides || {}
        )
    ) {
        if (
            value !==
                null &&
            value !==
                undefined
        ) {
            environment[key] =
                String(
                    value
                );
        }
    }

    const missing =
        variablesFromEgg(
            egg
        )
            .filter(
                variableRequired
            )
            .map(
                variableKey
            )
            .filter(
                key =>
                    key &&
                    !environment[
                        key
                    ]
            );

    if (
        missing.length
    ) {
        const error =
            new Error(
                `Required Egg variable(s) are missing: ${missing.join(", ")}`
            );

        error.code =
            "MISSING_EGG_VARIABLES";

        error.missing =
            missing;

        throw error;
    }

    return environment;
}

/* ============================================================
 * SERVER CREATION
 * ============================================================ */

export async function createServer(
    options = {}
) {
    requireApplicationApiKey();

    const user =
        positiveInteger(
            options.userId ??
            options.user_id ??
            options.user,
            "Pterodactyl user ID"
        );

    const serverName =
        cleanString(
            options.name ??
            options.serverName ??
            options.server_name,
            "Server name"
        );

    const node =
        positiveInteger(
            options.nodeId ??
            options.node_id ??
            config.pterodactylNodeId ??
            config.PTERODACTYL_NODE_ID,
            "Node ID"
        );

    const locationId =
        positiveInteger(
            options.locationId ??
            options.location_id ??
            config.pterodactylLocationId ??
            config.PTERODACTYL_LOCATION_ID,
            "Location ID"
        );

    const nest =
        positiveInteger(
            options.nestId ??
            options.nest_id ??
            config.pterodactylNestId ??
            config.PTERODACTYL_NEST_ID,
            "Nest ID"
        );

    const egg =
        positiveInteger(
            options.eggId ??
            options.egg_id ??
            config.pterodactylEggId ??
            config.PTERODACTYL_EGG_ID,
            "Egg ID"
        );

    const ramValue =
        positiveInteger(
            options.ram ??
            options.memory,
            "RAM"
        );

    const diskValue =
        positiveInteger(
            options.disk,
            "Disk"
        );

    const cpuValue =
        positiveInteger(
            options.cpu,
            "CPU"
        );

    const databases =
        nonNegativeInteger(
            options.databases,
            "Databases"
        );

    const backups =
        nonNegativeInteger(
            options.backups,
            "Backups"
        );

    const allocations =
        nonNegativeInteger(
            options.allocations,
            "Allocations",
            1
        );

    const startOnCompletion =
        options.startOnCompletion ??
        options.start_on_completion ??
        true;

    /*
     * Read the node first.
     *
     * This prevents deploying onto a node that is currently
     * marked as being in maintenance mode.
     */
    const nodeInfo =
        await getNode(
            node
        );

    if (
        nodeInfo?.maintenance_mode ===
            true ||
        nodeInfo?.maintenanceMode ===
            true
    ) {
        throw new Error(
            `Node ${nodeInfo?.name || node} is in maintenance mode.`
        );
    }

    /*
     * Read the Egg so that all required environment variables
     * can be validated before the server is created.
     */
    const eggInfo =
        await getEgg(
            nest,
            egg
        );

    const eggEnvironment =
        buildEggEnvironment(
            eggInfo,
            options.environment ||
            {}
        );

    const dockerImage =
        options.dockerImage ??
        options.docker_image ??
        config.pterodactylDockerImage ??
        config.PTERODACTYL_DOCKER_IMAGE ??
        eggInfo?.docker_image ??
        eggInfo?.dockerImage;

    const startup =
        options.startup ??
        config.pterodactylStartup ??
        config.PTERODACTYL_STARTUP ??
        eggInfo?.startup;

    if (
        !dockerImage
    ) {
        throw new Error(
            "No Docker image was configured and the selected Egg did not provide one."
        );
    }

    if (
        !startup
    ) {
        throw new Error(
            "No startup command was configured and the selected Egg did not provide one."
        );
    }

    const payload =
        {
            name:
                serverName,

            user:
                user,

            node:
                node,

            nest:
                nest,

            egg:
                egg,

            docker_image:
                dockerImage,

            startup:
                startup,

            environment:
                eggEnvironment,

            limits: {
                memory:
                    ramValue,

                swap:
                    nonNegativeInteger(
                        options.swap,
                        "Swap"
                    ),

                disk:
                    diskValue,

                io:
                    nonNegativeInteger(
                        options.io,
                        "IO",
                        500
                    ),

                cpu:
                    cpuValue
            },

            feature_limits: {
                databases:
                    databases,

                backups:
                    backups,

                allocations:
                    allocations
            },

            start_on_completion:
                Boolean(
                    startOnCompletion
                )
        };

    /*
     * If an allocation is explicitly supplied, use it.
     *
     * Otherwise Pterodactyl will automatically select an
     * allocation from the requested location.
     */
    if (
        options.allocationId !==
            undefined &&
        options.allocationId !==
            null
    ) {
        payload.allocation =
            {
                default:
                    positiveInteger(
                        options.allocationId,
                        "Allocation ID"
                    )
            };
    } else {
        payload.deploy =
            {
                locations: [
                    locationId
                ],

                dedicated_ip:
                    Boolean(
                        options.dedicatedIp ??
                        options.dedicated_ip ??
                        false
                    ),

                port_range:
                    Array.isArray(
                        options.portRange ??
                        options.port_range
                    )
                        ? (
                            options.portRange ??
                            options.port_range
                        )
                        : []
            };
    }

    /*
     * Optional external ID.
     */
    if (
        options.externalId !==
            undefined &&
        options.externalId !==
            null
    ) {
        payload.external_id =
            String(
                options.externalId
            );
    }

    const response =
        await request(
            applicationApi.post(
                "/servers",
                payload
            ),
            `Create Pterodactyl server "${serverName}"`
        );

    return normalizeResponse(
        response
    );
}

/* ============================================================
 * SERVER SUSPENSION
 * ============================================================ */

export async function suspendServer(
    serverId
) {
    requireApplicationApiKey();

    const id =
        positiveInteger(
            serverId,
            "Pterodactyl server ID"
        );

    await request(
        applicationApi.post(
            `/servers/${id}/suspend`,
            {}
        ),
        `Suspend Pterodactyl server ${id}`
    );

    return true;
}

export async function unsuspendServer(
    serverId
) {
    requireApplicationApiKey();

    const id =
        positiveInteger(
            serverId,
            "Pterodactyl server ID"
        );

    await request(
        applicationApi.post(
            `/servers/${id}/unsuspend`,
            {}
        ),
        `Unsuspend Pterodactyl server ${id}`
    );

    return true;
}

/* ============================================================
 * SERVER REINSTALL
 * ============================================================ */

export async function reinstallServer(
    serverId
) {
    requireApplicationApiKey();

    const id =
        positiveInteger(
            serverId,
            "Pterodactyl server ID"
        );

    await request(
        applicationApi.post(
            `/servers/${id}/reinstall`,
            {}
        ),
        `Reinstall Pterodactyl server ${id}`
    );

    return true;
}

/* ============================================================
 * SERVER UNLOCK
 * ============================================================ */

export async function unlockServer(
    serverId
) {
    requireApplicationApiKey();

    const id =
        positiveInteger(
            serverId,
            "Pterodactyl server ID"
        );

    await request(
        applicationApi.post(
            `/servers/${id}/uninstall`,
            {}
        ),
        `Uninstall Pterodactyl server ${id}`
    );

    return true;
}

/* ============================================================
 * SERVER DATABASES
 * ============================================================ */

export async function listServerDatabases(
    serverId
) {
    requireApplicationApiKey();

    const id =
        positiveInteger(
            serverId,
            "Pterodactyl server ID"
        );

    return listCollection(
        `/servers/${id}/databases`,
        `List databases for server ${id}`
    );
}

/* ============================================================
 * SERVER VARIABLES
 * ============================================================ */

export async function listServerVariables(
    serverId
) {
    requireApplicationApiKey();

    const id =
        positiveInteger(
            serverId,
            "Pterodactyl server ID"
        );

    const response =
        await request(
            applicationApi.get(
                `/servers/${id}`,
                {
                    params: {
                        include:
                            "variables"
                    }
                }
            ),
            `Get variables for server ${id}`
        );

    const normalized =
        normalizeResponse(
            response
        );

    return (
        normalized
            ?.relationships
            ?.variables
            ?.data
            ?.map(
                item =>
                    item?.attributes ||
                    item
            ) ||
        []
    );
}

/* ============================================================
 * SERVER REBUILD
 * ============================================================ */

export async function rebuildServer(
    serverId
) {
    requireApplicationApiKey();

    const id =
        positiveInteger(
            serverId,
            "Pterodactyl server ID"
        );

    await request(
        applicationApi.post(
            `/servers/${id}/rebuild`,
            {}
        ),
        `Rebuild Pterodactyl server ${id}`
    );

    return true;
}

/* ============================================================
 * SERVER STARTUP
 * ============================================================ */

export async function updateServerStartup(
    serverId,
    startup,
    environment = {}
) {
    requireApplicationApiKey();

    const id =
        positiveInteger(
            serverId,
            "Pterodactyl server ID"
        );

    const value =
        cleanString(
            startup,
            "Startup command"
        );

    const payload =
        {
            startup:
                value
        };

    if (
        environment &&
        typeof environment ===
            "object"
    ) {
        payload.environment =
            {
                ...environment
            };
    }

    const response =
        await request(
            applicationApi.patch(
                `/servers/${id}/startup`,
                payload
            ),
            `Update startup for Pterodactyl server ${id}`
        );

    return normalizeResponse(
        response
    );
}

/* ============================================================
 * SERVER IMAGE
 * ============================================================ */

export async function updateServerImage(
    serverId,
    image
) {
    requireApplicationApiKey();

    const id =
        positiveInteger(
            serverId,
            "Pterodactyl server ID"
        );

    const dockerImage =
        cleanString(
            image,
            "Docker image"
        );

    const response =
        await request(
            applicationApi.patch(
                `/servers/${id}/build`,
                {
                    docker_image:
                        dockerImage
                }
            ),
            `Update Docker image for server ${id}`
        );

    return normalizeResponse(
        response
    );
}

/* ============================================================
 * RAW APPLICATION REQUEST
 *
 * Kept available for advanced PetroBot V2 services.
 * ============================================================ */

export async function applicationRequest(
    method,
    path,
    options = {}
) {
    requireApplicationApiKey();

    const requestMethod =
        String(
            method ||
            "GET"
        )
            .trim()
            .toLowerCase();

    if (
        ![
            "get",
            "post",
            "put",
            "patch",
            "delete"
        ].includes(
            requestMethod
        )
    ) {
        throw new Error(
            `Unsupported HTTP method: ${method}`
        );
    }

    const cleanPath =
        cleanString(
            path,
            "API path"
        );

    const response =
        await request(
            applicationApi.request(
                {
                    method:
                        requestMethod,

                    url:
                        cleanPath,

                    params:
                        options.params,

                    data:
                        options.data,

                    headers:
                        options.headers
                }
            ),
            `Application API ${requestMethod.toUpperCase()} ${cleanPath}`
        );

    return response?.data;
}

/* ============================================================
 * RAW CLIENT REQUEST
 * ============================================================ */

export async function clientRequest(
    method,
    path,
    options = {}
) {
    const key =
        requireClientApiKey(
            options.apiKey
        );

    const requestMethod =
        String(
            method ||
            "GET"
        )
            .trim()
            .toLowerCase();

    if (
        ![
            "get",
            "post",
            "put",
            "patch",
            "delete"
        ].includes(
            requestMethod
        )
    ) {
        throw new Error(
            `Unsupported HTTP method: ${method}`
        );
    }

    const cleanPath =
        cleanString(
            path,
            "Client API path"
        );

    const response =
        await request(
            clientApi.request(
                {
                    method:
                        requestMethod,

                    url:
                        cleanPath,

                    params:
                        options.params,

                    data:
                        options.data,

                    headers: {
                        ...clientConfig(
                            key
                        ).headers,
                        ...(options.headers ||
                            {})
                    }
                }
            ),
            `Client API ${requestMethod.toUpperCase()} ${cleanPath}`
        );

    return response?.data;
}

/* ============================================================
 * DEFAULT SERVICE OBJECT
 * ============================================================ */

const pterodactyl = {
    isConfigured,
    isClientApiConfigured,
    getApiUrl,

    listUsers,
    getUser,
    findUserByEmail,
    findUser,
    createUser,
    updateUser,
    makeUserAdmin,
    deleteUser,

    listServers,
    listAllServers,
    getServer,
    getServerByExternalId,
    getNodeServers,
    deleteServer,
    updateServerDetails,
    renameServer,
    updateServerBuild,

    powerServer,
    sendPowerAction,
    startServer,
    stopServer,
    restartServer,
    killServer,
    getServerResources,
    getServerStatus,

    getNode,
    getNodes,
    listNodes,
    getNodeAllocations,
    getAllocation,
    getAvailableAllocation,

    listLocations,
    getLocation,

    listNests,
    getNest,

    listEggs,
    getEgg,
    buildEggEnvironment,

    createServer,

    suspendServer,
    unsuspendServer,
    reinstallServer,
    unlockServer,
    rebuildServer,

    listServerDatabases,
    listServerVariables,
    updateServerStartup,
    updateServerImage,

    applicationRequest,
    clientRequest
};

/* ============================================================
 * NAMED EXPORT
 * ============================================================ */

export {
    pterodactyl
};

/* ============================================================
 * CONFIG EXPORT
 *
 * Kept for compatibility with older PetroBot V2 modules that
 * imported config through this service.
 * ============================================================ */

export {
    config
};

/* ============================================================
 * DEFAULT EXPORT
 * ============================================================ */

export default pterodactyl;

/*
 * ============================================================
 * End of pterodactyl.js
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */