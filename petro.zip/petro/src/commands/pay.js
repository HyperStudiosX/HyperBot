/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */

import {
    SlashCommandBuilder
} from "discord.js";
import {
    transferCoins,
    getBalance,
    ensureUser
} from "../services/economy.js";
import {
    successEmbed,
    errorEmbed
} from "../utils/embeds.js";

export const data = new SlashCommandBuilder()
    .setName("pay")
    .setDescription("Transfer coins to another user.")
    .addUserOption(option =>
        option
            .setName("user")
            .setDescription("The user you want to pay.")
            .setRequired(true)
    )
    .addIntegerOption(option =>
        option
            .setName("amount")
            .setDescription("Amount of coins to transfer.")
            .setRequired(true)
            .setMinValue(1)
    )
    .setDMPermission(true);

export async function execute(interaction) {
    const sender = interaction.user;
    const receiver = interaction.options.getUser("user", true);
    const amount = interaction.options.getInteger("amount", true);

    // Prevent bots from being used as payment targets
    if (receiver.bot) {
        return interaction.reply({
            embeds: [
                errorEmbed(
                    "Invalid Recipient",
                    "You cannot transfer coins to a bot."
                )
            ],
            ephemeral: true
        });
    }

    // Prevent self transfers
    if (receiver.id === sender.id) {
        return interaction.reply({
            embeds: [
                errorEmbed(
                    "Invalid Transfer",
                    "You cannot transfer coins to yourself."
                )
            ],
            ephemeral: true
        });
    }

    if (!Number.isInteger(amount) || amount <= 0) {
        return interaction.reply({
            embeds: [
                errorEmbed(
                    "Invalid Amount",
                    "The amount must be a positive whole number."
                )
            ],
            ephemeral: true
        });
    }

    try {
        // Make sure both users exist
        ensureUser(
            sender.id,
            sender.username
        );

        ensureUser(
            receiver.id,
            receiver.username
        );

        // Check balance before attempting the transfer
        const senderBalance = getBalance(sender.id);

        if (senderBalance < amount) {
            return interaction.reply({
                embeds: [
                    errorEmbed(
                        "Insufficient Coins",
                        `You need **${amount.toLocaleString()} coins**, but you only have **${senderBalance.toLocaleString()} coins**.`
                    )
                ],
                ephemeral: true
            });
        }

        const result = transferCoins(
            sender.id,
            receiver.id,
            amount
        );

        return interaction.reply({
            embeds: [
                successEmbed(
                    "Transfer Successful",
                    `You sent **${amount.toLocaleString()} coins** to **${receiver.username}**.\n\n💰 **Your New Balance:** ${Number(result.senderBalance).toLocaleString()} coins`
                )
            ],
            ephemeral: true
        });
    } catch (error) {
        return interaction.reply({
            embeds: [
                errorEmbed(
                    "Transfer Failed",
                    error?.message || "The coin transfer could not be completed."
                )
            ],
            ephemeral: true
        });
    }
}

export default {
    data,
    execute
};

/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */