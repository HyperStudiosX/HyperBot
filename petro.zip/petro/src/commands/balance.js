/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */

import { SlashCommandBuilder } from "discord.js";
import { getBalance, ensureUser } from "../services/economy.js";
import { balanceEmbed } from "../utils/embeds.js";

export const data = new SlashCommandBuilder()
    .setName("balance")
    .setDescription("Check your coin balance.")
    .setDMPermission(true);

export async function execute(interaction) {
    const userId = interaction.user.id;
    const username = interaction.user.username;

    ensureUser(userId, username);

    const balance = getBalance(userId);

    return interaction.reply({
        embeds: [
            balanceEmbed(
                interaction.user,
                balance
            )
        ],
        ephemeral: true
    });
}

export default {
    data,
    execute
};

/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */