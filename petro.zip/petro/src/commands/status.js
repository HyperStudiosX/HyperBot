/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */

import { SlashCommandBuilder } from "discord.js";
import { serverManager } from "../services/serverManager.js";
import { getUser } from "../services/userService.js";
import { resourceEmbed, errorEmbed } from "../utils/embeds.js";

export const data = new SlashCommandBuilder()
    .setName("status")
    .setDescription("Check your server status and resources.")
    .addStringOption(option =>
        option
            .setName("server_id")
            .setDescription("The Server ID of the server.")
            .setRequired(true)
    )
    .setDMPermission(true);

export async function execute(interaction) {
    try {
        const serverId = interaction.options.getString("server_id", true);
        const user = getUser(interaction.user.id);

        if (!user) {
            return interaction.reply({
                embeds: [
                    errorEmbed(
                        "Account Not Found",
                        "Your account has not been registered yet."
                    )
                ],
                ephemeral: true
            });
        }

        await interaction.deferReply({ ephemeral: true });

        const server = serverManager.getOwnedServer(
            interaction.user.id,
            serverId
        );

        if (!server) {
            return interaction.editReply({
                embeds: [
                    errorEmbed(
                        "Server Not Found",
                        "The Server ID is invalid or this server does not belong to you."
                    )
                ]
            });
        }

        const status = await serverManager.getServerStatus(server);
        const resources = await serverManager.getServerResources(server);

        return interaction.editReply({
            embeds: [
                resourceEmbed(
                    server.name || "Server Status",
                    serverId,
                    status,
                    resources
                )
            ]
        });
    } catch (error) {
        console.error("[Status]", error);

        if (interaction.deferred || interaction.replied) {
            return interaction.editReply({
                embeds: [
                    errorEmbed(
                        "Failed to Get Status",
                        error?.message || "An unexpected error occurred while checking the server status."
                    )
                ]
            });
        }

        return interaction.reply({
            embeds: [
                errorEmbed(
                    "Failed to Get Status",
                    error?.message || "An unexpected error occurred while checking the server status."
                )
            ],
            ephemeral: true
        });
    }
}

export default {
    data,
    execute
};

/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */