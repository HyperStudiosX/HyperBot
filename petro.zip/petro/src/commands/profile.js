/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */

import { SlashCommandBuilder } from "discord.js";
import { getProfile } from "../services/userService.js";
import { createEmbed } from "../utils/embeds.js";

export const data = new SlashCommandBuilder()
    .setName("profile")
    .setDescription("View your bot profile.")
    .setDMPermission(true);

export async function execute(interaction) {
    try {
        const profile = getProfile(interaction.user.id);

        const embed = createEmbed({
            title: "👤 Your Profile",
            description: `Profile information for **${interaction.user.username}**.`,
            color: 0x5865F2,
            fields: [
                {
                    name: "Discord User",
                    value: `<@${interaction.user.id}>`,
                    inline: true
                },
                {
                    name: "User ID",
                    value: `\`${interaction.user.id}\``,
                    inline: true
                },
                {
                    name: "🪙 Coins",
                    value: `**${Number(profile.coins).toLocaleString()}**`,
                    inline: true
                },
                {
                    name: "🖥️ Servers",
                    value: `**${profile.serverCount ?? 0}**`,
                    inline: true
                },
                {
                    name: "📅 Account Created",
                    value: profile.createdAt
                        ? `<t:${Math.floor(new Date(profile.createdAt).getTime() / 1000)}:F>`
                        : "Unknown",
                    inline: false
                }
            ]
        });

        return interaction.reply({
            embeds: [embed],
            ephemeral: true
        });
    } catch (error) {
        return interaction.reply({
            embeds: [
                createEmbed({
                    title: "❌ Profile Error",
                    description: error?.message || "Unable to load your profile.",
                    color: 0xED4245
                })
            ],
            ephemeral: true
        });
    }
}

export default {
    data,
    execute
};

/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */