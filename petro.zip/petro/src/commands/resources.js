/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */

import { SlashCommandBuilder } from "discord.js";
import resourceManager from "../services/resourceManager.js";
import { createEmbed, errorEmbed } from "../utils/embeds.js";

export const name = "resources";
export const description = "View your available hosting resources.";
export const aliases = ["resource", "res"];

export const data = new SlashCommandBuilder()
    .setName("resources")
    .setDescription("View your available hosting resources.")
    .setDMPermission(true);

function getResourceValue(resources, ...keys) {
    for (const key of keys) {
        if (
            resources &&
            resources[key] !== undefined &&
            resources[key] !== null
        ) {
            const value = Number(resources[key]);

            if (Number.isFinite(value)) {
                return value;
            }
        }
    }

    return 0;
}

function formatMB(value) {
    const mb = Number(value || 0);

    if (mb >= 1024) {
        const gb = mb / 1024;

        if (Number.isInteger(gb)) {
            return `${gb} GB`;
        }

        return `${gb.toFixed(2)} GB`;
    }

    return `${mb} MB`;
}

function buildResourcesEmbed(user, resources) {
    const ram = getResourceValue(
        resources,
        "ram",
        "ramMb",
        "ram_mb"
    );

    const cpu = getResourceValue(
        resources,
        "cpu",
        "cpuPercent",
        "cpu_percent"
    );

    const disk = getResourceValue(
        resources,
        "disk",
        "diskMb",
        "disk_mb"
    );

    const backups = getResourceValue(
        resources,
        "backups"
    );

    const allocations = getResourceValue(
        resources,
        "allocations"
    );

    const databases = getResourceValue(
        resources,
        "databases"
    );

    const serverSlots = getResourceValue(
        resources,
        "server_slots",
        "serverSlots",
        "slots"
    );

    const embed = createEmbed({
        title: "📦 Your Hosting Resources",
        description:
            "Here are the resources currently available in your Petro account.\n\n" +
            "Resources are consumed when you deploy a server and are restored when appropriate.",
        color: 0x5865F2
    });

    embed.setAuthor({
        name: user.tag || user.username,
        iconURL: user.displayAvatarURL()
    });

    embed.addFields(
        {
            name: "🧠 RAM",
            value: `**${formatMB(ram)}**`,
            inline: true
        },
        {
            name: "⚙️ CPU",
            value: `**${cpu}%**`,
            inline: true
        },
        {
            name: "💾 Disk",
            value: `**${formatMB(disk)}**`,
            inline: true
        },
        {
            name: "🌐 Allocations",
            value: `**${allocations}**`,
            inline: true
        },
        {
            name: "🗄️ Databases",
            value: `**${databases}**`,
            inline: true
        },
        {
            name: "💾 Backups",
            value: `**${backups}**`,
            inline: true
        },
        {
            name: "🖥️ Server Slots",
            value: `**${serverSlots}**`,
            inline: true
        }
    );

    embed.addFields({
        name: "💡 Need More Resources?",
        value:
            "🛒 **Buy a plan:** `!buy <planid>`\n" +
            "🎟️ **Redeem a resource code:** `!redeem <code>`\n" +
            "📋 **View available plans:** `!plans`\n" +
            "🚀 **Deploy a server:** `!deploy <ram> <cpu> <disk> [name]`",
        inline: false
    });

    embed.setFooter({
        text: "HyperForgeX • Petro V2"
    });

    return embed;
}

export async function execute(interaction) {
    const userId = interaction.user.id;

    try {
        const resources = resourceManager.getResources(userId);

        const embed = buildResourcesEmbed(
            interaction.user,
            resources
        );

        return interaction.reply({
            embeds: [embed],
            ephemeral: true
        });
    } catch (error) {
        console.error(`[Resources] Slash command failed for ${userId}:`, error);

        return interaction.reply({
            embeds: [
                errorEmbed(
                    "Resource Error",
                    error?.message || "Unable to load your resources."
                )
            ],
            ephemeral: true
        });
    }
}

export async function prefixExecute(message) {
    const userId = message.author.id;

    try {
        const resources = resourceManager.getResources(userId);

        const embed = buildResourcesEmbed(
            message.author,
            resources
        );

        return message.reply({
            embeds: [embed]
        });
    } catch (error) {
        console.error(`[Resources] Prefix command failed for ${userId}:`, error);

        return message.reply({
            embeds: [
                errorEmbed(
                    "Resource Error",
                    error?.message || "Unable to load your resources."
                )
            ]
        });
    }
}

export default {
    name,
    description,
    aliases,
    data,
    execute,
    prefixExecute
};

/*
 * ============================================================
 * End of resources.js
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */