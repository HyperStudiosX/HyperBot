/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */

import {
    SlashCommandBuilder
} from "discord.js";
import {
    addCoins,
    ensureUser
} from "../services/economy.js";
import {
    requireBotAdmin
} from "../utils/permissions.js";
import {
    successEmbed,
    errorEmbed
} from "../utils/embeds.js";

export const data = new SlashCommandBuilder()
    .setName("givecoins")
    .setDescription("Give coins to a user.")
    .addUserOption(option =>
        option
            .setName("user")
            .setDescription("The user who will receive the coins.")
            .setRequired(true)
    )
    .addIntegerOption(option =>
        option
            .setName("amount")
            .setDescription("Amount of coins to give.")
            .setRequired(true)
            .setMinValue(1)
    )
    .setDMPermission(true);

export async function execute(interaction) {
    const adminId = interaction.user.id;
    const target = interaction.options.getUser("user", true);
    const amount = interaction.options.getInteger("amount", true);

    try {
        // Only bot administrators can use this command
        requireBotAdmin(adminId);

        if (target.bot) {
            return interaction.reply({
                embeds: [
                    errorEmbed(
                        "Invalid User",
                        "You cannot give coins to a bot."
                    )
                ],
                ephemeral: true
            });
        }

        if (!Number.isInteger(amount) || amount <= 0) {
            return interaction.reply({
                embeds: [
                    errorEmbed(
                        "Invalid Amount",
                        "The amount must be a positive whole number."
                    )
                ],
                ephemeral: true
            });
        }

        // Create the user if they don't have an economy account
        ensureUser(
            target.id,
            target.username
        );

        const result = addCoins(
            target.id,
            amount,
            `Given by ${interaction.user.username}`
        );

        return interaction.reply({
            embeds: [
                successEmbed(
                    "Coins Added",
                    `Successfully added **${amount.toLocaleString()} coins** to **${target.username}**.\n\n💰 **New Balance:** ${Number(result.balance).toLocaleString()} coins`
                )
            ],
            ephemeral: true
        });
    } catch (error) {
        return interaction.reply({
            embeds: [
                errorEmbed(
                    "Give Coins Failed",
                    error?.message || "Unable to add coins."
                )
            ],
            ephemeral: true
        });
    }
}

export default {
    data,
    execute
};

/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */