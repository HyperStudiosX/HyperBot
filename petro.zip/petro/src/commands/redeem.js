/*
 * ============================================================
 * PetroBot V2 - Redeem Command
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */

import database from "../database.js";
import economy from "../services/economy.js";
import resourceManager from "../services/resourceManager.js";
import { createEmbed, errorEmbed } from "../utils/embeds.js";

export const name = "redeem";
export const description = "Redeem a Petro coin or resource code.";

export const aliases = [
    "redeemcode",
    "code"
];

export const data = {
    name: "redeem",
    description: "Redeem a Petro coin or resource code.",
    options: [
        {
            name: "code",
            description: "The code you want to redeem.",
            type: 3,
            required: true
        }
    ]
};

function number(value, fallback = 0) {
    const n = Number(value);
    return Number.isFinite(n) ? n : fallback;
}

function formatNumber(value) {
    return number(value).toLocaleString("en-US");
}

function mbToGb(value) {
    const mb = number(value);
    const gb = mb / 1024;

    if (!Number.isFinite(gb) || gb <= 0) {
        return "0 GB";
    }

    if (Number.isInteger(gb)) {
        return `${gb} GB`;
    }

    return `${gb.toFixed(2).replace(/0+$/, "").replace(/\.$/, "")} GB`;
}

function normalizeCode(value) {
    return String(value ?? "")
        .trim()
        .toUpperCase();
}

function getCodeType(code) {
    return String(
        code?.type ??
        code?.codeType ??
        code?.code_type ??
        ""
    ).trim().toLowerCase();
}

function getCodeValue(code) {
    return number(
        code?.value ??
        code?.amount ??
        code?.coins ??
        code?.coinValue ??
        code?.coin_value
    );
}

function getCodeResources(code) {
    return {
        ram: number(
            code?.ram ??
            code?.ramMb ??
            code?.ram_mb
        ),
        cpu: number(
            code?.cpu ??
            code?.cpuPercent ??
            code?.cpu_percent
        ),
        disk: number(
            code?.disk ??
            code?.diskMb ??
            code?.disk_mb
        ),
        backups: number(
            code?.backups ??
            code?.backup
        ),
        allocations: number(
            code?.allocations ??
            code?.allocation
        ),
        databases: number(
            code?.databases ??
            code?.database
        ),
        server_slots: number(
            code?.serverSlots ??
            code?.server_slots ??
            code?.slots
        )
    };
}

function resourceText(resources) {
    const lines = [];

    if (resources.ram > 0) {
        lines.push(`🧠 RAM: **+${mbToGb(resources.ram)}**`);
    }

    if (resources.cpu > 0) {
        lines.push(`⚙️ CPU: **+${formatNumber(resources.cpu)}%**`);
    }

    if (resources.disk > 0) {
        lines.push(`💾 Disk: **+${mbToGb(resources.disk)}**`);
    }

    if (resources.allocations > 0) {
        lines.push(
            `🌐 Allocations: **+${formatNumber(resources.allocations)}**`
        );
    }

    if (resources.databases > 0) {
        lines.push(
            `🗄️ Databases: **+${formatNumber(resources.databases)}**`
        );
    }

    if (resources.backups > 0) {
        lines.push(
            `💿 Backups: **+${formatNumber(resources.backups)}**`
        );
    }

    if (resources.server_slots > 0) {
        lines.push(
            `🖥️ Server Slots: **+${formatNumber(resources.server_slots)}**`
        );
    }

    return lines.length > 0
        ? lines.join("\n")
        : "No resources are attached to this code.";
}

function currentResourceText(resources) {
    const data = resources || {};

    return (
        `🧠 RAM: **${mbToGb(data.ram)}**\n` +
        `⚙️ CPU: **${formatNumber(data.cpu)}%**\n` +
        `💾 Disk: **${mbToGb(data.disk)}**\n` +
        `🌐 Allocations: **${formatNumber(data.allocations)}**\n` +
        `🗄️ Databases: **${formatNumber(data.databases)}**\n` +
        `💿 Backups: **${formatNumber(data.backups)}**\n` +
        `🖥️ Server Slots: **${formatNumber(data.server_slots)}**`
    );
}

function isCoinCode(type) {
    return [
        "coin",
        "coins",
        "currency",
        "money"
    ].includes(type);
}

function isResourceCode(type) {
    return [
        "resource",
        "resources"
    ].includes(type);
}

function findCode(code) {
    const normalized = normalizeCode(code);

    if (!normalized) {
        return null;
    }

    const methods = [
        "getRedeemCode",
        "getCode",
        "findRedeemCode",
        "findCode"
    ];

    for (const method of methods) {
        if (typeof database[method] !== "function") {
            continue;
        }

        try {
            const result = database[method](normalized);

            if (result) {
                return result;
            }
        } catch (error) {
            console.error(
                `[Redeem] ${method} failed:`,
                error
            );
        }
    }

    return null;
}

function markCodeRedeemed(codeId, discordId) {
    const methods = [
        "redeemCode",
        "useRedeemCode",
        "markCodeRedeemed",
        "consumeRedeemCode"
    ];

    for (const method of methods) {
        if (typeof database[method] !== "function") {
            continue;
        }

        try {
            const result = database[method](
                codeId,
                discordId
            );

            if (result !== false) {
                return result ?? true;
            }
        } catch (error) {
            console.error(
                `[Redeem] ${method} failed:`,
                error
            );
        }
    }

    return null;
}

function getCodeId(code) {
    return (
        code?.id ??
        code?.codeId ??
        code?.code_id ??
        null
    );
}

function isAlreadyRedeemed(code) {
    return Boolean(
        code?.redeemed ||
        code?.isRedeemed ||
        code?.redeemedAt ||
        code?.redeemed_at
    );
}

function isExpired(code) {
    if (
        code?.expiresAt === null ||
        code?.expires_at === null ||
        code?.expiresAt === undefined &&
        code?.expires_at === undefined
    ) {
        return false;
    }

    const value =
        code?.expiresAt ??
        code?.expires_at;

    if (!value) {
        return false;
    }

    const timestamp = new Date(value).getTime();

    if (!Number.isFinite(timestamp)) {
        return false;
    }

    return timestamp <= Date.now();
}

function buildInvalidCodeEmbed() {
    return errorEmbed(
        "Invalid Code",
        "That redeem code does not exist or is invalid."
    );
}

function buildAlreadyRedeemedEmbed() {
    return errorEmbed(
        "Code Already Redeemed",
        "This redeem code has already been used."
    );
}

function buildExpiredEmbed() {
    return errorEmbed(
        "Code Expired",
        "This redeem code has expired and can no longer be redeemed."
    );
}

function buildCoinSuccessEmbed(
    code,
    amount,
    balance
) {
    const embed = createEmbed({
        title: "🎉 Coins Redeemed",
        description:
            "Your redeem code was successfully redeemed.",
        color: 0x57F287
    });

    embed.addFields(
        {
            name: "🎟️ Code",
            value: `\`${normalizeCode(code)}\``,
            inline: true
        },
        {
            name: "💰 Coins Received",
            value: `**+${formatNumber(amount)} coins**`,
            inline: true
        },
        {
            name: "💳 New Balance",
            value: `**${formatNumber(balance)} coins**`,
            inline: true
        }
    );

    embed.setFooter({
        text: "HyperForgeX • Petro V2"
    });

    return embed;
}

function buildResourceSuccessEmbed(
    code,
    resources,
    currentResources
) {
    const embed = createEmbed({
        title: "🎉 Resources Redeemed",
        description:
            "Your resource redeem code was successfully redeemed.",
        color: 0x57F287
    });

    embed.addFields(
        {
            name: "🎟️ Code",
            value: `\`${normalizeCode(code)}\``,
            inline: true
        },
        {
            name: "📦 Resources Received",
            value: resourceText(resources),
            inline: false
        },
        {
            name: "📊 Current Resource Balance",
            value: currentResourceText(currentResources),
            inline: false
        }
    );

    embed.setFooter({
        text: "HyperForgeX • Petro V2"
    });

    return embed;
}

async function redeem(
    discordId,
    username,
    rawCode
) {
    const codeValue = normalizeCode(rawCode);

    if (!codeValue) {
        return {
            success: false,
            type: "missing_code"
        };
    }

    let code = findCode(codeValue);

    if (!code) {
        return {
            success: false,
            type: "invalid_code"
        };
    }

    if (isAlreadyRedeemed(code)) {
        return {
            success: false,
            type: "already_redeemed"
        };
    }

    if (isExpired(code)) {
        return {
            success: false,
            type: "expired"
        };
    }

    const type = getCodeType(code);

    /*
     * --------------------------------------------------------
     * COIN CODE
     * --------------------------------------------------------
     */

    if (isCoinCode(type)) {
        const amount = getCodeValue(code);

        if (amount <= 0) {
            return {
                success: false,
                type: "invalid_value"
            };
        }

        try {
            if (
                typeof database.createUser ===
                "function"
            ) {
                database.createUser({
                    discordId,
                    username
                });
            }
        } catch (error) {
            console.error(
                "[Redeem] Failed to ensure user:",
                error
            );
        }

        let redeemed;

        try {
            redeemed = markCodeRedeemed(
                getCodeId(code),
                discordId
            );
        } catch (error) {
            console.error(
                "[Redeem] Failed to mark coin code:",
                error
            );

            return {
                success: false,
                type: "database_error"
            };
        }

        if (!redeemed) {
            return {
                success: false,
                type: "already_redeemed"
            };
        }

        try {
            economy.addCoins(
                discordId,
                amount,
                `Redeemed code ${codeValue}`
            );
        } catch (error) {
            console.error(
                "[Redeem] Failed to add coins:",
                error
            );

            return {
                success: false,
                type: "credit_failed"
            };
        }

        let balance = 0;

        try {
            balance = economy.getBalance(
                discordId
            );
        } catch {
            balance = amount;
        }

        return {
            success: true,
            type: "coins",
            code: codeValue,
            amount,
            balance
        };
    }

    /*
     * --------------------------------------------------------
     * RESOURCE CODE
     * --------------------------------------------------------
     */

    if (isResourceCode(type)) {
        const resources = getCodeResources(code);

        const hasResources =
            resources.ram > 0 ||
            resources.cpu > 0 ||
            resources.disk > 0 ||
            resources.backups > 0 ||
            resources.allocations > 0 ||
            resources.databases > 0 ||
            resources.server_slots > 0;

        if (!hasResources) {
            return {
                success: false,
                type: "invalid_value"
            };
        }

        try {
            if (
                typeof database.createUser ===
                "function"
            ) {
                database.createUser({
                    discordId,
                    username
                });
            }
        } catch (error) {
            console.error(
                "[Redeem] Failed to ensure resource user:",
                error
            );
        }

        let redeemed;

        try {
            redeemed = markCodeRedeemed(
                getCodeId(code),
                discordId
            );
        } catch (error) {
            console.error(
                "[Redeem] Failed to mark resource code:",
                error
            );

            return {
                success: false,
                type: "database_error"
            };
        }

        if (!redeemed) {
            return {
                success: false,
                type: "already_redeemed"
            };
        }

        try {
            resourceManager.addResources(
                discordId,
                resources
            );
        } catch (error) {
            console.error(
                "[Redeem] Failed to add resources:",
                error
            );

            return {
                success: false,
                type: "credit_failed"
            };
        }

        let currentResources = resources;

        try {
            currentResources =
                resourceManager.getResources(
                    discordId
                );
        } catch (error) {
            console.error(
                "[Redeem] Failed to read resources:",
                error
            );
        }

        return {
            success: true,
            type: "resources",
            code: codeValue,
            resources,
            currentResources
        };
    }

    return {
        success: false,
        type: "unknown_type"
    };
}

function errorMessage(result) {
    switch (result.type) {
        case "missing_code":
            return "❌ **Usage:** `!redeem <code>`";

        case "invalid_code":
            return "❌ That redeem code does not exist or is invalid.";

        case "already_redeemed":
            return "❌ This redeem code has already been redeemed.";

        case "expired":
            return "❌ This redeem code has expired.";

        case "invalid_value":
            return "❌ This redeem code does not contain a valid reward.";

        case "unknown_type":
            return "❌ This redeem code has an unsupported reward type.";

        case "database_error":
            return "❌ The code could not be processed because of a database error.";

        case "credit_failed":
            return "❌ The reward could not be added to your account.";

        default:
            return "❌ The redeem operation failed. Please try again.";
    }
}

export async function execute(
    message,
    args = []
) {
    const discordId = String(
        message?.author?.id ?? ""
    ).trim();

    const username =
        message?.author?.username ??
        message?.author?.tag ??
        null;

    if (!discordId) {
        return message.reply({
            embeds: [
                errorEmbed(
                    "Redeem Error",
                    "I could not determine your Discord account."
                )
            ]
        });
    }

    const rawCode = args?.[0];

    if (!rawCode) {
        return message.reply({
            content:
                "❌ **Usage:** `!redeem <code>`"
        });
    }

    try {
        const result = await redeem(
            discordId,
            username,
            rawCode
        );

        if (!result.success) {
            if (result.type === "invalid_code") {
                return message.reply({
                    embeds: [
                        buildInvalidCodeEmbed()
                    ]
                });
            }

            if (
                result.type ===
                "already_redeemed"
            ) {
                return message.reply({
                    embeds: [
                        buildAlreadyRedeemedEmbed()
                    ]
                });
            }

            if (result.type === "expired") {
                return message.reply({
                    embeds: [
                        buildExpiredEmbed()
                    ]
                });
            }

            return message.reply({
                content: errorMessage(result)
            });
        }

        if (result.type === "coins") {
            return message.reply({
                embeds: [
                    buildCoinSuccessEmbed(
                        result.code,
                        result.amount,
                        result.balance
                    )
                ]
            });
        }

        if (result.type === "resources") {
            return message.reply({
                embeds: [
                    buildResourceSuccessEmbed(
                        result.code,
                        result.resources,
                        result.currentResources
                    )
                ]
            });
        }

        return message.reply({
            content:
                "✅ Redeem code successfully processed."
        });
    } catch (error) {
        console.error(
            `[Redeem] Unexpected error for ${discordId}:`,
            error
        );

        return message.reply({
            embeds: [
                errorEmbed(
                    "Redeem Error",
                    "An unexpected error occurred while redeeming the code."
                )
            ]
        });
    }
}

export async function prefixExecute(
    message,
    args = []
) {
    return execute(message, args);
}

export async function executeSlash(
    interaction
) {
    const discordId = String(
        interaction?.user?.id ?? ""
    ).trim();

    const username =
        interaction?.user?.username ??
        interaction?.user?.tag ??
        null;

    const rawCode =
        interaction?.options?.getString?.(
            "code"
        );

    if (!discordId) {
        return interaction.reply({
            embeds: [
                errorEmbed(
                    "Redeem Error",
                    "I could not determine your Discord account."
                )
            ],
            ephemeral: true
        });
    }

    if (!rawCode) {
        return interaction.reply({
            content:
                "❌ Please provide a redeem code.",
            ephemeral: true
        });
    }

    try {
        const result = await redeem(
            discordId,
            username,
            rawCode
        );

        if (!result.success) {
            if (result.type === "invalid_code") {
                return interaction.reply({
                    embeds: [
                        buildInvalidCodeEmbed()
                    ],
                    ephemeral: true
                });
            }

            if (
                result.type ===
                "already_redeemed"
            ) {
                return interaction.reply({
                    embeds: [
                        buildAlreadyRedeemedEmbed()
                    ],
                    ephemeral: true
                });
            }

            if (result.type === "expired") {
                return interaction.reply({
                    embeds: [
                        buildExpiredEmbed()
                    ],
                    ephemeral: true
                });
            }

            return interaction.reply({
                content: errorMessage(result),
                ephemeral: true
            });
        }

        if (result.type === "coins") {
            return interaction.reply({
                embeds: [
                    buildCoinSuccessEmbed(
                        result.code,
                        result.amount,
                        result.balance
                    )
                ]
            });
        }

        if (result.type === "resources") {
            return interaction.reply({
                embeds: [
                    buildResourceSuccessEmbed(
                        result.code,
                        result.resources,
                        result.currentResources
                    )
                ]
            });
        }

        return interaction.reply({
            content:
                "✅ Redeem code successfully processed."
        });
    } catch (error) {
        console.error(
            `[Redeem] Unexpected slash error for ${discordId}:`,
            error
        );

        const payload = {
            embeds: [
                errorEmbed(
                    "Redeem Error",
                    "An unexpected error occurred while redeeming the code."
                )
            ],
            ephemeral: true
        };

        if (
            interaction.replied ||
            interaction.deferred
        ) {
            return interaction.followUp(
                payload
            );
        }

        return interaction.reply(payload);
    }
}

const redeemCommand = {
    name,
    description,
    aliases,
    data,
    execute,
    prefixExecute,
    executeSlash
};

export default redeemCommand;

/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */