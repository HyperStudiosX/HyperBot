/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * PetroBot V2 - Rename Server Command
 * ============================================================
 */

import {
    SlashCommandBuilder
} from "discord.js";

import serverManager from "../services/serverManager.js";

import {
    createEmbed,
    errorEmbed
} from "../utils/embeds.js";

export const name = "rename";

export const description =
    "Rename one of your Pterodactyl servers.";

export const aliases = [
    "renameserver",
    "serverrename"
];

export const data =
    new SlashCommandBuilder()
        .setName("rename")
        .setDescription(
            "Rename one of your Pterodactyl servers."
        )
        .addStringOption(option =>
            option
                .setName("server")
                .setDescription(
                    "Your server ID or server identifier."
                )
                .setRequired(true)
        )
        .addStringOption(option =>
            option
                .setName("name")
                .setDescription(
                    "The new name for your server."
                )
                .setRequired(true)
                .setMaxLength(100)
        )
        .setDMPermission(true);

/* ============================================================
 * HELPERS
 * ============================================================
 */

function normalizeName(value) {
    return String(value ?? "")
        .trim()
        .replace(/\s+/g, " ");
}

function normalizeServerId(value) {
    return String(value ?? "").trim();
}

/* ============================================================
 * SERVER LOOKUP
 * ============================================================
 */

function findUserServer(
    discordId,
    value
) {
    const serverId =
        normalizeServerId(value);

    if (!serverId) {
        return null;
    }

    /*
     * First try the server manager if it exposes
     * a dedicated lookup helper.
     */
    if (
        typeof serverManager.getServer ===
        "function"
    ) {
        try {
            const server =
                serverManager.getServer(
                    discordId,
                    serverId
                );

            if (server) {
                return server;
            }
        } catch {
            /*
             * Continue with database fallback.
             */
        }
    }

    /*
     * The current serverManager is built around
     * the database's user-owned server lookup.
     */
    if (
        typeof serverManager.getUserServer ===
        "function"
    ) {
        try {
            const server =
                serverManager.getUserServer(
                    discordId,
                    serverId
                );

            if (server) {
                return server;
            }
        } catch {
            /*
             * Continue with database fallback.
             */
        }
    }

    return null;
}

/* ============================================================
 * SERVER NAME
 * ============================================================
 */

function getCurrentServerName(server) {
    return (
        server?.name ||
        server?.identifier ||
        `Server #${server?.id ?? "Unknown"}`
    );
}

/* ============================================================
 * RENAME THROUGH SERVER MANAGER
 * ============================================================
 */

async function renameUserServer(
    discordId,
    serverId,
    newName
) {
    /*
     * This is the normal V2 path.
     *
     * serverManager.renameServer() already performs
     * the ownership validation and updates the
     * Pterodactyl/local server record.
     */
    if (
        typeof serverManager.renameServer ===
        "function"
    ) {
        return serverManager.renameServer(
            discordId,
            serverId,
            newName
        );
    }

    throw new Error(
        "The server rename service is unavailable."
    );
}

/* ============================================================
 * SUCCESS EMBED
 * ============================================================
 */

function buildSuccessEmbed(
    oldName,
    newName,
    serverId
) {
    const embed =
        createEmbed({
            title: "✅ Server Renamed",
            description:
                "Your server name has been successfully updated.",
            color: 0x57F287
        });

    embed.addFields(
        {
            name: "🖥️ Server ID",
            value:
                `\`${serverId}\``,
            inline: true
        },
        {
            name: "📝 Previous Name",
            value:
                `**${oldName}**`,
            inline: true
        },
        {
            name: "✨ New Name",
            value:
                `**${newName}**`,
            inline: false
        }
    );

    embed.setFooter({
        text:
            "HyperForgeX • Petro V2"
    });

    return embed;
}

/* ============================================================
 * CORE RENAME HANDLER
 * ============================================================
 */

async function handleRename(
    interaction,
    discordId,
    serverId,
    newName
) {
    const normalizedServerId =
        normalizeServerId(serverId);

    const normalizedName =
        normalizeName(newName);

    if (!normalizedServerId) {
        const embed =
            errorEmbed(
                "Missing Server ID",
                "Please provide the ID or identifier of the server you want to rename."
            );

        if (
            interaction.deferred ||
            interaction.replied
        ) {
            return interaction.editReply({
                embeds: [embed]
            });
        }

        return interaction.reply({
            embeds: [embed],
            ephemeral: true
        });
    }

    if (!normalizedName) {
        const embed =
            errorEmbed(
                "Missing Server Name",
                "Please provide a new name for your server."
            );

        if (
            interaction.deferred ||
            interaction.replied
        ) {
            return interaction.editReply({
                embeds: [embed]
            });
        }

        return interaction.reply({
            embeds: [embed],
            ephemeral: true
        });
    }

    if (normalizedName.length > 100) {
        const embed =
            errorEmbed(
                "Name Too Long",
                "The server name cannot be longer than **100 characters**."
            );

        if (
            interaction.deferred ||
            interaction.replied
        ) {
            return interaction.editReply({
                embeds: [embed]
            });
        }

        return interaction.reply({
            embeds: [embed],
            ephemeral: true
        });
    }

    try {
        /*
         * Get the current server first so the
         * response can show the old name.
         *
         * If the manager does not expose a lookup
         * helper, renameServer() remains responsible
         * for validating ownership.
         */
        let server =
            findUserServer(
                discordId,
                normalizedServerId
            );

        const oldName =
            getCurrentServerName(
                server
            );

        await renameUserServer(
            discordId,
            normalizedServerId,
            normalizedName
        );

        /*
         * If the lookup was unavailable, use the
         * requested ID in the success response.
         */
        const displayId =
            server?.id ??
            normalizedServerId;

        const embed =
            buildSuccessEmbed(
                oldName,
                normalizedName,
                displayId
            );

        if (
            interaction.deferred ||
            interaction.replied
        ) {
            return interaction.editReply({
                embeds: [embed]
            });
        }

        return interaction.reply({
            embeds: [embed],
            ephemeral: true
        });
    } catch (error) {
        console.error(
            "[Rename] Server rename failed:",
            error
        );

        const message =
            error?.message ||
            "The server could not be renamed. Please try again.";

        const embed =
            errorEmbed(
                "Rename Failed",
                message
            );

        if (
            interaction.deferred ||
            interaction.replied
        ) {
            return interaction.editReply({
                embeds: [embed]
            });
        }

        return interaction.reply({
            embeds: [embed],
            ephemeral: true
        });
    }
}

/* ============================================================
 * SLASH COMMAND
 *
 * /rename server:<id> name:<new name>
 * ============================================================
 */

export async function execute(
    interaction
) {
    const server =
        interaction.options.getString(
            "server",
            true
        );

    const newName =
        interaction.options.getString(
            "name",
            true
        );

    return handleRename(
        interaction,
        interaction.user.id,
        server,
        newName
    );
}

/* ============================================================
 * PREFIX COMMAND
 *
 * !rename <server-id> <new name>
 *
 * Example:
 * !rename 12 Survival Server
 * ============================================================
 */

export async function prefixExecute(
    message,
    args = []
) {
    if (!args.length) {
        return message.reply({
            embeds: [
                errorEmbed(
                    "Missing Arguments",
                    "Please provide the server ID and the new server name.\n\n" +
                    "**Usage:** `!rename <server-id> <new name>`\n\n" +
                    "**Example:** `!rename 12 Survival Server`"
                )
            ]
        });
    }

    const serverId =
        args.shift();

    const newName =
        normalizeName(
            args.join(" ")
        );

    if (!newName) {
        return message.reply({
            embeds: [
                errorEmbed(
                    "Missing Server Name",
                    "Please provide the new name for the server.\n\n" +
                    "**Usage:** `!rename <server-id> <new name>`"
                )
            ]
        });
    }

    return handleRename(
        message,
        message.author.id,
        serverId,
        newName
    );
}

/* ============================================================
 * DEFAULT EXPORT
 * ============================================================
 */

export default {
    name,
    description,
    aliases,
    data,
    execute,
    prefixExecute
};

/*
 * ============================================================
 * End of rename.js
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * PetroBot V2 - Rename Server Command
 * ============================================================
 */