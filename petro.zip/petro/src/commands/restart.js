/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */

import { SlashCommandBuilder } from "discord.js";
import { serverManager } from "../services/serverManager.js";
import { getUser } from "../services/userService.js";
import { successEmbed, errorEmbed } from "../utils/embeds.js";

export const data = new SlashCommandBuilder()
    .setName("restart")
    .setDescription("Restart your server.")
    .addStringOption(option =>
        option
            .setName("server_id")
            .setDescription("The Server ID of the server to restart.")
            .setRequired(true)
    )
    .setDMPermission(true);

export async function execute(interaction) {
    try {
        const serverId = interaction.options.getString("server_id", true);
        const user = getUser(interaction.user.id);

        if (!user) {
            return interaction.reply({
                embeds: [
                    errorEmbed(
                        "Account Not Found",
                        "Your account has not been registered yet."
                    )
                ],
                ephemeral: true
            });
        }

        await interaction.deferReply({ ephemeral: true });

        const server = serverManager.getOwnedServer(
            interaction.user.id,
            serverId
        );

        if (!server) {
            return interaction.editReply({
                embeds: [
                    errorEmbed(
                        "Server Not Found",
                        "The Server ID is invalid or this server does not belong to you."
                    )
                ]
            });
        }

        await serverManager.restartServer(server);

        return interaction.editReply({
            embeds: [
                successEmbed(
                    "Server Restarting",
                    `Server \`${server.name || serverId}\` is being restarted.\n\n**Server ID:** \`${serverId}\``
                )
            ]
        });
    } catch (error) {
        console.error("[Restart]", error);

        if (interaction.deferred || interaction.replied) {
            return interaction.editReply({
                embeds: [
                    errorEmbed(
                        "Failed to Restart Server",
                        error?.message || "An unexpected error occurred while restarting the server."
                    )
                ]
            });
        }

        return interaction.reply({
            embeds: [
                errorEmbed(
                    "Failed to Restart Server",
                    error?.message || "An unexpected error occurred while restarting the server."
                )
            ],
            ephemeral: true
        });
    }
}

export default {
    data,
    execute
};

/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */