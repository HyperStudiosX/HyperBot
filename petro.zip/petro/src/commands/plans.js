/*
 * ============================================================
 * PetroBot V2 - Hosting Plans Command
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */

import { getAllPlans } from "../plans.js";
import { createEmbed, errorEmbed } from "../utils/embeds.js";

/*
 * ============================================================
 * COMMAND INFORMATION
 * ============================================================
 */

export const name = "plans";
export const description = "View all available Petro V2 hosting plans.";

export const aliases = [
    "plan",
    "pricing",
    "price",
    "prices",
    "packages"
];

/*
 * ============================================================
 * CONSTANTS
 * ============================================================
 */

const MAX_PLANS = 5;

const EXTRA_RESOURCE_PRICES = {
    ram: {
        amount: 1,
        unit: "GB",
        price: 100
    },
    cpu: {
        amount: 100,
        unit: "%",
        price: 100
    },
    disk: {
        amount: 5,
        unit: "GB",
        price: 100
    },
    allocations: {
        amount: 1,
        unit: "",
        price: 100
    },
    databases: {
        amount: 1,
        unit: "",
        price: 100
    },
    backups: {
        amount: 1,
        unit: "",
        price: 100
    },
    serverSlots: {
        amount: 1,
        unit: "",
        price: 100
    }
};

/*
 * ============================================================
 * HELPERS
 * ============================================================
 */

/**
 * Convert megabytes to a readable GB value.
 *
 * @param {number} value
 * @returns {string}
 */
function mbToGb(value) {
    const number = Number(value);

    if (!Number.isFinite(number) || number <= 0) {
        return "0 GB";
    }

    const gb = number / 1024;

    if (Number.isInteger(gb)) {
        return `${gb} GB`;
    }

    return `${gb.toFixed(1).replace(/\.0$/, "")} GB`;
}

/**
 * Format a number safely.
 *
 * @param {number} value
 * @returns {string}
 */
function formatNumber(value) {
    const number = Number(value);

    if (!Number.isFinite(number)) {
        return "0";
    }

    return number.toLocaleString("en-US");
}

/**
 * Get a plan ID while supporting the different naming styles
 * used by the database and plan configuration.
 *
 * @param {object} plan
 * @param {number} index
 * @returns {string}
 */
function getPlanId(plan, index) {
    const value =
        plan?.id ??
        plan?.planId ??
        plan?.plan_id ??
        `plan${index + 1}`;

    return String(value);
}

/**
 * Get a plan display name.
 *
 * @param {object} plan
 * @param {number} index
 * @returns {string}
 */
function getPlanName(plan, index) {
    const value =
        plan?.name ??
        plan?.displayName ??
        plan?.display_name ??
        `Plan ${index + 1}`;

    return String(value);
}

/**
 * Get the plan price.
 *
 * @param {object} plan
 * @returns {number}
 */
function getPlanPrice(plan) {
    const price =
        plan?.price ??
        plan?.cost ??
        plan?.coins ??
        plan?.coinCost ??
        plan?.coin_cost ??
        0;

    const number = Number(price);

    return Number.isFinite(number) ? number : 0;
}

/**
 * Get RAM in MB.
 *
 * @param {object} plan
 * @returns {number}
 */
function getRam(plan) {
    const value =
        plan?.ram ??
        plan?.ramMb ??
        plan?.ram_mb ??
        plan?.memory ??
        plan?.memoryMb ??
        plan?.memory_mb ??
        0;

    const number = Number(value);

    return Number.isFinite(number) ? number : 0;
}

/**
 * Get CPU percentage.
 *
 * @param {object} plan
 * @returns {number}
 */
function getCpu(plan) {
    const value =
        plan?.cpu ??
        plan?.cpuPercent ??
        plan?.cpu_percent ??
        0;

    const number = Number(value);

    return Number.isFinite(number) ? number : 0;
}

/**
 * Get disk in MB.
 *
 * @param {object} plan
 * @returns {number}
 */
function getDisk(plan) {
    const value =
        plan?.disk ??
        plan?.diskMb ??
        plan?.disk_mb ??
        plan?.storage ??
        plan?.storageMb ??
        plan?.storage_mb ??
        0;

    const number = Number(value);

    return Number.isFinite(number) ? number : 0;
}

/**
 * Get backups.
 *
 * @param {object} plan
 * @returns {number}
 */
function getBackups(plan) {
    const value =
        plan?.backups ??
        plan?.backup ??
        0;

    const number = Number(value);

    return Number.isFinite(number) ? number : 0;
}

/**
 * Get allocations.
 *
 * @param {object} plan
 * @returns {number}
 */
function getAllocations(plan) {
    const value =
        plan?.allocations ??
        plan?.allocation ??
        0;

    const number = Number(value);

    return Number.isFinite(number) ? number : 0;
}

/**
 * Get databases.
 *
 * @param {object} plan
 * @returns {number}
 */
function getDatabases(plan) {
    const value =
        plan?.databases ??
        plan?.database ??
        0;

    const number = Number(value);

    return Number.isFinite(number) ? number : 0;
}

/**
 * Get server slots.
 *
 * @param {object} plan
 * @returns {number}
 */
function getServerSlots(plan) {
    const value =
        plan?.serverSlots ??
        plan?.server_slots ??
        plan?.slots ??
        plan?.serverSlot ??
        0;

    const number = Number(value);

    return Number.isFinite(number) ? number : 0;
}

/**
 * Get the plan description.
 *
 * @param {object} plan
 * @param {number} index
 * @returns {string}
 */
function getPlanDescription(plan, index) {
    if (plan?.description) {
        return String(plan.description);
    }

    const descriptions = [
        "Starter Minecraft hosting plan.",
        "Balanced hosting for growing servers.",
        "High-performance hosting for larger servers.",
        "Powerful hosting for large Minecraft networks.",
        "Maximum resources for demanding servers."
    ];

    return descriptions[index] ?? "Minecraft hosting plan.";
}

/**
 * Normalize a plan into one predictable object.
 *
 * @param {object} plan
 * @param {number} index
 * @returns {object}
 */
function normalizePlan(plan, index) {
    return {
        id: getPlanId(plan, index),
        name: getPlanName(plan, index),
        price: getPlanPrice(plan),
        ram: getRam(plan),
        cpu: getCpu(plan),
        disk: getDisk(plan),
        backups: getBackups(plan),
        allocations: getAllocations(plan),
        databases: getDatabases(plan),
        serverSlots: getServerSlots(plan),
        description: getPlanDescription(plan, index)
    };
}

/**
 * Get exactly five plans.
 *
 * The V2 plan system intentionally exposes only five plans.
 *
 * @returns {object[]}
 */
function getFivePlans() {
    let plans;

    try {
        plans = getAllPlans();
    } catch {
        plans = [];
    }

    if (!Array.isArray(plans)) {
        plans = [];
    }

    return plans
        .slice(0, MAX_PLANS)
        .map((plan, index) => normalizePlan(plan, index));
}

/**
 * Build one plan field.
 *
 * @param {object} plan
 * @param {number} index
 * @returns {object}
 */
function buildPlanField(plan, index) {
    const planNumber = index + 1;

    return {
        name:
            `🟦 ${plan.name} • ${formatNumber(plan.price)} Coins`,
        value:
            `> 🆔 **Plan ID:** \`${plan.id}\`\n` +
            `> 🧠 **RAM:** ${mbToGb(plan.ram)}\n` +
            `> ⚙️ **CPU:** ${formatNumber(plan.cpu)}%\n` +
            `> 💾 **Disk:** ${mbToGb(plan.disk)}\n` +
            `> 🌐 **Allocations:** ${formatNumber(plan.allocations)}\n` +
            `> 🗄️ **Databases:** ${formatNumber(plan.databases)}\n` +
            `> 💿 **Backups:** ${formatNumber(plan.backups)}\n` +
            `> 🖥️ **Server Slots:** ${formatNumber(plan.serverSlots)}\n` +
            `> 📋 **Description:** ${plan.description}\n` +
            `> 🛒 **Purchase:** \`!buy ${plan.id}\``,
        inline: false
    };
}

/**
 * Build the extra resource pricing field.
 *
 * @returns {object}
 */
function buildResourcePricingField() {
    const ram = EXTRA_RESOURCE_PRICES.ram;
    const cpu = EXTRA_RESOURCE_PRICES.cpu;
    const disk = EXTRA_RESOURCE_PRICES.disk;
    const allocations = EXTRA_RESOURCE_PRICES.allocations;
    const databases = EXTRA_RESOURCE_PRICES.databases;
    const backups = EXTRA_RESOURCE_PRICES.backups;
    const serverSlots = EXTRA_RESOURCE_PRICES.serverSlots;

    return {
        name: "💰 Extra Resource Pricing",
        value:
            `> 🧠 **RAM:** +${ram.amount} ${ram.unit} = **${formatNumber(ram.price)} coins**\n` +
            `> ⚙️ **CPU:** +${cpu.amount}${cpu.unit} = **${formatNumber(cpu.price)} coins**\n` +
            `> 💾 **Disk:** +${disk.amount} ${disk.unit} = **${formatNumber(disk.price)} coins**\n` +
            `> 🌐 **Allocation:** +${allocations.amount} = **${formatNumber(allocations.price)} coins**\n` +
            `> 🗄️ **Database:** +${databases.amount} = **${formatNumber(databases.price)} coins**\n` +
            `> 💿 **Backup:** +${backups.amount} = **${formatNumber(backups.price)} coins**\n` +
            `> 🖥️ **Server Slot:** +${serverSlots.amount} = **${formatNumber(serverSlots.price)} coins**`,
        inline: false
    };
}

/**
 * Build the purchase instructions field.
 *
 * @param {object[]} plans
 * @returns {object}
 */
function buildPurchaseField(plans) {
    const commands = plans.map(
        plan => `\`!buy ${plan.id}\` — ${plan.name}`
    );

    return {
        name: "🛒 How To Purchase",
        value:
            "Purchase a plan using your coins.\n\n" +
            commands.join("\n") +
            "\n\n" +
            "After purchasing a plan, its RAM, CPU and disk resources " +
            "are added to your available hosting resources.",
        inline: false
    };
}

/**
 * Build the plan list embed.
 *
 * @param {object[]} plans
 * @returns {object}
 */
function buildPlansEmbed(plans) {
    const embed = createEmbed({
        title: "🛒 Petro V2 Hosting Plans",
        description:
            "Choose one of the **5 available hosting plans**.\n" +
            "Plans are purchased using your **coin balance**.\n\n" +
            "Use `!buy <planid>` to purchase a plan.",
        color: 0x5865F2
    });

    for (let index = 0; index < plans.length; index++) {
        embed.addFields(buildPlanField(plans[index], index));
    }

    embed.addFields(buildResourcePricingField());
    embed.addFields(buildPurchaseField(plans));

    embed.setFooter({
        text: "HyperForgeX • Petro V2 • 5 Plans Available"
    });

    return embed;
}

/*
 * ============================================================
 * PREFIX COMMAND
 * ============================================================
 */

/**
 * Execute the !plans command.
 *
 * @param {import("discord.js").Message} message
 */
export async function execute(message) {
    try {
        const plans = getFivePlans();

        if (plans.length === 0) {
            await message.reply({
                embeds: [
                    errorEmbed(
                        "Plans Unavailable",
                        "No hosting plans are currently configured."
                    )
                ]
            });

            return;
        }

        const embed = buildPlansEmbed(plans);

        await message.reply({
            embeds: [embed]
        });
    } catch (error) {
        console.error("[Plans] Failed to display plans:", error);

        try {
            await message.reply({
                embeds: [
                    errorEmbed(
                        "Plans Error",
                        "I could not load the hosting plans right now. Please try again."
                    )
                ]
            });
        } catch (replyError) {
            console.error(
                "[Plans] Failed to send error message:",
                replyError
            );
        }
    }
}

/*
 * ============================================================
 * SLASH COMMAND COMPATIBILITY
 * ============================================================
 */

export const data = {
    name: "plans",
    description: "View all available Petro V2 hosting plans."
};

/**
 * Execute slash /plans.
 *
 * @param {import("discord.js").ChatInputCommandInteraction} interaction
 */
export async function executeSlash(interaction) {
    try {
        const plans = getFivePlans();

        if (plans.length === 0) {
            await interaction.reply({
                embeds: [
                    errorEmbed(
                        "Plans Unavailable",
                        "No hosting plans are currently configured."
                    )
                ],
                ephemeral: true
            });

            return;
        }

        const embed = buildPlansEmbed(plans);

        await interaction.reply({
            embeds: [embed]
        });
    } catch (error) {
        console.error(
            "[Plans] Failed to execute slash command:",
            error
        );

        const payload = {
            embeds: [
                errorEmbed(
                    "Plans Error",
                    "I could not load the hosting plans right now. Please try again."
                )
            ],
            ephemeral: true
        };

        if (interaction.replied || interaction.deferred) {
            await interaction.followUp(payload).catch(() => {});
        } else {
            await interaction.reply(payload).catch(() => {});
        }
    }
}

/*
 * ============================================================
 * DEFAULT EXPORT
 * ============================================================
 */

const plansCommand = {
    name,
    description,
    aliases,
    data,
    execute,
    executeSlash
};

export default plansCommand;

/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */