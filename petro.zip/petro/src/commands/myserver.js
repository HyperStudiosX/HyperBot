/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */

import {
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    StringSelectMenuBuilder,
    SlashCommandBuilder
} from "discord.js";

import {
    getUserServers,
    ensureUser
} from "../services/userService.js";

import {
    serverManager
} from "../services/serverManager.js";

import {
    infoEmbed,
    errorEmbed
} from "../utils/embeds.js";

import {
    config
} from "../config.js";

/*
 * ============================================================
 * COMMAND INFORMATION
 * ============================================================
 */

export const name =
    "myserver";

export const aliases = [
    "myservers",
    "servers"
];

/*
 * ============================================================
 * SLASH COMMAND
 * ============================================================
 */

export const data =
    new SlashCommandBuilder()
        .setName("myserver")
        .setDescription(
            "View your Minecraft servers."
        )
        .setDMPermission(true);

/*
 * ============================================================
 * MAIN EXECUTE
 * ============================================================
 */

export async function execute(
    interaction
) {
    try {
        const discordId =
            interaction.user.id;

        ensureUser(
            discordId,
            interaction.user.username
        );

        const servers =
            getUserServers(
                discordId
            );

        if (
            !servers.length
        ) {
            return interaction.reply({
                embeds: [
                    infoEmbed(
                        "🖥️ My Servers",
                        "You don't have any servers yet.\n\n" +
                        `Use \`${config.PREFIX}deploy\` to deploy your first server.`
                    )
                ],
                ephemeral: true
            });
        }

        return sendServerSelector(
            interaction,
            servers
        );
    } catch (error) {
        console.error(
            "[MyServer]",
            error
        );

        return replyError(
            interaction,
            error
        );
    }
}

/*
 * ============================================================
 * PREFIX COMMAND
 * ============================================================
 *
 * Supported:
 *
 * !myserver
 * !myservers
 *
 * Optional:
 *
 * !myserver <server_id>
 */

export async function prefixExecute(
    message,
    args = []
) {
    try {
        const discordId =
            message.author.id;

        ensureUser(
            discordId,
            message.author.username
        );

        const suppliedId =
            String(
                args[0] ||
                ""
            ).trim();

        /*
         * Direct server lookup.
         */
        if (
            suppliedId
        ) {
            const server =
                serverManager.getOwnedServer(
                    discordId,
                    suppliedId
                );

            if (!server) {
                return message.reply({
                    embeds: [
                        errorEmbed(
                            "Server Not Found",
                            "I couldn't find a server with that ID belonging to you."
                        )
                    ]
                });
            }

            return sendServerDetails(
                message,
                server
            );
        }

        const servers =
            getUserServers(
                discordId
            );

        if (
            !servers.length
        ) {
            return message.reply({
                embeds: [
                    infoEmbed(
                        "🖥️ My Servers",
                        "You don't have any servers yet.\n\n" +
                        `Use \`${config.PREFIX}deploy\` to deploy your first server.`
                    )
                ]
            });
        }

        return sendServerSelector(
            message,
            servers
        );
    } catch (error) {
        console.error(
            "[MyServer Prefix]",
            error
        );

        return message.reply({
            embeds: [
                errorEmbed(
                    "MyServer Error",
                    error?.message ||
                    "Unable to load your servers."
                )
            ]
        });
    }
}

/*
 * ============================================================
 * SERVER SELECTOR
 * ============================================================
 */

async function sendServerSelector(
    target,
    servers
) {
    /*
     * Discord select menus support a maximum of 25 options.
     */
    const visibleServers =
        servers.slice(
            0,
            25
        );

    const options =
        visibleServers.map(
            server => ({
                label:
                    truncate(
                        server?.name ||
                        `Server ${server?.id}`,
                        100
                    ),

                description:
                    truncate(
                        `Server ID: ${server?.id} • ${formatStatus(server?.status)}`,
                        100
                    ),

                value:
                    String(
                        server?.id
                    ),

                emoji:
                    statusEmoji(
                        server?.status
                    )
            })
        );

    const menu =
        new StringSelectMenuBuilder()
            .setCustomId(
                "myserver_select"
            )
            .setPlaceholder(
                "Select a server"
            )
            .setMinValues(1)
            .setMaxValues(1)
            .addOptions(
                options
            );

    const row =
        new ActionRowBuilder()
            .addComponents(
                menu
            );

    let description =
        [
            "## 🖥️ Your Minecraft Servers",
            "",
            `You currently have **${servers.length}** server${servers.length === 1 ? "" : "s"}.`,
            "",
            "Select a server below to view its details.",
            "",
            "You can also use:",
            `\`${config.PREFIX}myserver <server_id>\``
        ].join(
            "\n"
        );

    if (
        servers.length > 25
    ) {
        description +=
            `\n\n⚠️ Only the first 25 servers are shown in the menu.`;
    }

    const embed =
        infoEmbed(
            "🖥️ My Servers",
            description
        );

    if (
        typeof target.isChatInputCommand ===
            "function" &&
        target.isChatInputCommand()
    ) {
        return target.reply({
            embeds: [
                embed
            ],
            components: [
                row
            ],
            ephemeral: true
        });
    }

    return target.reply({
        embeds: [
            embed
        ],
        components: [
            row
        ]
    });
}

/*
 * ============================================================
 * HANDLE SERVER SELECTION
 * ============================================================
 *
 * index.js routes:
 *
 * myserver_select
 *
 * to this function.
 */

export async function handleServerSelection(
    interaction
) {
    try {
        if (
            !interaction.isStringSelectMenu()
        ) {
            return false;
        }

        if (
            interaction.customId !==
            "myserver_select"
        ) {
            return false;
        }

        const selectedId =
            interaction.values?.[0];

        if (
            !selectedId
        ) {
            await interaction.update({
                embeds: [
                    errorEmbed(
                        "No Server Selected",
                        "Please select a server."
                    )
                ],
                components: []
            });

            return true;
        }

        /*
         * IMPORTANT:
         *
         * The select menu stores the LOCAL DATABASE SERVER ID.
         *
         * We then verify ownership before displaying anything.
         */
        const server =
            serverManager.getOwnedServer(
                interaction.user.id,
                selectedId
            );

        if (!server) {
            await interaction.update({
                embeds: [
                    errorEmbed(
                        "Server Not Found",
                        "That server does not exist or does not belong to you."
                    )
                ],
                components: []
            });

            return true;
        }

        return sendServerDetails(
            interaction,
            server,
            true
        );
    } catch (error) {
        console.error(
            "[MyServer Selection]",
            error
        );

        if (
            interaction.deferred ||
            interaction.replied
        ) {
            await interaction.editReply({
                embeds: [
                    errorEmbed(
                        "Server Error",
                        error?.message ||
                        "Unable to load the selected server."
                    )
                ],
                components: []
            });

            return true;
        }

        await interaction.reply({
            embeds: [
                errorEmbed(
                    "Server Error",
                    error?.message ||
                    "Unable to load the selected server."
                )
            ],
            ephemeral: true
        });

        return true;
    }
}

/*
 * ============================================================
 * SERVER DETAILS
 * ============================================================
 */

async function sendServerDetails(
    target,
    server,
    update = false
) {
    const panelId =
        server?.pterodactyl_id ??
        server?.pterodactylId ??
        "Unknown";

    const identifier =
        server?.identifier ||
        "Unknown";

    const name =
        server?.name ||
        "Minecraft Server";

    const status =
        formatStatus(
            server?.status
        );

    const plan =
        server?.plan_name ??
        server?.plan ??
        server?.plan_id ??
        "Custom";

    const nodeId =
        server?.node_id ??
        server?.nodeId ??
        "Unknown";

    const allocationId =
        server?.allocation_id ??
        server?.allocationId ??
        "Unknown";

    const ram =
        formatStorage(
            server?.ram
        );

    const disk =
        formatStorage(
            server?.disk
        );

    const cpu =
        Number(
            server?.cpu ||
            0
        );

    const backups =
        Number(
            server?.backups ||
            0
        );

    const allocations =
        Number(
            server?.allocations ||
            0
        );

    const databases =
        Number(
            server?.databases ||
            0
        );

    const slots =
        Number(
            server?.server_slots ??
            1
        );

    const description =
        [
            `## 🖥️ ${name}`,
            "",
            `**Status:** ${status}`,
            "",
            "**Server Information**",
            `> 🆔 Local Server ID: \`${server?.id ?? "Unknown"}\``,
            `> 🔢 Pterodactyl ID: \`${panelId}\``,
            `> 🔑 Identifier: \`${identifier}\``,
            `> 🧩 Plan: \`${plan}\``,
            `> 🖥️ Node ID: \`${nodeId}\``,
            `> 🔌 Allocation ID: \`${allocationId}\``,
            "",
            "**Resources**",
            `> 🧠 RAM: \`${ram}\``,
            `> ⚡ CPU: \`${cpu.toLocaleString()}%\``,
            `> 💾 Disk: \`${disk}\``,
            `> 📦 Backups: \`${backups}\``,
            `> 🔌 Allocations: \`${allocations}\``,
            `> 🗄️ Databases: \`${databases}\``,
            `> 🖥️ Server Slots: \`${slots}\``
        ].join(
            "\n"
        );

    const embed =
        infoEmbed(
            "🖥️ Server Details",
            description
        );

    /*
     * ----------------------------------------------------------
     * BUTTONS
     * ----------------------------------------------------------
     *
     * These use the same custom IDs handled by index.js.
     */

    const row =
        new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(
                        `server_start:${server.id}`
                    )
                    .setLabel(
                        "Start"
                    )
                    .setEmoji(
                        "▶️"
                    )
                    .setStyle(
                        ButtonStyle.Success
                    ),

                new ButtonBuilder()
                    .setCustomId(
                        `server_restart:${server.id}`
                    )
                    .setLabel(
                        "Restart"
                    )
                    .setEmoji(
                        "🔄"
                    )
                    .setStyle(
                        ButtonStyle.Primary
                    ),

                new ButtonBuilder()
                    .setCustomId(
                        `server_stop:${server.id}`
                    )
                    .setLabel(
                        "Stop"
                    )
                    .setEmoji(
                        "⏹️"
                    )
                    .setStyle(
                        ButtonStyle.Danger
                    ),

                new ButtonBuilder()
                    .setCustomId(
                        `server_info:${server.id}`
                    )
                    .setLabel(
                        "Info"
                    )
                    .setEmoji(
                        "📋"
                    )
                    .setStyle(
                        ButtonStyle.Secondary
                    ),

                new ButtonBuilder()
                    .setCustomId(
                        `server_back:${server.id}`
                    )
                    .setLabel(
                        "Back"
                    )
                    .setEmoji(
                        "↩️"
                    )
                    .setStyle(
                        ButtonStyle.Secondary
                    )
            );

    const deleteRow =
        new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(
                        `server_rename:${server.id}`
                    )
                    .setLabel(
                        "Rename"
                    )
                    .setEmoji(
                        "✏️"
                    )
                    .setStyle(
                        ButtonStyle.Secondary
                    ),

                new ButtonBuilder()
                    .setCustomId(
                        `server_delete:${server.id}`
                    )
                    .setLabel(
                        "Delete"
                    )
                    .setEmoji(
                        "🗑️"
                    )
                    .setStyle(
                        ButtonStyle.Danger
                    )
            );

    const components = [
        row,
        deleteRow
    ];

    if (
        update
    ) {
        return target.update({
            embeds: [
                embed
            ],
            components
        });
    }

    if (
        typeof target.isChatInputCommand ===
            "function" &&
        target.isChatInputCommand()
    ) {
        return target.reply({
            embeds: [
                embed
            ],
            components,
            ephemeral: true
        });
    }

    return target.reply({
        embeds: [
            embed
        ],
        components
    });
}

/*
 * ============================================================
 * STATUS
 * ============================================================
 */

function formatStatus(
    status
) {
    const value =
        String(
            status ||
            "unknown"
        )
        .trim()
        .toLowerCase();

    const labels = {
        online:
            "🟢 Online",

        running:
            "🟢 Running",

        active:
            "🟢 Active",

        starting:
            "🟡 Starting",

        stopping:
            "🟠 Stopping",

        offline:
            "🔴 Offline",

        stopped:
            "🔴 Stopped",

        suspended:
            "⛔ Suspended",

        installing:
            "🔵 Installing",

        restoring:
            "🔵 Restoring",

        unknown:
            "⚪ Unknown"
    };

    return (
        labels[value] ||
        `⚪ ${capitalize(value)}`
    );
}

/*
 * ============================================================
 * STATUS EMOJI
 * ============================================================
 */

function statusEmoji(
    status
) {
    const value =
        String(
            status ||
            "unknown"
        )
        .trim()
        .toLowerCase();

    const icons = {
        online:
            "🟢",

        running:
            "🟢",

        active:
            "🟢",

        starting:
            "🟡",

        stopping:
            "🟠",

        offline:
            "🔴",

        stopped:
            "🔴",

        suspended:
            "⛔",

        installing:
            "🔵",

        restoring:
            "🔵",

        unknown:
            "⚪"
    };

    return (
        icons[value] ||
        "⚪"
    );
}

/*
 * ============================================================
 * STORAGE FORMAT
 * ============================================================
 */

function formatStorage(
    value
) {
    const mb =
        Number(
            value ||
            0
        );

    if (
        !Number.isFinite(
            mb
        ) ||
        mb <= 0
    ) {
        return "0 MB";
    }

    if (
        mb % 1024 ===
        0
    ) {
        return `${mb / 1024} GB`;
    }

    if (
        mb >= 1024
    ) {
        return `${(mb / 1024).toFixed(1)} GB`;
    }

    return `${mb} MB`;
}

/*
 * ============================================================
 * TEXT HELPERS
 * ============================================================
 */

function truncate(
    value,
    maxLength
) {
    const text =
        String(
            value ??
            ""
        );

    if (
        text.length <=
        maxLength
    ) {
        return text;
    }

    return (
        text.slice(
            0,
            maxLength - 3
        ) +
        "..."
    );
}

function capitalize(
    value
) {
    const text =
        String(
            value ||
            ""
        );

    if (!text) {
        return "Unknown";
    }

    return (
        text.charAt(0).toUpperCase() +
        text.slice(1)
    );
}

/*
 * ============================================================
 * ERROR HANDLER
 * ============================================================
 */

async function replyError(
    target,
    error
) {
    const embed =
        errorEmbed(
            "MyServer Error",
            error?.message ||
            "An unexpected error occurred while loading your servers."
        );

    try {
        if (
            target.deferred ||
            target.replied
        ) {
            return target.editReply({
                embeds: [
                    embed
                ],
                components: []
            });
        }

        return target.reply({
            embeds: [
                embed
            ],
            components: [],
            ephemeral: true
        });
    } catch {
        return null;
    }
}

/*
 * ============================================================
 * EXPORT
 * ============================================================
 */

export default {
    data,
    name,
    aliases,
    execute,
    prefixExecute,
    handleServerSelection
};

/*
 * ============================================================
 * End of myserver.js
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * PetroBot V2 MyServer Command.
 * ============================================================
 */