/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */

import { SlashCommandBuilder } from "discord.js";
import { serverManager } from "../services/serverManager.js";
import { getUser } from "../services/userService.js";
import { serverEmbed, errorEmbed } from "../utils/embeds.js";

export const data = new SlashCommandBuilder()
    .setName("serverinfo")
    .setDescription("View detailed information about your server.")
    .addStringOption(option =>
        option
            .setName("server_id")
            .setDescription("The Server ID of the server.")
            .setRequired(true)
    )
    .setDMPermission(true);

export async function execute(interaction) {
    try {
        const serverId = interaction.options.getString("server_id", true);
        const user = getUser(interaction.user.id);

        if (!user) {
            return interaction.reply({
                embeds: [
                    errorEmbed(
                        "Account Not Found",
                        "Your account has not been registered yet."
                    )
                ],
                ephemeral: true
            });
        }

        await interaction.deferReply({ ephemeral: true });

        const server = serverManager.getOwnedServer(
            interaction.user.id,
            serverId
        );

        if (!server) {
            return interaction.editReply({
                embeds: [
                    errorEmbed(
                        "Server Not Found",
                        "The Server ID is invalid or this server does not belong to you."
                    )
                ]
            });
        }

        const info = await serverManager.getServerInfo(server);

        return interaction.editReply({
            embeds: [
                serverEmbed(
                    info.name || server.name || "Server Information",
                    {
                        "Server ID": info.id || server.id,
                        "UUID": info.uuid || "Unavailable",
                        "Status": info.status || "Unknown",
                        "Plan": info.plan || server.plan || "Unknown",
                        "Node": info.node || "Unknown",
                        "Location": info.location || "Unknown",
                        "Memory": info.memory || "Unknown",
                        "CPU": info.cpu || "Unknown",
                        "Disk": info.disk || "Unknown"
                    }
                )
            ]
        });
    } catch (error) {
        console.error("[ServerInfo]", error);

        if (interaction.deferred || interaction.replied) {
            return interaction.editReply({
                embeds: [
                    errorEmbed(
                        "Failed to Get Server Information",
                        error?.message || "An unexpected error occurred while retrieving server information."
                    )
                ]
            });
        }

        return interaction.reply({
            embeds: [
                errorEmbed(
                    "Failed to Get Server Information",
                    error?.message || "An unexpected error occurred while retrieving server information."
                )
            ],
            ephemeral: true
        });
    }
}

export default {
    data,
    execute
};

/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */