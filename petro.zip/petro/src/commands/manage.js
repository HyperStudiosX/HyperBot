/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */

import {
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    StringSelectMenuBuilder,
    SlashCommandBuilder
} from "discord.js";

import {
    getUserServers,
    ensureUser
} from "../services/userService.js";

import {
    serverManager,
    ServerManagerError
} from "../services/serverManager.js";

import {
    config
} from "../config.js";

import {
    successEmbed,
    errorEmbed,
    infoEmbed
} from "../utils/embeds.js";

/*
 * ============================================================
 * COMMAND INFORMATION
 * ============================================================
 */

export const name =
    "manage";

export const aliases = [
    "server",
    "control"
];

/*
 * ============================================================
 * SLASH COMMAND
 * ============================================================
 */

export const data =
    new SlashCommandBuilder()
        .setName("manage")
        .setDescription(
            "Manage one of your Pterodactyl servers."
        )
        .setDMPermission(true);

/*
 * ============================================================
 * COMMAND EXECUTE
 * ============================================================
 */

export async function execute(
    interaction
) {
    try {
        const discordId =
            interaction.user.id;

        ensureUser(
            discordId,
            interaction.user.username
        );

        const servers =
            getUserServers(
                discordId
            );

        if (
            !Array.isArray(servers) ||
            servers.length === 0
        ) {
            return interaction.reply({
                embeds: [
                    infoEmbed(
                        "No Servers",
                        "You don't have any servers to manage yet.\n\n" +
                        `Use \`${config.PREFIX}deploy\` to deploy a server.`
                    )
                ],
                ephemeral: true
            });
        }

        return sendManageMenu(
            interaction,
            servers,
            false
        );
    } catch (error) {
        console.error(
            "[Manage]",
            error
        );

        return replyError(
            interaction,
            error
        );
    }
}

/*
 * ============================================================
 * PREFIX COMMAND
 * ============================================================
 *
 * Supported:
 *
 * !manage
 * !server
 * !control
 *
 * The command loader supports aliases, so all aliases point
 * back to this same implementation.
 */

export async function prefixExecute(
    message,
    args = []
) {
    try {
        const discordId =
            message.author.id;

        ensureUser(
            discordId,
            message.author.username
        );

        /*
         * If a server ID was supplied directly:
         *
         * !manage 12
         *
         * open that server immediately.
         */
        const suppliedId =
            String(
                args[0] ||
                ""
            ).trim();

        if (
            suppliedId
        ) {
            const server =
                serverManager.getOwnedServer(
                    discordId,
                    suppliedId
                );

            if (!server) {
                return message.reply({
                    embeds: [
                        errorEmbed(
                            "Server Not Found",
                            "I could not find a server with that ID belonging to you."
                        )
                    ]
                });
            }

            return sendServerControlPanel(
                message,
                server
            );
        }

        const servers =
            getUserServers(
                discordId
            );

        if (
            !Array.isArray(servers) ||
            servers.length === 0
        ) {
            return message.reply({
                embeds: [
                    infoEmbed(
                        "No Servers",
                        "You don't have any servers to manage yet.\n\n" +
                        `Use \`${config.PREFIX}deploy\` to deploy a server.`
                    )
                ]
            });
        }

        return sendManageMenu(
            message,
            servers,
            true
        );
    } catch (error) {
        console.error(
            "[Manage Prefix]",
            error
        );

        return message.reply({
            embeds: [
                errorEmbed(
                    "Manage Error",
                    error?.message ||
                    "Unable to open the server management menu."
                )
            ]
        });
    }
}

/*
 * ============================================================
 * SEND MANAGE MENU
 * ============================================================
 */

async function sendManageMenu(
    target,
    servers,
    isPrefix = false
) {
    const limitedServers =
        servers.slice(
            0,
            25
        );

    const options =
        limitedServers.map(
            server => ({
                label:
                    truncate(
                        server?.name ||
                        `Server ${server?.id}`,
                        100
                    ),

                description:
                    truncate(
                        `ID: ${server?.id} • ${formatStatusText(server?.status)}`,
                        100
                    ),

                value:
                    String(
                        server?.id
                    ),

                emoji:
                    getStatusEmoji(
                        server?.status
                    )
            })
        );

    const select =
        new StringSelectMenuBuilder()
            .setCustomId(
                "manage_server_select"
            )
            .setPlaceholder(
                "Select a server to manage"
            )
            .setMinValues(1)
            .setMaxValues(1)
            .addOptions(
                options
            );

    const row =
        new ActionRowBuilder()
            .addComponents(
                select
            );

    const description =
        [
            "Select one of your Pterodactyl servers below.",
            "",
            `🖥️ **Servers:** ${servers.length}`,
            "",
            "You can start, stop, restart, inspect, rename, or delete your server from the management panel."
        ].join(
            "\n"
        );

    const embed =
        infoEmbed(
            "🛠️ Server Management",
            description
        );

    /*
     * If there are more than 25 servers, Discord's select
     * menu cannot contain every server. Tell the user that
     * they can directly use the server ID.
     */
    if (
        servers.length > 25
    ) {
        embed.setFooter({
            text:
                `Showing the first 25 servers. Use ${config.PREFIX}manage <server_id> for another server.`
        });
    }

    if (
        isPrefix
    ) {
        return target.reply({
            embeds: [
                embed
            ],
            components: [
                row
            ]
        });
    }

    return target.reply({
        embeds: [
            embed
        ],
        components: [
            row
        ],
        ephemeral: true
    });
}

/*
 * ============================================================
 * HANDLE MANAGE SELECTION
 * ============================================================
 *
 * This function is called by index.js when the user selects
 * an item from:
 *
 * customId = manage_server_select
 *
 * The selected value is the LOCAL DATABASE SERVER ID.
 */

export async function handleManageSelection(
    interaction
) {
    try {
        if (
            !interaction.isStringSelectMenu()
        ) {
            return false;
        }

        if (
            interaction.customId !==
            "manage_server_select"
        ) {
            return false;
        }

        const selectedId =
            interaction.values?.[0];

        if (
            !selectedId
        ) {
            await interaction.update({
                embeds: [
                    errorEmbed(
                        "No Server Selected",
                        "Please select a server from the menu."
                    )
                ],
                components: []
            });

            return true;
        }

        const server =
            serverManager.getOwnedServer(
                interaction.user.id,
                selectedId
            );

        if (!server) {
            await interaction.update({
                embeds: [
                    errorEmbed(
                        "Server Not Found",
                        "That server does not exist or does not belong to you."
                    )
                ],
                components: []
            });

            return true;
        }

        return sendServerControlPanel(
            interaction,
            server,
            true
        );
    } catch (error) {
        console.error(
            "[Manage Selection]",
            error
        );

        if (
            interaction.deferred ||
            interaction.replied
        ) {
            await interaction.editReply({
                embeds: [
                    errorEmbed(
                        "Management Error",
                        error?.message ||
                        "Unable to open the selected server."
                    )
                ],
                components: []
            });

            return true;
        }

        await interaction.reply({
            embeds: [
                errorEmbed(
                    "Management Error",
                    error?.message ||
                    "Unable to open the selected server."
                )
            ],
            ephemeral: true
        });

        return true;
    }
}

/*
 * ============================================================
 * SERVER CONTROL PANEL
 * ============================================================
 */

async function sendServerControlPanel(
    target,
    server,
    update = false
) {
    const panelId =
        server?.pterodactyl_id ??
        server?.pterodactylId ??
        null;

    const identifier =
        server?.identifier ||
        null;

    const status =
        formatStatusText(
            server?.status
        );

    const plan =
        server?.plan_name ??
        server?.plan ??
        server?.plan_id ??
        "Custom";

    const description =
        [
            `## 🖥️ ${server?.name || "Minecraft Server"}`,
            "",
            `**Server ID:** \`${server?.id ?? "Unknown"}\``,
            `**Pterodactyl ID:** \`${panelId ?? "Unknown"}\``,
            `**Identifier:** \`${identifier || "Unknown"}\``,
            `**Status:** ${getStatusEmoji(server?.status)} ${status}`,
            `**Plan:** \`${plan}\``,
            "",
            "**Resources**",
            `> 🧠 RAM: \`${formatRam(server?.ram)}\``,
            `> ⚡ CPU: \`${formatCpu(server?.cpu)}\``,
            `> 💾 Disk: \`${formatDisk(server?.disk)}\``,
            `> 💾 Backups: \`${Number(server?.backups || 0)}\``,
            `> 🔌 Allocations: \`${Number(server?.allocations || 0)}\``,
            `> 🗄️ Databases: \`${Number(server?.databases || 0)}\``
        ].join(
            "\n"
        );

    const embed =
        infoEmbed(
            "🛠️ Server Control Panel",
            description
        );

    /*
     * ----------------------------------------------------------
     * ROW 1 - POWER
     * ----------------------------------------------------------
     */

    const powerRow =
        new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(
                        `server_start:${server.id}`
                    )
                    .setLabel(
                        "Start"
                    )
                    .setEmoji(
                        "▶️"
                    )
                    .setStyle(
                        ButtonStyle.Success
                    ),

                new ButtonBuilder()
                    .setCustomId(
                        `server_restart:${server.id}`
                    )
                    .setLabel(
                        "Restart"
                    )
                    .setEmoji(
                        "🔄"
                    )
                    .setStyle(
                        ButtonStyle.Primary
                    ),

                new ButtonBuilder()
                    .setCustomId(
                        `server_stop:${server.id}`
                    )
                    .setLabel(
                        "Stop"
                    )
                    .setEmoji(
                        "⏹️"
                    )
                    .setStyle(
                        ButtonStyle.Danger
                    )
            );

    /*
     * ----------------------------------------------------------
     * ROW 2 - INFORMATION / RENAME
     * ----------------------------------------------------------
     */

    const infoRow =
        new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(
                        `server_info:${server.id}`
                    )
                    .setLabel(
                        "Server Info"
                    )
                    .setEmoji(
                        "📋"
                    )
                    .setStyle(
                        ButtonStyle.Secondary
                    ),

                new ButtonBuilder()
                    .setCustomId(
                        `server_rename:${server.id}`
                    )
                    .setLabel(
                        "Rename"
                    )
                    .setEmoji(
                        "✏️"
                    )
                    .setStyle(
                        ButtonStyle.Secondary
                    ),

                new ButtonBuilder()
                    .setCustomId(
                        `server_delete:${server.id}`
                    )
                    .setLabel(
                        "Delete"
                    )
                    .setEmoji(
                        "🗑️"
                    )
                    .setStyle(
                        ButtonStyle.Danger
                    ),

                new ButtonBuilder()
                    .setCustomId(
                        `server_back:${server.id}`
                    )
                    .setLabel(
                        "Back"
                    )
                    .setEmoji(
                        "↩️"
                    )
                    .setStyle(
                        ButtonStyle.Secondary
                    )
            );

    const components = [
        powerRow,
        infoRow
    ];

    if (
        update
    ) {
        return target.update({
            embeds: [
                embed
            ],
            components
        });
    }

    return target.reply({
        embeds: [
            embed
        ],
        components,
        ephemeral: true
    });
}

/*
 * ============================================================
 * STATUS FORMATTER
 * ============================================================
 */

function formatStatusText(
    status
) {
    const value =
        String(
            status ||
            "unknown"
        )
        .trim()
        .toLowerCase();

    const labels = {
        online:
            "Online",

        running:
            "Running",

        active:
            "Active",

        starting:
            "Starting",

        stopping:
            "Stopping",

        offline:
            "Offline",

        stopped:
            "Stopped",

        suspended:
            "Suspended",

        installing:
            "Installing",

        restoring:
            "Restoring",

        unknown:
            "Unknown"
    };

    return (
        labels[value] ||
        capitalize(
            value
        )
    );
}

/*
 * ============================================================
 * STATUS EMOJI
 * ============================================================
 */

function getStatusEmoji(
    status
) {
    const value =
        String(
            status ||
            "unknown"
        )
        .trim()
        .toLowerCase();

    const icons = {
        online:
            "🟢",

        running:
            "🟢",

        active:
            "🟢",

        starting:
            "🟡",

        stopping:
            "🟠",

        offline:
            "🔴",

        stopped:
            "🔴",

        suspended:
            "⛔",

        installing:
            "🔵",

        restoring:
            "🔵",

        unknown:
            "⚪"
    };

    return (
        icons[value] ||
        "⚪"
    );
}

/*
 * ============================================================
 * RESOURCE FORMATTERS
 * ============================================================
 */

function formatRam(
    value
) {
    const mb =
        Number(
            value || 0
        );

    if (
        mb <= 0
    ) {
        return "0 MB";
    }

    if (
        mb % 1024 === 0
    ) {
        return `${mb / 1024} GB`;
    }

    if (
        mb > 1024
    ) {
        return `${(mb / 1024).toFixed(1)} GB`;
    }

    return `${mb} MB`;
}

function formatDisk(
    value
) {
    return formatRam(
        value
    );
}

function formatCpu(
    value
) {
    return `${Number(value || 0).toLocaleString()}%`;
}

/*
 * ============================================================
 * TEXT HELPERS
 * ============================================================
 */

function truncate(
    value,
    max
) {
    const text =
        String(
            value ??
            ""
        );

    if (
        text.length <= max
    ) {
        return text;
    }

    return (
        text.slice(
            0,
            Math.max(
                0,
                max - 3
            )
        ) +
        "..."
    );
}

function capitalize(
    value
) {
    const text =
        String(
            value ||
            ""
        );

    if (!text) {
        return "Unknown";
    }

    return (
        text.charAt(0).toUpperCase() +
        text.slice(1)
    );
}

/*
 * ============================================================
 * ERROR REPLY
 * ============================================================
 */

async function replyError(
    target,
    error
) {
    let title =
        "Management Error";

    let message =
        error?.message ||
        "An unexpected error occurred while managing the server.";

    if (
        error instanceof ServerManagerError
    ) {
        if (
            error.code ===
            "SERVER_NOT_FOUND"
        ) {
            title =
                "Server Not Found";
        }

        if (
            error.code ===
            "SERVER_NOT_OWNED"
        ) {
            title =
                "Access Denied";
        }

        if (
            error.code ===
            "INVALID_IDENTIFIER"
        ) {
            title =
                "Invalid Server";
        }

        if (
            error.code ===
            "INVALID_PTERODACTYL_ID"
        ) {
            title =
                "Invalid Pterodactyl Server";
        }
    }

    const payload = {
        embeds: [
            errorEmbed(
                title,
                message
            )
        ],
        ephemeral:
            target?.isChatInputCommand?.()
                ? true
                : undefined
    };

    try {
        if (
            target.deferred ||
            target.replied
        ) {
            return target.editReply({
                ...payload,
                ephemeral: undefined
            });
        }

        return target.reply(
            payload
        );
    } catch {
        return null;
    }
}

/*
 * ============================================================
 * EXPORT
 * ============================================================
 */

export default {
    data,
    name,
    aliases,
    execute,
    prefixExecute,
    handleManageSelection
};

/*
 * ============================================================
 * End of manage.js
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * PetroBot V2 Manage Command.
 * ============================================================
 */