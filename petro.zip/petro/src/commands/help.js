/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */

import {
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle
} from "discord.js";
import config from "../config.js";
import { isBotAdmin } from "../utils/permissions.js";
import { createEmbed } from "../utils/embeds.js";

export const name = "help";
export const description = "Open the Petro help center.";

const PREFIX = config.PREFIX || "!";

const USER_CATEGORIES = {
    "Getting Started": [
        ["help", "Open the help center"],
        ["plans", "View available hosting plans"],
        ["balance", "Check your coin balance"],
        ["resources", "View your available resources"],
        ["profile", "View your hosting profile"]
    ],
    "Hosting": [
        ["buy <plan>", "Purchase a hosting plan"],
        ["deploy <RAM> <CPU> <DISK>", "Deploy a new server"],
        ["myserver", "View your server"],
        ["servers", "View your servers"],
        ["manage", "Manage your server"],
        ["serverinfo", "View server information"],
        ["status", "View server status"]
    ],
    "Server Controls": [
        ["start", "Start a server"],
        ["stop", "Stop a server"],
        ["restart", "Restart a server"],
        ["power", "Control server power"],
        ["kill", "Force stop a server"],
        ["rename", "Rename a server"],
        ["reinstall", "Reinstall a server"]
    ],
    "Economy": [
        ["coins", "View the economy"],
        ["balance", "Check your balance"],
        ["pay <user> <amount>", "Send coins to another user"],
        ["redeem <code>", "Redeem a code"]
    ],
    "Account": [
        ["user", "Manage your hosting account"],
        ["transfer", "Transfer your server"],
        ["deleteserver", "Delete your server"]
    ]
};

const ADMIN_CATEGORIES = {
    "Administration": [
        ["addcoins <user> <amount>", "Add coins to a user"],
        ["givecoins <user> <amount>", "Give coins to a user"],
        ["createcode coins <amount>", "Create a coin redeem code"],
        ["createcode resource <RAM> <CPU> <DISK>", "Create a resource code"],
        ["useradmin", "Administrative user management"],
        ["utility", "Administrative utilities"]
    ],
    "Server Administration": [
        ["servers", "View server records"],
        ["serverinfo", "Inspect server information"],
        ["manage", "Manage a server"],
        ["suspend", "Suspend a server"],
        ["unsuspend", "Unsuspend a server"],
        ["reinstall", "Reinstall a server"],
        ["kill", "Force stop a server"],
        ["deleteserver", "Delete a server"]
    ],
    "Economy Administration": [
        ["addcoins", "Add coins"],
        ["givecoins", "Give coins"],
        ["createcode", "Create redeem codes"],
        ["redeem", "Redeem/test codes"],
        ["pay", "Transfer coins"]
    ],
    "Staff Utilities": [
        ["user", "User management"],
        ["profile", "View profiles"],
        ["transfer", "Server transfer tools"],
        ["slashAdmin", "Administrative slash tools"]
    ]
};

function isStaff(message) {
    if (isBotAdmin(message.author.id)) {
        return true;
    }

    if (!message.guild || !message.member) {
        return false;
    }

    return (
        message.member.permissions.has("Administrator") ||
        message.member.permissions.has("ManageGuild")
    );
}

function userButtons() {
    return [
        new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId("help_user_getting_started")
                .setLabel("Getting Started")
                .setEmoji("🚀")
                .setStyle(ButtonStyle.Primary),

            new ButtonBuilder()
                .setCustomId("help_user_hosting")
                .setLabel("Hosting")
                .setEmoji("🖥️")
                .setStyle(ButtonStyle.Secondary),

            new ButtonBuilder()
                .setCustomId("help_user_controls")
                .setLabel("Controls")
                .setEmoji("🎛️")
                .setStyle(ButtonStyle.Secondary)
        ),

        new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId("help_user_economy")
                .setLabel("Economy")
                .setEmoji("🪙")
                .setStyle(ButtonStyle.Secondary),

            new ButtonBuilder()
                .setCustomId("help_user_account")
                .setLabel("Account")
                .setEmoji("👤")
                .setStyle(ButtonStyle.Secondary),

            new ButtonBuilder()
                .setCustomId("help_home")
                .setLabel("Overview")
                .setEmoji("⌂")
                .setStyle(ButtonStyle.Success)
        )
    ];
}

function adminButtons() {
    return [
        new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId("help_admin_administration")
                .setLabel("Administration")
                .setEmoji("🛡️")
                .setStyle(ButtonStyle.Primary),

            new ButtonBuilder()
                .setCustomId("help_admin_servers")
                .setLabel("Servers")
                .setEmoji("🖥️")
                .setStyle(ButtonStyle.Secondary),

            new ButtonBuilder()
                .setCustomId("help_admin_economy")
                .setLabel("Economy")
                .setEmoji("🪙")
                .setStyle(ButtonStyle.Secondary)
        ),

        new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId("help_admin_utilities")
                .setLabel("Staff Utilities")
                .setEmoji("🔧")
                .setStyle(ButtonStyle.Secondary),

            new ButtonBuilder()
                .setCustomId("help_home")
                .setLabel("Overview")
                .setEmoji("🏠")
                .setStyle(ButtonStyle.Success)
        )
    ];
}

function makeUserHome() {
    const embed = createEmbed({
        title: "⚡ Petro • Control Center",
        description:
            `Welcome to **Petro**.\n\n` +
            `Your complete hosting control center for managing servers, resources and coins directly from Discord.\n\n` +
            `**Prefix:** \`${PREFIX}\`\n` +
            `Select a category below to explore the available commands.`,
        color: 0x8B5CF6
    });

    embed.addFields(
        {
            name: "🖥️ Hosting",
            value:
                "Deploy, view and manage your hosting servers.\n" +
                `\`${PREFIX}plans\` • \`${PREFIX}deploy\` • \`${PREFIX}manage\``,
            inline: true
        },
        {
            name: "🪙 Economy",
            value:
                "Purchase resources, check coins and redeem codes.\n" +
                `\`${PREFIX}balance\` • \`${PREFIX}buy\` • \`${PREFIX}redeem\``,
            inline: true
        },
        {
            name: "🎛️ Server Control",
            value:
                "Control your server power and configuration.\n" +
                `\`${PREFIX}start\` • \`${PREFIX}stop\` • \`${PREFIX}restart\``,
            inline: true
        }
    );

    embed.setFooter({
        text: "Petro • Powered by HyperForgeX"
    });

    return embed;
}

function makeAdminHome() {
    const embed = createEmbed({
        title: "🛡️ Petro • Staff Control Center",
        description:
            `Welcome to the **Staff Control Center**.\n\n` +
            `You have elevated permissions, so additional administration commands are available.\n\n` +
            `**Prefix:** \`${PREFIX}\`\n` +
            `Select a category below to access staff tools.`,
        color: 0xED4245
    });

    embed.addFields(
        {
            name: "🛡️ Administration",
            value:
                "Manage users, permissions and redeem codes.",
            inline: true
        },
        {
            name: "🖥️ Server Operations",
            value:
                "Inspect and control hosted servers.",
            inline: true
        },
        {
            name: "🪙 Economy",
            value:
                "Manage coins and economy operations.",
            inline: true
        },
        {
            name: "🔧 Staff Utilities",
            value:
                "Additional tools available to authorized staff.",
            inline: true
        }
    );

    embed.setFooter({
        text: "Petro • Staff Access • HyperForgeX"
    });

    return embed;
}

function makeCategory(title, commands, admin = false) {
    const embed = createEmbed({
        title: `${admin ? "🛡️" : "⚡"} Petro • ${title}`,
        description:
            `${admin ? "Staff" : "User"} command reference.\n\n` +
            `**Prefix:** \`${PREFIX}\``,
        color: admin ? 0xED4245 : 0x8B5CF6
    });

    embed.addFields({
        name: "Available Commands",
        value: commands
            .map(([command, description]) =>
                `\`${PREFIX}${command}\` — ${description}`
            )
            .join("\n"),
        inline: false
    });

    embed.setFooter({
        text: `Petro • ${admin ? "Staff Center" : "Help Center"} • HyperForgeX`
    });

    return embed;
}

export async function execute(message) {
    const admin = isStaff(message);

    await message.reply({
        embeds: [
            admin
                ? makeAdminHome()
                : makeUserHome()
        ],
        components: admin
            ? adminButtons()
            : userButtons()
    });
}

export function getUserCategory(customId) {
    const categories = {
        help_user_getting_started: [
            "Getting Started",
            USER_CATEGORIES["Getting Started"]
        ],
        help_user_hosting: [
            "Hosting",
            USER_CATEGORIES.Hosting
        ],
        help_user_controls: [
            "Server Controls",
            USER_CATEGORIES["Server Controls"]
        ],
        help_user_economy: [
            "Economy",
            USER_CATEGORIES.Economy
        ],
        help_user_account: [
            "Account",
            USER_CATEGORIES.Account
        ]
    };

    return categories[customId] || null;
}

export function getAdminCategory(customId) {
    const categories = {
        help_admin_administration: [
            "Administration",
            ADMIN_CATEGORIES.Administration
        ],
        help_admin_servers: [
            "Server Administration",
            ADMIN_CATEGORIES["Server Administration"]
        ],
        help_admin_economy: [
            "Economy Administration",
            ADMIN_CATEGORIES["Economy Administration"]
        ],
        help_admin_utilities: [
            "Staff Utilities",
            ADMIN_CATEGORIES["Staff Utilities"]
        ]
    };

    return categories[customId] || null;
}

export async function handleHelpButton(interaction) {
    const id = interaction.customId;

    const admin =
        isBotAdmin(interaction.user.id) ||
        (
            interaction.inGuild() &&
            interaction.memberPermissions?.has("Administrator")
        ) ||
        (
            interaction.inGuild() &&
            interaction.memberPermissions?.has("ManageGuild")
        );

    if (id === "help_home") {
        return interaction.update({
            embeds: [
                admin
                    ? makeAdminHome()
                    : makeUserHome()
            ],
            components: admin
                ? adminButtons()
                : userButtons()
        });
    }

    if (id === "help_user") {
        return interaction.update({
            embeds: [makeUserHome()],
            components: userButtons()
        });
    }

    if (id.startsWith("help_user_")) {
        const category = getUserCategory(id);

        if (!category) return;

        return interaction.update({
            embeds: [
                makeCategory(
                    category[0],
                    category[1],
                    false
                )
            ],
            components: userButtons()
        });
    }

    if (id.startsWith("help_admin_")) {
        if (!admin) {
            return interaction.reply({
                content:
                    "🔒 You do not have permission to access the staff help menu.",
                ephemeral: true
            });
        }

        const category = getAdminCategory(id);

        if (!category) return;

        return interaction.update({
            embeds: [
                makeCategory(
                    category[0],
                    category[1],
                    true
                )
            ],
            components: adminButtons()
        });
    }
}

export { isStaff };

export default {
    name,
    description,
    execute,
    handleHelpButton,
    getUserCategory,
    getAdminCategory,
    isStaff
};

/*
 * ============================================================
 * End of help.js
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */