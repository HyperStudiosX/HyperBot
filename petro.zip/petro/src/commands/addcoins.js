/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */

import {
    SlashCommandBuilder
} from "discord.js";
import {
    addCoins,
    ensureUser
} from "../services/economy.js";
import {
    requireBotAdmin
} from "../utils/permissions.js";
import {
    successEmbed,
    errorEmbed
} from "../utils/embeds.js";

export const data = new SlashCommandBuilder()
    .setName("addcoins")
    .setDescription("Add coins to a user's balance.")
    .addUserOption(option =>
        option
            .setName("user")
            .setDescription("The user receiving the coins.")
            .setRequired(true)
    )
    .addIntegerOption(option =>
        option
            .setName("amount")
            .setDescription("Number of coins to add.")
            .setRequired(true)
            .setMinValue(1)
    )
    .setDMPermission(true);

export async function execute(interaction) {
    try {
        requireBotAdmin(interaction.user.id);

        const target = interaction.options.getUser("user", true);
        const amount = interaction.options.getInteger("amount", true);

        if (target.bot) {
            return interaction.reply({
                embeds: [
                    errorEmbed(
                        "Invalid User",
                        "Bots cannot receive coins."
                    )
                ],
                ephemeral: true
            });
        }

        if (!Number.isInteger(amount) || amount <= 0) {
            return interaction.reply({
                embeds: [
                    errorEmbed(
                        "Invalid Amount",
                        "The amount must be a positive whole number."
                    )
                ],
                ephemeral: true
            });
        }

        // Make sure the target has an economy account
        ensureUser(
            target.id,
            target.username
        );

        const result = addCoins(
            target.id,
            amount,
            `Added by ${interaction.user.username}`
        );

        return interaction.reply({
            embeds: [
                successEmbed(
                    "Coins Added",
                    `Added **${amount.toLocaleString()} coins** to **${target.username}**.\n\n💰 **New Balance:** ${Number(result.balance).toLocaleString()} coins`
                )
            ],
            ephemeral: true
        });
    } catch (error) {
        return interaction.reply({
            embeds: [
                errorEmbed(
                    "Operation Failed",
                    error?.message || "Unable to add coins."
                )
            ],
            ephemeral: true
        });
    }
}

export default {
    data,
    execute
};

/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */