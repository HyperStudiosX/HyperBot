/*
 * ============================================================
 * PetroBot V2 - Buy Command
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */

import { getPlan } from "../plans.js";
import economy from "../services/economy.js";
import resourceManager from "../services/resourceManager.js";
import { createEmbed, errorEmbed } from "../utils/embeds.js";

export const name = "buy";
export const description = "Purchase a hosting plan with coins.";

export const aliases = [
    "purchase",
    "buyplan",
    "purchaseplan"
];

export const data = {
    name: "buy",
    description: "Purchase a hosting plan with coins.",
    options: [
        {
            name: "plan",
            description: "The ID of the hosting plan to purchase.",
            type: 3,
            required: true
        }
    ]
};

function toNumber(value, fallback = 0) {
    const number = Number(value);
    return Number.isFinite(number) ? number : fallback;
}

function mbToGb(value) {
    return toNumber(value) / 1024;
}

function formatNumber(value) {
    return toNumber(value).toLocaleString("en-US");
}

function getPlanId(plan) {
    return String(
        plan?.id ??
        plan?.planId ??
        plan?.plan_id ??
        ""
    ).trim();
}

function getPlanName(plan) {
    return String(
        plan?.name ??
        plan?.displayName ??
        plan?.display_name ??
        "Hosting Plan"
    );
}

function getPlanPrice(plan) {
    return toNumber(
        plan?.price ??
        plan?.cost ??
        plan?.coins ??
        plan?.coinCost ??
        plan?.coin_cost
    );
}

function getPlanResources(plan) {
    return {
        ram: toNumber(
            plan?.ram ??
            plan?.ramMb ??
            plan?.ram_mb ??
            plan?.memory ??
            plan?.memoryMb ??
            plan?.memory_mb
        ),
        cpu: toNumber(
            plan?.cpu ??
            plan?.cpuPercent ??
            plan?.cpu_percent
        ),
        disk: toNumber(
            plan?.disk ??
            plan?.diskMb ??
            plan?.disk_mb ??
            plan?.storage ??
            plan?.storageMb ??
            plan?.storage_mb
        ),
        backups: toNumber(
            plan?.backups ??
            plan?.backup
        ),
        allocations: toNumber(
            plan?.allocations ??
            plan?.allocation
        ),
        databases: toNumber(
            plan?.databases ??
            plan?.database
        ),
        server_slots: toNumber(
            plan?.serverSlots ??
            plan?.server_slots ??
            plan?.slots
        )
    };
}

function buildResourceText(resources) {
    return (
        `🧠 RAM: **+${mbToGb(resources.ram)} GB**\n` +
        `⚙️ CPU: **+${formatNumber(resources.cpu)}%**\n` +
        `💾 Disk: **+${mbToGb(resources.disk)} GB**\n` +
        `🌐 Allocations: **+${formatNumber(resources.allocations)}**\n` +
        `🗄️ Databases: **+${formatNumber(resources.databases)}**\n` +
        `💿 Backups: **+${formatNumber(resources.backups)}**\n` +
        `🖥️ Server Slots: **+${formatNumber(resources.server_slots)}**`
    );
}

function buildCurrentResourcesText(resources) {
    const data = resources || {};

    return (
        `🧠 RAM: **${mbToGb(data.ram)} GB**\n` +
        `⚙️ CPU: **${formatNumber(data.cpu)}%**\n` +
        `💾 Disk: **${mbToGb(data.disk)} GB**\n` +
        `🌐 Allocations: **${formatNumber(data.allocations)}**\n` +
        `🗄️ Databases: **${formatNumber(data.databases)}**\n` +
        `💿 Backups: **${formatNumber(data.backups)}**\n` +
        `🖥️ Server Slots: **${formatNumber(data.server_slots)}**`
    );
}

function getRequestedPlanId(value) {
    return String(value ?? "").trim();
}

async function performPurchase(userId, username, requestedPlanId) {
    const planId = getRequestedPlanId(requestedPlanId);

    if (!planId) {
        return {
            success: false,
            type: "missing_plan"
        };
    }

    const plan = getPlan(planId);

    if (!plan) {
        return {
            success: false,
            type: "invalid_plan",
            planId
        };
    }

    const planPrice = getPlanPrice(plan);
    const planResources = getPlanResources(plan);

    resourceManager.ensureResourceAccount(userId);

    const balanceBefore = economy.getBalance(userId);

    if (balanceBefore < planPrice) {
        return {
            success: false,
            type: "insufficient_coins",
            plan,
            price: planPrice,
            balance: balanceBefore,
            missing: planPrice - balanceBefore
        };
    }

    let purchase;

    try {
        purchase = economy.spendCoins(
            userId,
            planPrice,
            `Purchased ${getPlanName(plan)}`
        );
    } catch (error) {
        return {
            success: false,
            type: "spend_failed",
            plan,
            error
        };
    }

    if (!purchase) {
        return {
            success: false,
            type: "spend_failed",
            plan
        };
    }

    try {
        resourceManager.addResources(
            userId,
            planResources
        );
    } catch (error) {
        console.error(
            `[Buy] Failed to add plan resources for ${userId}:`,
            error
        );

        try {
            economy.addCoins(
                userId,
                planPrice,
                `Refund for failed ${getPlanName(plan)} purchase`
            );
        } catch (refundError) {
            console.error(
                `[Buy] CRITICAL: Refund failed for ${userId}:`,
                refundError
            );
        }

        return {
            success: false,
            type: "resource_failed",
            plan,
            error
        };
    }

    let currentResources;

    try {
        currentResources =
            resourceManager.getResources(userId);
    } catch (error) {
        console.error(
            `[Buy] Failed to read resources for ${userId}:`,
            error
        );

        currentResources = planResources;
    }

    let balanceAfter;

    try {
        balanceAfter = economy.getBalance(userId);
    } catch {
        balanceAfter = Math.max(
            0,
            balanceBefore - planPrice
        );
    }

    return {
        success: true,
        userId,
        username,
        plan,
        planId: getPlanId(plan),
        price: planPrice,
        resourcesAdded: planResources,
        currentResources,
        balanceBefore,
        balanceAfter
    };
}

function buildSuccessEmbed(result) {
    const plan = result.plan;

    const embed = createEmbed({
        title: "✅ Plan Purchased Successfully",
        description:
            `You have successfully purchased **${getPlanName(plan)}**.\n\n` +
            "The plan resources have been added to your Petro resource balance.",
        color: 0x57F287
    });

    embed.addFields(
        {
            name: "🛒 Purchase",
            value:
                `**${getPlanName(plan)}**\n` +
                `🆔 Plan ID: \`${getPlanId(plan)}\`\n` +
                `💰 Cost: **${formatNumber(result.price)} coins**`,
            inline: true
        },
        {
            name: "💰 Coin Balance",
            value:
                `Before: **${formatNumber(result.balanceBefore)} coins**\n` +
                `After: **${formatNumber(result.balanceAfter)} coins**`,
            inline: true
        },
        {
            name: "📦 Resources Added",
            value: buildResourceText(result.resourcesAdded),
            inline: false
        },
        {
            name: "📊 Current Resource Balance",
            value: buildCurrentResourcesText(
                result.currentResources
            ),
            inline: false
        },
        {
            name: "🚀 Next Step",
            value:
                "You can now use your available resources to deploy a server.\n" +
                "Use `!resources` to view your resources.",
            inline: false
        }
    );

    embed.setFooter({
        text: "HyperForgeX • Petro V2"
    });

    return embed;
}

function buildInsufficientCoinsEmbed(result) {
    const embed = createEmbed({
        title: "❌ Insufficient Coins",
        description:
            `You don't have enough coins to purchase **${getPlanName(result.plan)}**.`,
        color: 0xED4245
    });

    embed.addFields(
        {
            name: "💰 Your Balance",
            value: `**${formatNumber(result.balance)} coins**`,
            inline: true
        },
        {
            name: "🛒 Plan Price",
            value: `**${formatNumber(result.price)} coins**`,
            inline: true
        },
        {
            name: "📉 Missing",
            value: `**${formatNumber(result.missing)} coins**`,
            inline: true
        },
        {
            name: "💡 What You Can Do",
            value:
                "• Receive coins from another user\n" +
                "• Redeem a coin code with `!redeem <code>`\n" +
                "• Check your balance with `!balance`",
            inline: false
        }
    );

    embed.setFooter({
        text: "HyperForgeX • Petro V2"
    });

    return embed;
}

function buildMissingPlanMessage() {
    return (
        "❌ **Missing Plan ID**\n\n" +
        "Please specify the plan you want to purchase.\n\n" +
        "Use `!plans` to view all available plans.\n" +
        "Example: `!buy plan1`"
    );
}

function buildInvalidPlanMessage(planId) {
    return (
        "❌ **Invalid Plan**\n\n" +
        `The plan \`${planId}\` does not exist.\n\n` +
        "Use `!plans` to view the available plans."
    );
}

function buildPurchaseFailureMessage(result) {
    if (result.type === "resource_failed") {
        return (
            "❌ **Purchase Failed**\n\n" +
            "The plan resources could not be added to your account.\n" +
            "Your coins have been refunded."
        );
    }

    return (
        "❌ **Purchase Failed**\n\n" +
        "The purchase could not be completed.\n" +
        "Please try again."
    );
}

export async function execute(message, args = []) {
    const userId = String(
        message?.author?.id ?? ""
    ).trim();

    const username =
        message?.author?.username ??
        message?.author?.tag ??
        null;

    if (!userId) {
        return message.reply({
            embeds: [
                errorEmbed(
                    "Purchase Error",
                    "I could not determine your Discord account."
                )
            ]
        });
    }

    const planId = args?.[0];

    if (!planId) {
        return message.reply({
            content: buildMissingPlanMessage()
        });
    }

    try {
        const result = await performPurchase(
            userId,
            username,
            planId
        );

        if (!result.success) {
            if (result.type === "missing_plan") {
                return message.reply({
                    content: buildMissingPlanMessage()
                });
            }

            if (result.type === "invalid_plan") {
                return message.reply({
                    content: buildInvalidPlanMessage(
                        result.planId
                    )
                });
            }

            if (result.type === "insufficient_coins") {
                return message.reply({
                    embeds: [
                        buildInsufficientCoinsEmbed(result)
                    ]
                });
            }

            return message.reply({
                content: buildPurchaseFailureMessage(result)
            });
        }

        return message.reply({
            embeds: [
                buildSuccessEmbed(result)
            ]
        });
    } catch (error) {
        console.error(
            `[Buy] Unexpected purchase error for ${userId}:`,
            error
        );

        return message.reply({
            embeds: [
                errorEmbed(
                    "Purchase Error",
                    "An unexpected error occurred while purchasing the plan. Your account was not intentionally charged by this error handler."
                )
            ]
        });
    }
}

export async function prefixExecute(message, args = []) {
    return execute(message, args);
}

export async function executeSlash(interaction) {
    const userId = String(
        interaction?.user?.id ?? ""
    ).trim();

    const username =
        interaction?.user?.username ??
        interaction?.user?.tag ??
        null;

    const planId =
        interaction?.options?.getString?.("plan") ??
        null;

    if (!userId) {
        return interaction.reply({
            embeds: [
                errorEmbed(
                    "Purchase Error",
                    "I could not determine your Discord account."
                )
            ],
            ephemeral: true
        });
    }

    if (!planId) {
        return interaction.reply({
            content:
                "❌ Please provide a plan ID. Use `/plans` to view available plans.",
            ephemeral: true
        });
    }

    try {
        const result = await performPurchase(
            userId,
            username,
            planId
        );

        if (!result.success) {
            if (result.type === "invalid_plan") {
                return interaction.reply({
                    content: buildInvalidPlanMessage(
                        result.planId
                    ),
                    ephemeral: true
                });
            }

            if (result.type === "insufficient_coins") {
                return interaction.reply({
                    embeds: [
                        buildInsufficientCoinsEmbed(result)
                    ],
                    ephemeral: true
                });
            }

            return interaction.reply({
                content: buildPurchaseFailureMessage(result),
                ephemeral: true
            });
        }

        return interaction.reply({
            embeds: [
                buildSuccessEmbed(result)
            ]
        });
    } catch (error) {
        console.error(
            `[Buy] Unexpected slash purchase error for ${userId}:`,
            error
        );

        const payload = {
            embeds: [
                errorEmbed(
                    "Purchase Error",
                    "An unexpected error occurred while purchasing the plan."
                )
            ],
            ephemeral: true
        };

        if (
            interaction.replied ||
            interaction.deferred
        ) {
            return interaction.followUp(payload);
        }

        return interaction.reply(payload);
    }
}

const buyCommand = {
    name,
    description,
    aliases,
    data,
    execute,
    prefixExecute,
    executeSlash
};

export default buyCommand;

/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */