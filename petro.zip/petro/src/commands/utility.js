/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */

import { SlashCommandBuilder } from "discord.js";
import { createEmbed, errorEmbed } from "../utils/embeds.js";

export const data = new SlashCommandBuilder()
    .setName("utility")
    .setDescription("View utility information and bot diagnostics.")
    .addSubcommand(subcommand =>
        subcommand
            .setName("ping")
            .setDescription("Check the bot latency.")
    )
    .addSubcommand(subcommand =>
        subcommand
            .setName("uptime")
            .setDescription("Check how long the bot has been online.")
    )
    .addSubcommand(subcommand =>
        subcommand
            .setName("info")
            .setDescription("View bot information.")
    )
    .setDMPermission(true);

export async function execute(interaction) {
    try {
        const subcommand = interaction.options.getSubcommand();

        if (subcommand === "ping") {
            const sent = await interaction.reply({
                embeds: [
                    createEmbed({
                        title: "🏓 Pong!",
                        description: "Calculating latency...",
                        color: 0x5865F2
                    })
                ],
                ephemeral: true,
                fetchReply: true
            });

            const latency = sent.createdTimestamp - interaction.createdTimestamp;
            const websocket = interaction.client.ws.ping;

            return interaction.editReply({
                embeds: [
                    createEmbed({
                        title: "🏓 Bot Latency",
                        description:
                            `**Response:** \`${latency}ms\`\n` +
                            `**WebSocket:** \`${websocket}ms\``,
                        color: 0x57F287
                    })
                ]
            });
        }

        if (subcommand === "uptime") {
            const uptime = interaction.client.uptime || 0;

            const seconds = Math.floor(uptime / 1000) % 60;
            const minutes = Math.floor(uptime / 60000) % 60;
            const hours = Math.floor(uptime / 3600000) % 24;
            const days = Math.floor(uptime / 86400000);

            const parts = [];

            if (days) parts.push(`${days}d`);
            if (hours) parts.push(`${hours}h`);
            if (minutes) parts.push(`${minutes}m`);
            parts.push(`${seconds}s`);

            return interaction.reply({
                embeds: [
                    createEmbed({
                        title: "⏱️ Bot Uptime",
                        description: `The bot has been online for **${parts.join(" ")}**.`,
                        color: 0x5865F2
                    })
                ],
                ephemeral: true
            });
        }

        if (subcommand === "info") {
            const client = interaction.client;

            return interaction.reply({
                embeds: [
                    createEmbed({
                        title: "⚙️ Bot Information",
                        description:
                            `**Bot:** ${client.user}\n` +
                            `**Bot ID:** \`${client.user.id}\`\n` +
                            `**Node.js:** \`${process.version}\`\n` +
                            `**Discord.js:** \`${process.env.npm_package_dependencies_discord_js || "Installed"}\`\n` +
                            `**Guilds:** \`${client.guilds.cache.size}\`\n` +
                            `**Users Cached:** \`${client.users.cache.size}\``,
                        color: 0x5865F2
                    })
                ],
                ephemeral: true
            });
        }

        return interaction.reply({
            embeds: [
                errorEmbed(
                    "Invalid Utility Command",
                    "Unknown utility subcommand."
                )
            ],
            ephemeral: true
        });
    } catch (error) {
        console.error("[Utility]", error);

        if (interaction.deferred || interaction.replied) {
            return interaction.editReply({
                embeds: [
                    errorEmbed(
                        "Utility Error",
                        error?.message || "An unexpected error occurred."
                    )
                ]
            });
        }

        return interaction.reply({
            embeds: [
                errorEmbed(
                    "Utility Error",
                    error?.message || "An unexpected error occurred."
                )
            ],
            ephemeral: true
        });
    }
}

export default {
    data,
    execute
};

/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */