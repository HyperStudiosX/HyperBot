/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */

import {
    SlashCommandBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle
} from "discord.js";

import {
    ensureUser,
    getUser
} from "../services/userService.js";

import database from "../database.js";

import * as pterodactyl from "../services/pterodactyl.js";

import {
    successEmbed,
    errorEmbed,
    infoEmbed
} from "../utils/embeds.js";

/*
 * ============================================================
 * HELPERS
 * ============================================================
 */

function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function getAdminIds() {
    return String(process.env.BOT_ADMIN_IDS || "")
        .split(",")
        .map(id => id.trim())
        .filter(Boolean);
}

function isBotAdmin(userId) {
    return getAdminIds().includes(String(userId));
}

function generateUsername(email) {
    const localPart =
        String(email)
            .split("@")[0]
            .replace(/[^a-zA-Z0-9_-]/g, "")
            .slice(0, 24);

    return localPart || `user${Date.now()}`;
}

function getPterodactylUserId(user) {
    return (
        user?.pterodactyl_id ||
        user?.pterodactylId ||
        user?.pterodactyl_user_id ||
        null
    );
}

/*
 * ============================================================
 * SLASH COMMAND
 * ============================================================
 */

export const data = new SlashCommandBuilder()
    .setName("user")
    .setDescription("Manage your account.")
    .addSubcommand(subcommand =>
        subcommand
            .setName("register")
            .setDescription("Register your Discord account.")
    )
    .addSubcommand(subcommand =>
        subcommand
            .setName("info")
            .setDescription("View your account information.")
    )
    .setDMPermission(true);

/*
 * ============================================================
 * SLASH EXECUTE
 * ============================================================
 */

export async function execute(interaction) {
    try {
        const subcommand =
            interaction.options.getSubcommand();

        if (subcommand === "register") {
            const existingUser =
                getUser(interaction.user.id);

            if (existingUser) {
                return interaction.reply({
                    embeds: [
                        errorEmbed(
                            "Already Registered",
                            "Your Discord account is already registered."
                        )
                    ],
                    ephemeral: true
                });
            }

            const user =
                ensureUser(
                    interaction.user.id,
                    interaction.user.username
                );

            return interaction.reply({
                embeds: [
                    successEmbed(
                        "Account Registered",
                        `Your account has been registered successfully.\n\n` +
                        `**Username:** \`${interaction.user.username}\`\n` +
                        `**Discord ID:** \`${interaction.user.id}\`\n` +
                        `**Coins:** \`${user?.coins ?? 0}\``
                    )
                ],
                ephemeral: true
            });
        }

        if (subcommand === "info") {
            const user =
                getUser(interaction.user.id);

            if (!user) {
                return interaction.reply({
                    embeds: [
                        errorEmbed(
                            "Account Not Found",
                            "You are not registered yet. Use `/user register` first."
                        )
                    ],
                    ephemeral: true
                });
            }

            const createdTimestamp =
                user.created_at
                    ? Math.floor(
                        new Date(user.created_at).getTime() / 1000
                    )
                    : null;

            return interaction.reply({
                embeds: [
                    infoEmbed(
                        "Account Information",
                        `**Username:** \`${user.username || interaction.user.username}\`\n` +
                        `**Discord ID:** \`${user.discord_id || interaction.user.id}\`\n` +
                        `**Coins:** \`${Number(user.coins || 0).toLocaleString()}\`\n` +
                        `**Pterodactyl ID:** \`${getPterodactylUserId(user) || "Not linked"}\`` +
                        (
                            createdTimestamp
                                ? `\n**Created:** <t:${createdTimestamp}:F>`
                                : ""
                        )
                    )
                ],
                ephemeral: true
            });
        }

        return interaction.reply({
            embeds: [
                errorEmbed(
                    "Invalid Command",
                    "Unknown user subcommand."
                )
            ],
            ephemeral: true
        });
    } catch (error) {
        console.error("[User Slash]", error);

        if (interaction.deferred || interaction.replied) {
            return interaction.editReply({
                embeds: [
                    errorEmbed(
                        "User Command Error",
                        error?.message ||
                        "An unexpected error occurred."
                    )
                ]
            });
        }

        return interaction.reply({
            embeds: [
                errorEmbed(
                    "User Command Error",
                    error?.message ||
                    "An unexpected error occurred."
                )
            ],
            ephemeral: true
        });
    }
}

/*
 * ============================================================
 * PREFIX COMMAND
 *
 * !user create
 * !user info
 * !user create admin <email> <password>
 * !user make admin <email>
 * !user remove admin <email>
 * ============================================================
 */

export async function prefixExecute(message, args) {
    try {
        const subcommand =
            String(args?.[0] || "").toLowerCase();

        /*
         * --------------------------------------------------------
         * !user
         * --------------------------------------------------------
         */

        if (!subcommand) {
            return message.reply({
                embeds: [
                    infoEmbed(
                        "User Commands",
                        [
                            "`!user create` — Create your Pterodactyl account",
                            "`!user info` — View your account",
                            "",
                            "**Admin Commands**",
                            "`!user create admin <email> <password>`",
                            "`!user make admin <email>`",
                            "`!user remove admin <email>`"
                        ].join("\n")
                    )
                ]
            });
        }

        /*
         * --------------------------------------------------------
         * !user info
         * --------------------------------------------------------
         */

        if (subcommand === "info") {
            const user =
                getUser(message.author.id);

            if (!user) {
                return message.reply({
                    embeds: [
                        errorEmbed(
                            "Account Not Found",
                            "You are not registered yet."
                        )
                    ]
                });
            }

            return message.reply({
                embeds: [
                    infoEmbed(
                        "Account Information",
                        [
                            `**Discord:** ${message.author}`,
                            `**Discord ID:** \`${message.author.id}\``,
                            `**Username:** \`${user.username || message.author.username}\``,
                            `**Coins:** \`${Number(user.coins || 0).toLocaleString()}\``,
                            `**Pterodactyl ID:** \`${getPterodactylUserId(user) || "Not linked"}\``
                        ].join("\n")
                    )
                ]
            });
        }

        /*
         * --------------------------------------------------------
         * !user create admin
         * --------------------------------------------------------
         */

        if (
            subcommand === "create" &&
            String(args?.[1] || "").toLowerCase() === "admin"
        ) {
            if (!isBotAdmin(message.author.id)) {
                return message.reply({
                    embeds: [
                        errorEmbed(
                            "Permission Denied",
                            "You do not have permission to create Pterodactyl administrators."
                        )
                    ]
                });
            }

            const email =
                String(args?.[2] || "").trim();

            const password =
                String(args?.[3] || "");

            if (!email || !password) {
                return message.reply({
                    embeds: [
                        errorEmbed(
                            "Missing Arguments",
                            "Usage:\n`!user create admin <email> <password>`"
                        )
                    ]
                });
            }

            if (!isValidEmail(email)) {
                return message.reply({
                    embeds: [
                        errorEmbed(
                            "Invalid Email",
                            "Please provide a valid email address."
                        )
                    ]
                });
            }

            if (password.length < 8) {
                return message.reply({
                    embeds: [
                        errorEmbed(
                            "Weak Password",
                            "The password must contain at least 8 characters."
                        )
                    ]
                });
            }

            const existing =
                await pterodactyl.findUserByEmail(email);

            if (existing) {
                return message.reply({
                    embeds: [
                        errorEmbed(
                            "User Already Exists",
                            `A Pterodactyl user already exists with \`${email}\`.`
                        )
                    ]
                });
            }

            const username =
                generateUsername(email);

            const created =
                await pterodactyl.createUser({
                    email,
                    username,
                    firstName: "Pterodactyl",
                    lastName: "Admin",
                    password,
                    rootAdmin: true
                });

            const createdId =
                created?.id ||
                created?.attributes?.id;

            return message.reply({
                embeds: [
                    successEmbed(
                        "Pterodactyl Admin Created",
                        [
                            `**Email:** \`${email}\``,
                            `**Username:** \`${username}\``,
                            `**Pterodactyl ID:** \`${createdId || "Unknown"}\``,
                            `**Root Admin:** \`Yes\``
                        ].join("\n")
                    )
                ]
            });
        }

        /*
         * --------------------------------------------------------
         * !user create
         * --------------------------------------------------------
         */

        if (subcommand === "create") {
            const user =
                getUser(message.author.id);

            if (user && getPterodactylUserId(user)) {
                return message.reply({
                    embeds: [
                        errorEmbed(
                            "Account Already Linked",
                            "Your Discord account already has a Pterodactyl account linked."
                        )
                    ]
                });
            }

            const row =
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId(
                            `user_create_open:${message.author.id}`
                        )
                        .setLabel("Create Pterodactyl Account")
                        .setStyle(ButtonStyle.Primary),

                    new ButtonBuilder()
                        .setCustomId(
                            `user_create_cancel:${message.author.id}`
                        )
                        .setLabel("Cancel")
                        .setStyle(ButtonStyle.Secondary)
                );

            return message.reply({
                embeds: [
                    infoEmbed(
                        "Create Pterodactyl Account",
                        [
                            "Click the button below to create your Pterodactyl account.",
                            "",
                            "You will be asked for:",
                            "• Email address",
                            "• Pterodactyl password",
                            "",
                            "Your account will be created as a **normal user**, not an administrator."
                        ].join("\n")
                    )
                ],
                components: [row]
            });
        }

        /*
         * --------------------------------------------------------
         * !user make admin
         * --------------------------------------------------------
         */

        if (
            subcommand === "make" &&
            String(args?.[1] || "").toLowerCase() === "admin"
        ) {
            if (!isBotAdmin(message.author.id)) {
                return message.reply({
                    embeds: [
                        errorEmbed(
                            "Permission Denied",
                            "You do not have permission to promote Pterodactyl users."
                        )
                    ]
                });
            }

            const email =
                String(args?.[2] || "").trim();

            if (!email) {
                return message.reply({
                    embeds: [
                        errorEmbed(
                            "Missing Email",
                            "Usage:\n`!user make admin <email>`"
                        )
                    ]
                });
            }

            const existing =
                await pterodactyl.findUserByEmail(email);

            if (!existing) {
                return message.reply({
                    embeds: [
                        errorEmbed(
                            "User Not Found",
                            `No Pterodactyl user was found with \`${email}\`.`
                        )
                    ]
                });
            }

            const id =
                existing.id ||
                existing.attributes?.id;

            if (!id) {
                return message.reply({
                    embeds: [
                        errorEmbed(
                            "Pterodactyl Error",
                            "Could not determine the Pterodactyl user ID."
                        )
                    ]
                });
            }

            if (existing.root_admin || existing.attributes?.root_admin) {
                return message.reply({
                    embeds: [
                        infoEmbed(
                            "Already Administrator",
                            `\`${email}\` is already a Pterodactyl administrator.`
                        )
                    ]
                });
            }

            if (
                typeof pterodactyl.updateUser !== "function"
            ) {
                return message.reply({
                    embeds: [
                        errorEmbed(
                            "Feature Unavailable",
                            "The Pterodactyl service does not currently expose `updateUser`."
                        )
                    ]
                });
            }

            await pterodactyl.updateUser(id, {
                root_admin: true
            });

            return message.reply({
                embeds: [
                    successEmbed(
                        "Administrator Granted",
                        `Pterodactyl user \`${email}\` is now a root administrator.`
                    )
                ]
            });
        }

        /*
         * --------------------------------------------------------
         * !user remove admin
         * --------------------------------------------------------
         */

        if (
            subcommand === "remove" &&
            String(args?.[1] || "").toLowerCase() === "admin"
        ) {
            if (!isBotAdmin(message.author.id)) {
                return message.reply({
                    embeds: [
                        errorEmbed(
                            "Permission Denied",
                            "You do not have permission to remove Pterodactyl administrator access."
                        )
                    ]
                });
            }

            const email =
                String(args?.[2] || "").trim();

            if (!email) {
                return message.reply({
                    embeds: [
                        errorEmbed(
                            "Missing Email",
                            "Usage:\n`!user remove admin <email>`"
                        )
                    ]
                });
            }

            const existing =
                await pterodactyl.findUserByEmail(email);

            if (!existing) {
                return message.reply({
                    embeds: [
                        errorEmbed(
                            "User Not Found",
                            `No Pterodactyl user was found with \`${email}\`.`
                        )
                    ]
                });
            }

            const id =
                existing.id ||
                existing.attributes?.id;

            if (!id) {
                return message.reply({
                    embeds: [
                        errorEmbed(
                            "Pterodactyl Error",
                            "Could not determine the Pterodactyl user ID."
                        )
                    ]
                });
            }

            if (
                typeof pterodactyl.updateUser !== "function"
            ) {
                return message.reply({
                    embeds: [
                        errorEmbed(
                            "Feature Unavailable",
                            "The Pterodactyl service does not currently expose `updateUser`."
                        )
                    ]
                });
            }

            await pterodactyl.updateUser(id, {
                root_admin: false
            });

            return message.reply({
                embeds: [
                    successEmbed(
                        "Administrator Removed",
                        `Pterodactyl administrator access has been removed from \`${email}\`.`
                    )
                ]
            });
        }

        /*
         * --------------------------------------------------------
         * UNKNOWN SUBCOMMAND
         * --------------------------------------------------------
         */

        return message.reply({
            embeds: [
                errorEmbed(
                    "Unknown User Command",
                    [
                        "`!user create`",
                        "`!user info`",
                        "",
                        "**Admin:**",
                        "`!user create admin <email> <password>`",
                        "`!user make admin <email>`",
                        "`!user remove admin <email>`"
                    ].join("\n")
                )
            ]
        });
    } catch (error) {
        console.error("[User Prefix]", error);

        return message.reply({
            embeds: [
                errorEmbed(
                    "User Command Error",
                    error?.message ||
                    "An unexpected error occurred."
                )
            ]
        });
    }
}

/*
 * ============================================================
 * BUTTONS + MODAL
 * ============================================================
 */

export async function handleUserComponent(interaction) {
    const customId =
        interaction.customId;

    /*
     * --------------------------------------------------------
     * OPEN CREATE MODAL
     * --------------------------------------------------------
     */

    if (customId.startsWith("user_create_open:")) {
        const ownerId =
            customId.split(":")[1];

        if (interaction.user.id !== ownerId) {
            await interaction.reply({
                embeds: [
                    errorEmbed(
                        "Not Your Menu",
                        "Only the user who opened this menu can use it."
                    )
                ],
                ephemeral: true
            });

            return true;
        }

        const modal =
            new ModalBuilder()
                .setCustomId("user_create_modal")
                .setTitle("Create Pterodactyl Account");

        const emailInput =
            new TextInputBuilder()
                .setCustomId("user_create_email")
                .setLabel("Email Address")
                .setPlaceholder("you@example.com")
                .setStyle(TextInputStyle.Short)
                .setRequired(true)
                .setMaxLength(254);

        const passwordInput =
            new TextInputBuilder()
                .setCustomId("user_create_password")
                .setLabel("Pterodactyl Password")
                .setPlaceholder("Minimum 8 characters")
                .setStyle(TextInputStyle.Short)
                .setRequired(true)
                .setMinLength(8)
                .setMaxLength(72);

        modal.addComponents(
            new ActionRowBuilder().addComponents(
                emailInput
            ),
            new ActionRowBuilder().addComponents(
                passwordInput
            )
        );

        await interaction.showModal(modal);

        return true;
    }

    /*
     * --------------------------------------------------------
     * CANCEL
     * --------------------------------------------------------
     */

    if (customId.startsWith("user_create_cancel:")) {
        const ownerId =
            customId.split(":")[1];

        if (interaction.user.id !== ownerId) {
            await interaction.reply({
                embeds: [
                    errorEmbed(
                        "Not Your Menu",
                        "Only the user who opened this menu can cancel it."
                    )
                ],
                ephemeral: true
            });

            return true;
        }

        await interaction.update({
            embeds: [
                infoEmbed(
                    "Cancelled",
                    "Pterodactyl account creation was cancelled."
                )
            ],
            components: []
        });

        return true;
    }

    /*
     * --------------------------------------------------------
     * CREATE MODAL
     * --------------------------------------------------------
     */

    if (customId === "user_create_modal") {
        const email =
            interaction.fields
                .getTextInputValue("user_create_email")
                .trim()
                .toLowerCase();

        const password =
            interaction.fields
                .getTextInputValue("user_create_password");

        if (!isValidEmail(email)) {
            await interaction.reply({
                embeds: [
                    errorEmbed(
                        "Invalid Email",
                        "Please enter a valid email address."
                    )
                ],
                ephemeral: true
            });

            return true;
        }

        if (
            password.length < 8 ||
            password.length > 72
        ) {
            await interaction.reply({
                embeds: [
                    errorEmbed(
                        "Invalid Password",
                        "Your password must be between 8 and 72 characters."
                    )
                ],
                ephemeral: true
            });

            return true;
        }

        await interaction.deferReply({
            ephemeral: true
        });

        let localUser =
            getUser(interaction.user.id);

        if (!localUser) {
            localUser =
                ensureUser(
                    interaction.user.id,
                    interaction.user.username
                );
        }

        if (
            localUser &&
            getPterodactylUserId(localUser)
        ) {
            return interaction.editReply({
                embeds: [
                    errorEmbed(
                        "Already Linked",
                        "Your Discord account already has a Pterodactyl account."
                    )
                ]
            });
        }

        const existing =
            await pterodactyl.findUserByEmail(email);

        if (existing) {
            return interaction.editReply({
                embeds: [
                    errorEmbed(
                        "Email Already Used",
                        "A Pterodactyl account already exists with this email address."
                    )
                ]
            });
        }

        const username =
            generateUsername(email);

        const created =
            await pterodactyl.createUser({
                email,
                username,
                firstName:
                    interaction.user.username
                        .replace(/[^a-zA-Z0-9]/g, "")
                        .slice(0, 20) ||
                    "User",
                lastName: "User",
                password,
                rootAdmin: false
            });

        const pterodactylId =
            created?.id ||
            created?.attributes?.id;

        if (!pterodactylId) {
            throw new Error(
                "Pterodactyl created the account but did not return a user ID."
            );
        }

        if (
            typeof database.linkPterodactylUser !==
            "function"
        ) {
            throw new Error(
                "Database service is missing linkPterodactylUser()."
            );
        }

        await database.linkPterodactylUser({
            discordId:
                interaction.user.id,
            pterodactylId,
            email,
            username
        });

        return interaction.editReply({
            embeds: [
                successEmbed(
                    "Pterodactyl Account Created",
                    [
                        "Your Pterodactyl account has been created successfully.",
                        "",
                        `**Email:** \`${email}\``,
                        `**Username:** \`${username}\``,
                        `**Pterodactyl ID:** \`${pterodactylId}\``,
                        `**Administrator:** \`No\``,
                        "",
                        "Your Discord account is now linked to this Pterodactyl account."
                    ].join("\n")
                )
            ]
        });
    }

    return false;
}

/*
 * ============================================================
 * EXPORTS
 * ============================================================
 */

export const name = "user";

export default {
    name,
    data,
    execute,
    prefixExecute,
    handleUserComponent
};

/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */