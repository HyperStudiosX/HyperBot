/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */

import { SlashCommandBuilder } from "discord.js";
import { serverManager } from "../services/serverManager.js";
import { getUser } from "../services/userService.js";
import { successEmbed, errorEmbed } from "../utils/embeds.js";

export const data = new SlashCommandBuilder()
    .setName("power")
    .setDescription("Send a power action to your server.")
    .addStringOption(option =>
        option
            .setName("server_id")
            .setDescription("The Server ID of the server.")
            .setRequired(true)
    )
    .addStringOption(option =>
        option
            .setName("action")
            .setDescription("The power action to perform.")
            .setRequired(true)
            .addChoices(
                { name: "Start", value: "start" },
                { name: "Stop", value: "stop" },
                { name: "Restart", value: "restart" },
                { name: "Kill", value: "kill" }
            )
    )
    .setDMPermission(true);

export async function execute(interaction) {
    try {
        const serverId = interaction.options.getString("server_id", true);
        const action = interaction.options.getString("action", true);
        const user = getUser(interaction.user.id);

        if (!user) {
            return interaction.reply({
                embeds: [
                    errorEmbed(
                        "Account Not Found",
                        "Your account has not been registered yet."
                    )
                ],
                ephemeral: true
            });
        }

        await interaction.deferReply({ ephemeral: true });

        const server = serverManager.getOwnedServer(
            interaction.user.id,
            serverId
        );

        if (!server) {
            return interaction.editReply({
                embeds: [
                    errorEmbed(
                        "Server Not Found",
                        "The Server ID is invalid or this server does not belong to you."
                    )
                ]
            });
        }

        await serverManager.powerAction(interaction.user.id, server.id, action);

        const actionName =
            action.charAt(0).toUpperCase() + action.slice(1);

        return interaction.editReply({
            embeds: [
                successEmbed(
                    `Server ${actionName}`,
                    `Power action **${actionName}** has been sent to your server.\n\n` +
                    `**Server:** \`${server.name || serverId}\`\n` +
                    `**Server ID:** \`${serverId}\``
                )
            ]
        });
    } catch (error) {
        console.error("[Power]", error);

        if (interaction.deferred || interaction.replied) {
            return interaction.editReply({
                embeds: [
                    errorEmbed(
                        "Power Action Failed",
                        error?.message || "An unexpected error occurred while sending the power action."
                    )
                ]
            });
        }

        return interaction.reply({
            embeds: [
                errorEmbed(
                    "Power Action Failed",
                    error?.message || "An unexpected error occurred while sending the power action."
                )
            ],
            ephemeral: true
        });
    }
}

export default {
    data,
    execute
};

/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */