/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */

import { SlashCommandBuilder } from "discord.js";
import { serverManager } from "../services/serverManager.js";
import { getUser } from "../services/userService.js";
import { successEmbed, errorEmbed, warningEmbed } from "../utils/embeds.js";

export const data = new SlashCommandBuilder()
    .setName("reinstall")
    .setDescription("Reinstall your server.")
    .addStringOption(option =>
        option
            .setName("server_id")
            .setDescription("The Server ID of the server to reinstall.")
            .setRequired(true)
    )
    .setDMPermission(true);

export async function execute(interaction) {
    try {
        const serverId = interaction.options.getString("server_id", true);
        const user = getUser(interaction.user.id);

        if (!user) {
            return interaction.reply({
                embeds: [
                    errorEmbed(
                        "Account Not Found",
                        "Your account has not been registered yet."
                    )
                ],
                ephemeral: true
            });
        }

        const server = serverManager.getOwnedServer(
            interaction.user.id,
            serverId
        );

        if (!server) {
            return interaction.reply({
                embeds: [
                    errorEmbed(
                        "Server Not Found",
                        "The Server ID is invalid or this server does not belong to you."
                    )
                ],
                ephemeral: true
            });
        }

        return interaction.reply({
            embeds: [
                warningEmbed(
                    "⚠️ Server Reinstallation",
                    `You are about to reinstall **${server.name || "this server"}**.\n\n` +
                    `**Server ID:** \`${serverId}\`\n\n` +
                    "Reinstallation may reset or remove server files depending on your Pterodactyl configuration. Make sure you have a backup before continuing."
                )
            ],
            components: [
                {
                    type: 1,
                    components: [
                        {
                            type: 2,
                            custom_id: `reinstall_confirm:${serverId}`,
                            label: "Reinstall",
                            style: 4,
                            emoji: {
                                name: "🔄"
                            }
                        },
                        {
                            type: 2,
                            custom_id: `reinstall_cancel:${serverId}`,
                            label: "Cancel",
                            style: 2,
                            emoji: {
                                name: "✖️"
                            }
                        }
                    ]
                }
            ],
            ephemeral: true
        });
    } catch (error) {
        console.error("[Reinstall]", error);

        return interaction.reply({
            embeds: [
                errorEmbed(
                    "Reinstall Error",
                    error?.message || "An unexpected error occurred."
                )
            ],
            ephemeral: true
        });
    }
}

export async function handleReinstallConfirmation(interaction) {
    try {
        const [action, serverId] = interaction.customId.split(":");

        if (!serverId) {
            return interaction.reply({
                embeds: [
                    errorEmbed(
                        "Invalid Request",
                        "The Server ID could not be determined."
                    )
                ],
                ephemeral: true
            });
        }

        if (action === "reinstall_cancel") {
            return interaction.update({
                embeds: [
                    successEmbed(
                        "Reinstallation Cancelled",
                        `Server \`${serverId}\` was not reinstalled.`
                    )
                ],
                components: []
            });
        }

        if (action !== "reinstall_confirm") {
            return interaction.reply({
                content: "❌ Invalid reinstall action.",
                ephemeral: true
            });
        }

        const server = serverManager.getOwnedServer(
            interaction.user.id,
            serverId
        );

        if (!server) {
            return interaction.update({
                embeds: [
                    errorEmbed(
                        "Server Not Found",
                        "This server does not exist or no longer belongs to you."
                    )
                ],
                components: []
            });
        }

        await interaction.update({
            embeds: [
                warningEmbed(
                    "Reinstalling Server",
                    `Reinstalling **${server.name || serverId}**...\n\nPlease wait.`
                )
            ],
            components: []
        });

        await serverManager.reinstallServer(server);

        return interaction.editReply({
            embeds: [
                successEmbed(
                    "Server Reinstalled",
                    `Server \`${server.name || serverId}\` has been queued for reinstallation.\n\n**Server ID:** \`${serverId}\``
                )
            ],
            components: []
        });
    } catch (error) {
        console.error("[Reinstall Confirmation]", error);

        if (interaction.deferred || interaction.replied) {
            return interaction.editReply({
                embeds: [
                    errorEmbed(
                        "Failed to Reinstall Server",
                        error?.message || "An unexpected error occurred while reinstalling the server."
                    )
                ],
                components: []
            });
        }

        return interaction.reply({
            embeds: [
                errorEmbed(
                    "Failed to Reinstall Server",
                    error?.message || "An unexpected error occurred while reinstalling the server."
                )
            ],
            ephemeral: true
        });
    }
}

export default {
    data,
    execute,
    handleReinstallConfirmation
};

/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */