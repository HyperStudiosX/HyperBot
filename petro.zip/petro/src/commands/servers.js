/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */

import { SlashCommandBuilder } from "discord.js";
import { getUserServers } from "../services/userService.js";
import {
    createEmbed,
    errorEmbed
} from "../utils/embeds.js";
import {
    paginationButtons
} from "../utils/components.js";

/*
 * ============================================================
 * COMMAND DATA
 * ============================================================
 */

export const data =
    new SlashCommandBuilder()
        .setName("servers")
        .setDescription(
            "View all servers linked to your account."
        )
        .setDMPermission(true);

/*
 * ============================================================
 * MAIN COMMAND
 * ============================================================
 */

export async function execute(
    interaction
) {
    try {
        const discordId =
            interaction.user.id;

        const servers =
            getUserServers(
                discordId
            );

        if (
            !Array.isArray(servers) ||
            servers.length === 0
        ) {
            return interaction.reply({
                embeds: [
                    errorEmbed(
                        "No Servers",
                        "You don't have any servers linked to your account.\n\nUse `/deploy` to create a server."
                    )
                ],
                ephemeral: true
            });
        }

        const pageSize = 10;

        const totalPages =
            Math.max(
                1,
                Math.ceil(
                    servers.length /
                    pageSize
                )
            );

        return sendServerPage(
            interaction,
            servers,
            0,
            totalPages
        );
    } catch (error) {
        console.error(
            "[Servers]",
            error
        );

        const message =
            error?.message ||
            "An unexpected error occurred while loading your servers.";

        if (
            interaction.replied ||
            interaction.deferred
        ) {
            return interaction.editReply({
                embeds: [
                    errorEmbed(
                        "Failed to Load Servers",
                        message
                    )
                ],
                components: []
            });
        }

        return interaction.reply({
            embeds: [
                errorEmbed(
                    "Failed to Load Servers",
                    message
                )
            ],
            ephemeral: true
        });
    }
}

/*
 * ============================================================
 * PAGINATION HANDLER
 * ============================================================
 */

export async function handleServersPagination(
    interaction
) {
    try {
        const parts =
            String(
                interaction.customId ||
                ""
            ).split(":");

        /*
         * Expected custom ID:
         *
         * servers:previous:1
         * servers:next:1
         */
        const direction =
            parts[1] || "";

        const currentPage =
            Number(
                parts[2]
            );

        const servers =
            getUserServers(
                interaction.user.id
            );

        if (
            !Array.isArray(servers) ||
            servers.length === 0
        ) {
            return interaction.update({
                embeds: [
                    errorEmbed(
                        "No Servers",
                        "You don't have any servers linked to your account."
                    )
                ],
                components: []
            });
        }

        const pageSize = 10;

        const totalPages =
            Math.max(
                1,
                Math.ceil(
                    servers.length /
                    pageSize
                )
            );

        let page =
            Number.isFinite(
                currentPage
            )
                ? currentPage
                : 0;

        if (
            direction === "next"
        ) {
            page++;
        }

        if (
            direction === "previous"
        ) {
            page--;
        }

        page =
            Math.max(
                0,
                Math.min(
                    page,
                    totalPages - 1
                )
            );

        return sendServerPage(
            interaction,
            servers,
            page,
            totalPages,
            true
        );
    } catch (error) {
        console.error(
            "[Servers Pagination]",
            error
        );

        const message =
            error?.message ||
            "Unable to change the server page.";

        if (
            interaction.replied ||
            interaction.deferred
        ) {
            return interaction.editReply({
                embeds: [
                    errorEmbed(
                        "Pagination Error",
                        message
                    )
                ],
                components: []
            });
        }

        return interaction.reply({
            embeds: [
                errorEmbed(
                    "Pagination Error",
                    message
                )
            ],
            ephemeral: true
        });
    }
}

/*
 * ============================================================
 * BUILD SERVER STATUS
 * ============================================================
 */

function formatStatus(
    status
) {
    const value =
        String(
            status ||
            "unknown"
        ).trim();

    const normalized =
        value.toLowerCase();

    const icons = {
        running: "🟢",
        online: "🟢",
        active: "🟢",
        starting: "🟡",
        stopping: "🟠",
        offline: "🔴",
        stopped: "🔴",
        suspended: "⛔",
        installing: "🔵",
        restoring: "🔵",
        unknown: "⚪"
    };

    const icon =
        icons[
            normalized
        ] ||
        "⚪";

    return `${icon} ${value}`;
}

/*
 * ============================================================
 * FORMAT PLAN
 * ============================================================
 */

function formatPlan(
    server
) {
    return (
        server?.plan ||
        server?.plan_name ||
        server?.planName ||
        "Custom"
    );
}

/*
 * ============================================================
 * BUILD SERVER DESCRIPTION
 * ============================================================
 */

function buildServerDescription(
    server,
    number
) {
    const name =
        String(
            server?.name ||
            `Server ${server?.id || number}`
        );

    const localId =
        server?.id ??
        "Unknown";

    const pterodactylId =
        server?.pterodactyl_id ??
        server?.pterodactylId ??
        null;

    const identifier =
        server?.identifier ||
        null;

    const status =
        formatStatus(
            server?.status
        );

    const plan =
        formatPlan(
            server
        );

    let output =
        `**${number}. ${name}**\n`;

    output +=
        `> 🆔 Server ID: \`${localId}\`\n`;

    if (
        pterodactylId !== null
    ) {
        output +=
            `> 🔢 Pterodactyl ID: \`${pterodactylId}\`\n`;
    }

    if (
        identifier
    ) {
        output +=
            `> 🔑 Identifier: \`${identifier}\`\n`;
    }

    output +=
        `> 📡 Status: ${status}\n`;

    output +=
        `> 📦 Plan: \`${plan}\``;

    return output;
}

/*
 * ============================================================
 * SEND SERVER PAGE
 * ============================================================
 */

async function sendServerPage(
    interaction,
    servers,
    page,
    totalPages,
    update = false
) {
    const pageSize = 10;

    const safeTotalPages =
        Math.max(
            1,
            Number(
                totalPages
            ) || 1
        );

    const safePage =
        Math.max(
            0,
            Math.min(
                Number(page) || 0,
                safeTotalPages - 1
            )
        );

    const start =
        safePage *
        pageSize;

    const pageServers =
        servers.slice(
            start,
            start + pageSize
        );

    const description =
        pageServers
            .map(
                (
                    server,
                    index
                ) =>
                    buildServerDescription(
                        server,
                        start +
                            index +
                            1
                    )
            )
            .join(
                "\n\n"
            );

    const serverCount =
        servers.length;

    const embed =
        createEmbed({
            title:
                "🖥️ Your Servers",

            description:
                description ||
                "No servers are available on this page.",

            color:
                0x5865F2,

            footer: {
                text:
                    `Page ${safePage + 1}/${safeTotalPages} • ${serverCount} server${serverCount === 1 ? "" : "s"}`
            }
        });

    const components =
        safeTotalPages > 1
            ? [
                paginationButtons(
                    "servers",
                    safePage,
                    safeTotalPages
                )
            ]
            : [];

    if (
        update
    ) {
        return interaction.update({
            embeds: [
                embed
            ],
            components
        });
    }

    return interaction.reply({
        embeds: [
            embed
        ],
        components,
        ephemeral: true
    });
}

/*
 * ============================================================
 * EXPORT
 * ============================================================
 */

export default {
    data,
    execute,
    handleServersPagination
};

/*
 * ============================================================
 * End of servers.js
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * PetroBot V2 Servers Command.
 * ============================================================
 */