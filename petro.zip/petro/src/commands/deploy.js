/*
 * ============================================================
 * PetroBot V2 - Deploy Command
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */

import deployment from "../services/deployment.js";
import resourceManager from "../services/resourceManager.js";
import { createEmbed, errorEmbed } from "../utils/embeds.js";

export const name = "deploy";
export const description = "Deploy a Pterodactyl server using your resources.";

export const aliases = [
    "create",
    "createserver",
    "serverdeploy"
];

export const data = {
    name: "deploy",
    description: "Deploy a Pterodactyl server using your resources.",
    options: [
        {
            name: "ram",
            description: "RAM in MB.",
            type: 4,
            required: true
        },
        {
            name: "cpu",
            description: "CPU percentage.",
            type: 4,
            required: true
        },
        {
            name: "disk",
            description: "Disk in MB.",
            type: 4,
            required: true
        },
        {
            name: "name",
            description: "Name of the server.",
            type: 3,
            required: false
        }
    ]
};

/*
 * ============================================================
 * CONSTANTS
 * ============================================================
 */

const MAX_SERVER_NAME_LENGTH = 100;

const DEFAULT_BACKUPS = 0;
const DEFAULT_ALLOCATIONS = 1;
const DEFAULT_DATABASES = 0;
const DEFAULT_SERVER_SLOTS = 1;

/*
 * ============================================================
 * HELPERS
 * ============================================================
 */

function toNumber(value, fallback = 0) {
    const number = Number(value);

    return Number.isFinite(number)
        ? number
        : fallback;
}

function formatNumber(value) {
    return toNumber(value).toLocaleString("en-US");
}

function formatGb(mb) {
    const gb = toNumber(mb) / 1024;

    if (!Number.isFinite(gb)) {
        return "0 GB";
    }

    if (Number.isInteger(gb)) {
        return `${gb} GB`;
    }

    return `${gb.toFixed(2)} GB`;
}

function normalizeResources(ram, cpu, disk) {
    return {
        ram: Math.floor(toNumber(ram)),
        cpu: Math.floor(toNumber(cpu)),
        disk: Math.floor(toNumber(disk)),
        backups: DEFAULT_BACKUPS,
        allocations: DEFAULT_ALLOCATIONS,
        databases: DEFAULT_DATABASES,
        server_slots: DEFAULT_SERVER_SLOTS
    };
}

function getServerName(message, args) {
    const suppliedName = args
        .slice(3)
        .join(" ")
        .trim();

    if (suppliedName) {
        return suppliedName;
    }

    const username =
        message?.author?.username ||
        "Player";

    return `${username}'s Server`;
}

function getMissingLines(missing) {
    const lines = [];

    if (toNumber(missing?.ram) > 0) {
        lines.push(
            `🧠 RAM: **${formatGb(missing.ram)}**`
        );
    }

    if (toNumber(missing?.cpu) > 0) {
        lines.push(
            `⚙️ CPU: **${formatNumber(missing.cpu)}%**`
        );
    }

    if (toNumber(missing?.disk) > 0) {
        lines.push(
            `💾 Disk: **${formatGb(missing.disk)}**`
        );
    }

    if (toNumber(missing?.allocations) > 0) {
        lines.push(
            `🌐 Allocations: **${formatNumber(missing.allocations)}**`
        );
    }

    if (toNumber(missing?.databases) > 0) {
        lines.push(
            `🗄️ Databases: **${formatNumber(missing.databases)}**`
        );
    }

    if (toNumber(missing?.backups) > 0) {
        lines.push(
            `💿 Backups: **${formatNumber(missing.backups)}**`
        );
    }

    if (toNumber(missing?.server_slots) > 0) {
        lines.push(
            `🖥️ Server Slots: **${formatNumber(missing.server_slots)}**`
        );
    }

    return lines;
}

function resourceSummary(resources) {
    return (
        `🧠 RAM: **${formatGb(resources.ram)}**\n` +
        `⚙️ CPU: **${formatNumber(resources.cpu)}%**\n` +
        `💾 Disk: **${formatGb(resources.disk)}**\n` +
        `🌐 Allocations: **${formatNumber(resources.allocations)}**\n` +
        `🗄️ Databases: **${formatNumber(resources.databases)}**\n` +
        `💿 Backups: **${formatNumber(resources.backups)}**\n` +
        `🖥️ Server Slots: **${formatNumber(resources.server_slots)}**`
    );
}

function requestedSummary(resources) {
    return (
        `🧠 RAM: **${formatGb(resources.ram)}**\n` +
        `⚙️ CPU: **${formatNumber(resources.cpu)}%**\n` +
        `💾 Disk: **${formatGb(resources.disk)}**\n` +
        `🌐 Allocations: **${formatNumber(resources.allocations)}**\n` +
        `🗄️ Databases: **${formatNumber(resources.databases)}**\n` +
        `💿 Backups: **${formatNumber(resources.backups)}**\n` +
        `🖥️ Server Slots: **${formatNumber(resources.server_slots)}**`
    );
}

function buildResourceErrorEmbed(
    requested,
    available,
    missing
) {
    const embed = createEmbed({
        title: "❌ Extra Resources Demanded",
        description:
            "You do not currently have enough resources to deploy this server.",
        color: 0xED4245
    });

    embed.addFields(
        {
            name: "📦 Requested",
            value: requestedSummary(requested),
            inline: true
        },
        {
            name: "📊 Available",
            value: resourceSummary(available),
            inline: true
        }
    );

    const missingLines =
        getMissingLines(missing);

    embed.addFields({
        name: "⚠️ Missing Resources",
        value:
            missingLines.length > 0
                ? missingLines.join("\n")
                : "None",
        inline: false
    });

    embed.addFields({
        name: "💡 Get More Resources",
        value:
            "🛒 `!plans` — View hosting plans\n" +
            "💰 `!buy <planid>` — Purchase a plan with coins\n" +
            "🎟️ `!redeem <code>` — Redeem a resource code\n" +
            "📊 `!resources` — View your resources",
        inline: false
    });

    embed.setFooter({
        text: "HyperForgeX • Petro V2"
    });

    return embed;
}

function buildLoadingEmbed(
    serverName,
    resources
) {
    const embed = createEmbed({
        title: "🚀 Deploying Server",
        description:
            `Preparing **${serverName}** for deployment.\n\n` +
            "The deployment system is checking your resources, " +
            "available nodes and allocations.",
        color: 0x5865F2
    });

    embed.addFields(
        {
            name: "🖥️ Server",
            value: `**${serverName}**`,
            inline: true
        },
        {
            name: "📦 Resources",
            value:
                `🧠 ${formatGb(resources.ram)} RAM\n` +
                `⚙️ ${formatNumber(resources.cpu)}% CPU\n` +
                `💾 ${formatGb(resources.disk)} Disk`,
            inline: true
        },
        {
            name: "🔎 Deployment Checks",
            value:
                "⏳ Checking resource balance\n" +
                "⏳ Finding available node\n" +
                "⏳ Finding available allocation\n" +
                "⏳ Creating Pterodactyl server",
            inline: false
        }
    );

    embed.setFooter({
        text: "HyperForgeX • Petro V2"
    });

    return embed;
}

function getServerIdentifier(server) {
    return (
        server?.identifier ??
        server?.serverIdentifier ??
        server?.server_identifier ??
        null
    );
}

function getPterodactylServerId(server) {
    return (
        server?.pterodactyl_id ??
        server?.pterodactylId ??
        server?.id ??
        null
    );
}

function getServerNode(server, result) {
    return (
        server?.node ??
        server?.node_name ??
        server?.nodeName ??
        result?.node?.name ??
        result?.target?.node?.name ??
        result?.deployment?.node?.name ??
        null
    );
}

function getServerAllocation(server, result) {
    return (
        server?.allocation_id ??
        server?.allocationId ??
        result?.allocation?.id ??
        result?.target?.allocation?.id ??
        null
    );
}

function buildSuccessEmbed(
    serverName,
    requested,
    result
) {
    const server =
        result?.server ??
        result?.pterodactylServer ??
        result ??
        {};

    const identifier =
        getServerIdentifier(server);

    const pterodactylId =
        getPterodactylServerId(server);

    const node =
        getServerNode(
            server,
            result
        );

    const allocation =
        getServerAllocation(
            server,
            result
        );

    const embed = createEmbed({
        title: "✅ Server Deployed Successfully",
        description:
            `**${serverName}** has been successfully deployed on Pterodactyl.`,
        color: 0x57F287
    });

    const details = [];

    if (pterodactylId !== null) {
        details.push(
            `🆔 **Server ID:** \`${pterodactylId}\``
        );
    }

    if (identifier) {
        details.push(
            `🔑 **Identifier:** \`${identifier}\``
        );
    }

    if (node) {
        details.push(
            `🖥️ **Node:** \`${node}\``
        );
    }

    if (allocation !== null) {
        details.push(
            `🌐 **Allocation:** \`${allocation}\``
        );
    }

    details.push(
        `📛 **Name:** ${server?.name ?? serverName}`,
        `📡 **Status:** ${server?.status ?? "Installing"}`
    );

    embed.addFields({
        name: "🖥️ Server Details",
        value: details.join("\n"),
        inline: false
    });

    embed.addFields({
        name: "📦 Resources Used",
        value:
            `🧠 RAM: **${formatGb(requested.ram)}**\n` +
            `⚙️ CPU: **${formatNumber(requested.cpu)}%**\n` +
            `💾 Disk: **${formatGb(requested.disk)}**\n` +
            `🌐 Allocation: **${formatNumber(requested.allocations)}**\n` +
            `🖥️ Server Slot: **${formatNumber(requested.server_slots)}**`,
        inline: false
    });

    embed.addFields({
        name: "⚡ Manage",
        value:
            "`!myserver` — View your servers\n" +
            "`!manage` — Open server management\n" +
            "`!status <server>` — Check server status",
        inline: false
    });

    embed.setFooter({
        text: "HyperForgeX • Petro V2"
    });

    return embed;
}

function getDeploymentError(error) {
    const code = String(
        error?.code ??
        error?.name ??
        ""
    ).toUpperCase();

    const message = String(
        error?.message ??
        ""
    );

    if (
        code === "NO_ALLOCATION" ||
        code.includes("NO_ALLOCATION") ||
        message.toLowerCase().includes(
            "no free allocation"
        )
    ) {
        return {
            title: "❌ No Free Allocation",
            description:
                "There are currently no free allocations available on the configured nodes.\n\n" +
                "Please try again later."
        };
    }

    if (
        code === "NODE_CAPACITY" ||
        code.includes("NODE_CAPACITY")
    ) {
        return {
            title: "❌ Node Capacity Reached",
            description:
                "No configured node currently has enough capacity for this server.\n\n" +
                "The deployment system checked the available nodes."
        };
    }

    if (
        code === "PTERODACTYL_USER" ||
        code.includes("PTERODACTYL_USER")
    ) {
        return {
            title: "❌ Pterodactyl User Error",
            description:
                "Your Pterodactyl user account could not be created or located.\n\n" +
                "Please contact an administrator."
        };
    }

    if (
        code === "PTERODACTYL_API" ||
        code.includes("PTERODACTYL")
    ) {
        return {
            title: "❌ Pterodactyl Error",
            description:
                "Pterodactyl rejected or could not process the deployment request."
        };
    }

    if (
        code === "RESOURCE_ERROR" ||
        code.includes("RESOURCE")
    ) {
        return {
            title: "❌ Resource Error",
            description:
                "There was a problem processing the resources required for deployment."
        };
    }

    return {
        title: "❌ Deployment Failed",
        description:
            message ||
            "The server could not be deployed."
    };
}

function buildFailureEmbed(
    error,
    resources
) {
    const details =
        getDeploymentError(error);

    const embed = createEmbed({
        title: details.title,
        description: details.description,
        color: 0xED4245
    });

    embed.addFields({
        name: "📦 Resource Protection",
        value:
            "Your deployment resources are handled atomically by the deployment service. " +
            "If the deployment could not be completed, consumed resources are restored.",
        inline: false
    });

    if (resources) {
        embed.addFields({
            name: "📋 Requested Resources",
            value:
                `🧠 RAM: **${formatGb(resources.ram)}**\n` +
                `⚙️ CPU: **${formatNumber(resources.cpu)}%**\n` +
                `💾 Disk: **${formatGb(resources.disk)}**`,
            inline: false
        });
    }

    embed.setFooter({
        text: "HyperForgeX • Petro V2"
    });

    return embed;
}

function validateInput(
    ram,
    cpu,
    disk,
    serverName
) {
    if (
        !Number.isFinite(ram) ||
        ram <= 0
    ) {
        return {
            valid: false,
            message:
                "❌ **Invalid RAM**\n\n" +
                "RAM must be a positive number in MB.\n" +
                "Example: `!deploy 2048 100 5120 My Server`"
        };
    }

    if (
        !Number.isFinite(cpu) ||
        cpu <= 0
    ) {
        return {
            valid: false,
            message:
                "❌ **Invalid CPU**\n\n" +
                "CPU must be a positive percentage.\n" +
                "Example: `!deploy 2048 100 5120 My Server`"
        };
    }

    if (
        !Number.isFinite(disk) ||
        disk <= 0
    ) {
        return {
            valid: false,
            message:
                "❌ **Invalid Disk**\n\n" +
                "Disk must be a positive number in MB.\n" +
                "Example: `!deploy 2048 100 5120 My Server`"
        };
    }

    if (
        !Number.isInteger(ram) ||
        !Number.isInteger(cpu) ||
        !Number.isInteger(disk)
    ) {
        return {
            valid: false,
            message:
                "❌ RAM, CPU and Disk must be whole numbers."
        };
    }

    if (
        serverName.length < 1 ||
        serverName.length >
            MAX_SERVER_NAME_LENGTH
    ) {
        return {
            valid: false,
            message:
                `❌ Server name must be between 1 and ${MAX_SERVER_NAME_LENGTH} characters.`
        };
    }

    return {
        valid: true
    };
}

/*
 * ============================================================
 * RESOURCE CHECK
 * ============================================================
 */

export function checkDeploymentResources(
    userId,
    requested
) {
    resourceManager.ensureResourceAccount(
        userId
    );

    const available =
        resourceManager.getResources(
            userId
        );

    const missing =
        resourceManager.getMissingResources(
            available,
            requested
        );

    return {
        available,
        missing,
        sufficient:
            !missing?.hasMissing
    };
}

/*
 * ============================================================
 * PREFIX COMMAND
 * ============================================================
 */

/**
 * !deploy <RAM_MB> <CPU_%> <DISK_MB> [server name]
 *
 * Example:
 * !deploy 2048 100 5120 My Server
 */
export async function execute(
    message,
    args = []
) {
    const userId = String(
        message?.author?.id ?? ""
    ).trim();

    if (!userId) {
        return message.reply({
            embeds: [
                errorEmbed(
                    "Deployment Error",
                    "I could not determine your Discord account."
                )
            ]
        });
    }

    const ram = Number(args[0]);
    const cpu = Number(args[1]);
    const disk = Number(args[2]);

    const serverName =
        getServerName(
            message,
            args
        );

    const validation =
        validateInput(
            ram,
            cpu,
            disk,
            serverName
        );

    if (!validation.valid) {
        return message.reply({
            content: validation.message
        });
    }

    const requested =
        normalizeResources(
            ram,
            cpu,
            disk
        );

    /*
     * --------------------------------------------------------
     * RESOURCE CHECK
     * --------------------------------------------------------
     */

    try {
        const check =
            checkDeploymentResources(
                userId,
                requested
            );

        if (!check.sufficient) {
            return message.reply({
                embeds: [
                    buildResourceErrorEmbed(
                        requested,
                        check.available,
                        check.missing
                    )
                ]
            });
        }
    } catch (error) {
        console.error(
            `[Deploy] Resource check failed for ${userId}:`,
            error
        );

        return message.reply({
            embeds: [
                errorEmbed(
                    "Resource Check Failed",
                    "I could not verify your available resources. The deployment was not started."
                )
            ]
        });
    }

    /*
     * --------------------------------------------------------
     * DEPLOYMENT MESSAGE
     * --------------------------------------------------------
     */

    let reply;

    try {
        reply = await message.reply({
            embeds: [
                buildLoadingEmbed(
                    serverName,
                    requested
                )
            ]
        });
    } catch (error) {
        console.error(
            "[Deploy] Failed to send loading message:",
            error
        );

        return;
    }

    /*
     * --------------------------------------------------------
     * ACTUAL DEPLOYMENT
     * --------------------------------------------------------
     */

    try {
        const result =
            await deployment.deploy({
                discordId: userId,
                username:
                    message?.author?.username ??
                    null,
                serverName,
                resources: requested
            });

        const successEmbed =
            buildSuccessEmbed(
                serverName,
                requested,
                result
            );

        return reply.edit({
            embeds: [
                successEmbed
            ]
        });
    } catch (error) {
        console.error(
            `[Deploy] Deployment failed for ${userId}:`,
            error
        );

        const failureEmbed =
            buildFailureEmbed(
                error,
                requested
            );

        try {
            return reply.edit({
                embeds: [
                    failureEmbed
                ]
            });
        } catch (editError) {
            console.error(
                "[Deploy] Failed to edit deployment message:",
                editError
            );

            return message.reply({
                embeds: [
                    failureEmbed
                ]
            });
        }
    }
}

/*
 * ============================================================
 * PREFIX COMPATIBILITY
 * ============================================================
 */

export async function prefixExecute(
    message,
    args = []
) {
    return execute(
        message,
        args
    );
}

/*
 * ============================================================
 * SLASH COMMAND
 * ============================================================
 */

export async function executeSlash(
    interaction
) {
    const userId = String(
        interaction?.user?.id ?? ""
    ).trim();

    if (!userId) {
        return interaction.reply({
            embeds: [
                errorEmbed(
                    "Deployment Error",
                    "I could not determine your Discord account."
                )
            ],
            ephemeral: true
        });
    }

    const ram =
        interaction.options.getInteger(
            "ram"
        );

    const cpu =
        interaction.options.getInteger(
            "cpu"
        );

    const disk =
        interaction.options.getInteger(
            "disk"
        );

    const serverName =
        interaction.options.getString(
            "name"
        )?.trim() ||
        `${interaction.user.username}'s Server`;

    const validation =
        validateInput(
            ram,
            cpu,
            disk,
            serverName
        );

    if (!validation.valid) {
        return interaction.reply({
            content: validation.message,
            ephemeral: true
        });
    }

    const requested =
        normalizeResources(
            ram,
            cpu,
            disk
        );

    try {
        const check =
            checkDeploymentResources(
                userId,
                requested
            );

        if (!check.sufficient) {
            return interaction.reply({
                embeds: [
                    buildResourceErrorEmbed(
                        requested,
                        check.available,
                        check.missing
                    )
                ],
                ephemeral: true
            });
        }
    } catch (error) {
        console.error(
            `[Deploy] Slash resource check failed for ${userId}:`,
            error
        );

        return interaction.reply({
            embeds: [
                errorEmbed(
                    "Resource Check Failed",
                    "I could not verify your available resources. The deployment was not started."
                )
            ],
            ephemeral: true
        });
    }

    try {
        await interaction.reply({
            embeds: [
                buildLoadingEmbed(
                    serverName,
                    requested
                )
            ]
        });
    } catch (error) {
        console.error(
            "[Deploy] Failed to send slash loading message:",
            error
        );

        return;
    }

    try {
        const result =
            await deployment.deploy({
                discordId: userId,
                username:
                    interaction?.user?.username ??
                    null,
                serverName,
                resources: requested
            });

        return interaction.editReply({
            embeds: [
                buildSuccessEmbed(
                    serverName,
                    requested,
                    result
                )
            ]
        });
    } catch (error) {
        console.error(
            `[Deploy] Slash deployment failed for ${userId}:`,
            error
        );

        return interaction.editReply({
            embeds: [
                buildFailureEmbed(
                    error,
                    requested
                )
            ]
        });
    }
}

/*
 * ============================================================
 * DEFAULT EXPORT
 * ============================================================
 */

const deployCommand = {
    name,
    description,
    aliases,
    data,
    execute,
    prefixExecute,
    executeSlash,
    checkDeploymentResources
};

export default deployCommand;

/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */