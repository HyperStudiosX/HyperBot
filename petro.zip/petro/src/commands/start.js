/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */

import { SlashCommandBuilder } from "discord.js";
import { serverManager } from "../services/serverManager.js";
import { getUser } from "../services/userService.js";
import { successEmbed, errorEmbed } from "../utils/embeds.js";

export const data = new SlashCommandBuilder()
    .setName("start")
    .setDescription("Start your server.")
    .addStringOption(option =>
        option
            .setName("server_id")
            .setDescription("The Server ID of the server to start.")
            .setRequired(true)
    )
    .setDMPermission(true);

export async function execute(interaction) {
    try {
        const serverId = interaction.options.getString("server_id", true);
        const user = getUser(interaction.user.id);

        if (!user) {
            return interaction.reply({
                embeds: [
                    errorEmbed(
                        "Account Not Found",
                        "Your account has not been registered yet."
                    )
                ],
                ephemeral: true
            });
        }

        await interaction.deferReply({ ephemeral: true });

        const server = serverManager.getOwnedServer(
            interaction.user.id,
            serverId
        );

        if (!server) {
            return interaction.editReply({
                embeds: [
                    errorEmbed(
                        "Server Not Found",
                        "The Server ID is invalid or this server does not belong to you."
                    )
                ]
            });
        }

        await serverManager.startServer(server);

        return interaction.editReply({
            embeds: [
                successEmbed(
                    "Server Starting",
                    `Server \`${server.name || serverId}\` is starting.\n\n**Server ID:** \`${serverId}\``
                )
            ]
        });
    } catch (error) {
        console.error("[Start]", error);

        if (interaction.deferred || interaction.replied) {
            return interaction.editReply({
                embeds: [
                    errorEmbed(
                        "Failed to Start Server",
                        error?.message || "An unexpected error occurred while starting the server."
                    )
                ]
            });
        }

        return interaction.reply({
            embeds: [
                errorEmbed(
                    "Failed to Start Server",
                    error?.message || "An unexpected error occurred while starting the server."
                )
            ],
            ephemeral: true
        });
    }
}

export default {
    data,
    execute
};

/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */