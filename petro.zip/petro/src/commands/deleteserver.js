/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * PetroBot V2 - Delete Server Command
 * ============================================================
 */

import {
    SlashCommandBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle
} from "discord.js";

import serverManager from "../services/serverManager.js";
import database from "../database.js";
import {
    createEmbed,
    errorEmbed
} from "../utils/embeds.js";

export const name = "deleteserver";

export const description =
    "Delete one of your Pterodactyl servers.";

export const aliases = [
    "delete",
    "delserver",
    "rmserver"
];

export const data =
    new SlashCommandBuilder()
        .setName("deleteserver")
        .setDescription(
            "Delete one of your Pterodactyl servers."
        )
        .addStringOption(option =>
            option
                .setName("server")
                .setDescription(
                    "Server ID or Pterodactyl server identifier."
                )
                .setRequired(true)
        )
        .setDMPermission(true);

/* ============================================================
 * SERVER LOOKUP
 * ============================================================
 */

function findUserServer(
    discordId,
    value
) {
    const input =
        String(value ?? "")
            .trim();

    if (!input) {
        return null;
    }

    /*
     * Prefer the database helper designed for
     * user-owned server lookup.
     */
    if (
        typeof database.findServerForUser ===
        "function"
    ) {
        const server =
            database.findServerForUser(
                discordId,
                input
            );

        if (server) {
            return server;
        }
    }

    /*
     * Try a numeric local database ID.
     */
    if (
        /^\d+$/.test(input) &&
        typeof database.getServerForUser ===
        "function"
    ) {
        const server =
            database.getServerForUser(
                discordId,
                Number(input)
            );

        if (server) {
            return server;
        }
    }

    /*
     * Fallback to the user's server list.
     */
    if (
        typeof database.getUserServers ===
        "function"
    ) {
        const servers =
            database.getUserServers(
                discordId
            );

        const lower =
            input.toLowerCase();

        return servers.find(server => {
            return (
                String(server.id) === input ||
                String(
                    server.pterodactyl_id ??
                    ""
                ) === input ||
                String(
                    server.identifier ??
                    ""
                ).toLowerCase() === lower
            );
        }) || null;
    }

    return null;
}

/* ============================================================
 * SERVER NAME
 * ============================================================
 */

function getServerName(server) {
    return (
        server?.name ||
        server?.identifier ||
        `Server #${server?.id ?? "Unknown"}`
    );
}

/* ============================================================
 * SERVER IDENTIFIER
 * ============================================================
 */

function getServerIdentifier(server) {
    return (
        server?.identifier ||
        server?.pterodactyl_id ||
        server?.id
    );
}

/* ============================================================
 * RESOURCE FORMAT
 * ============================================================
 */

function formatMemory(value) {
    const mb =
        Number(value || 0);

    if (mb >= 1024) {
        const gb =
            mb / 1024;

        if (
            Number.isInteger(gb)
        ) {
            return `${gb} GB`;
        }

        return `${gb.toFixed(2)} GB`;
    }

    return `${mb} MB`;
}

/* ============================================================
 * CONFIRMATION EMBED
 * ============================================================
 */

function buildConfirmationEmbed(
    server
) {
    const embed =
        createEmbed({
            title: "⚠️ Delete Server?",
            description:
                "You are about to permanently delete the following server from Pterodactyl.\n\n" +
                "**This action cannot be undone.**",
            color: 0xED4245
        });

    embed.addFields(
        {
            name: "🖥️ Server",
            value:
                `**${getServerName(server)}**`,
            inline: false
        },
        {
            name: "🆔 Server ID",
            value:
                `\`${server.id}\``,
            inline: true
        },
        {
            name: "🔑 Identifier",
            value:
                `\`${getServerIdentifier(server)}\``,
            inline: true
        },
        {
            name: "📦 Resources",
            value:
                `RAM: **${formatMemory(server.ram)}**\n` +
                `CPU: **${Number(server.cpu || 0)}%**\n` +
                `Disk: **${formatMemory(server.disk)}**`,
            inline: false
        }
    );

    embed.setFooter({
        text:
            "HyperForgeX • Petro V2 • Deletion requires confirmation"
    });

    return embed;
}

/* ============================================================
 * CONFIRMATION BUTTONS
 * ============================================================
 */

function buildConfirmationButtons(
    userId,
    serverId
) {
    return new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId(
                    `delete_server_confirm:${userId}:${serverId}`
                )
                .setLabel("Delete Server")
                .setEmoji("🗑️")
                .setStyle(
                    ButtonStyle.Danger
                ),
            new ButtonBuilder()
                .setCustomId(
                    `delete_server_cancel:${userId}:${serverId}`
                )
                .setLabel("Cancel")
                .setEmoji("❌")
                .setStyle(
                    ButtonStyle.Secondary
                )
        );
}

/* ============================================================
 * SHOW DELETE CONFIRMATION
 * ============================================================
 */

async function showDeleteConfirmation(
    target,
    user
) {
    const server =
        findUserServer(
            user.id,
            target
        );

    if (!server) {
        return {
            embeds: [
                errorEmbed(
                    "Server Not Found",
                    "I could not find a server matching that ID or identifier in your account."
                )
            ]
        };
    }

    return {
        embeds: [
            buildConfirmationEmbed(
                server
            )
        ],
        components: [
            buildConfirmationButtons(
                user.id,
                server.id
            )
        ]
    };
}

/* ============================================================
 * DELETE SERVER
 * ============================================================
 */

async function deleteServer(
    interaction,
    serverId,
    userId
) {
    const server =
        findUserServer(
            userId,
            serverId
        );

    if (!server) {
        const response = {
            embeds: [
                errorEmbed(
                    "Server Not Found",
                    "This server no longer exists in your Petro account."
                )
            ],
            components: []
        };

        if (
            interaction.deferred ||
            interaction.replied
        ) {
            return interaction.editReply(
                response
            );
        }

        return interaction.reply({
            ...response,
            ephemeral: true
        });
    }

    try {
        /*
         * serverManager.deleteServer()
         * performs the Pterodactyl deletion and
         * local resource/accounting cleanup.
         */
        if (
            typeof serverManager.deleteServer ===
            "function"
        ) {
            await serverManager.deleteServer(
                userId,
                server.id
            );
        } else {
            /*
             * Fallback if the service does not
             * expose deleteServer().
             */
            const pterodactylId =
                server.pterodactyl_id;

            if (
                pterodactylId &&
                typeof serverManager.delete ===
                "function"
            ) {
                await serverManager.delete(
                    userId,
                    server.id
                );
            } else {
                throw new Error(
                    "The server deletion service is unavailable."
                );
            }
        }

        const embed =
            createEmbed({
                title: "✅ Server Deleted",
                description:
                    `The server **${getServerName(server)}** has been permanently deleted.`,
                color: 0x57F287
            });

        embed.addFields({
            name: "🗑️ Deleted Server",
            value:
                `**${getServerName(server)}**\n` +
                `ID: \`${server.id}\``,
            inline: false
        });

        embed.addFields({
            name: "📦 Released Resources",
            value:
                `RAM: **${formatMemory(server.ram)}**\n` +
                `CPU: **${Number(server.cpu || 0)}%**\n` +
                `Disk: **${formatMemory(server.disk)}**`,
            inline: false
        });

        embed.setFooter({
            text:
                "HyperForgeX • Petro V2"
        });

        if (
            interaction.deferred ||
            interaction.replied
        ) {
            return interaction.editReply({
                embeds: [embed],
                components: []
            });
        }

        return interaction.reply({
            embeds: [embed],
            ephemeral: true
        });
    } catch (error) {
        console.error(
            "[DeleteServer] Deletion failed:",
            error
        );

        const response = {
            embeds: [
                errorEmbed(
                    "Server Deletion Failed",
                    error?.message ||
                    "The server could not be deleted. Please try again."
                )
            ],
            components: []
        };

        if (
            interaction.deferred ||
            interaction.replied
        ) {
            return interaction.editReply(
                response
            );
        }

        return interaction.reply({
            ...response,
            ephemeral: true
        });
    }
}

/* ============================================================
 * SLASH COMMAND
 * ============================================================
 */

export async function execute(
    interaction
) {
    const target =
        interaction.options.getString(
            "server",
            true
        );

    try {
        const response =
            await showDeleteConfirmation(
                target,
                interaction.user
            );

        return interaction.reply({
            ...response,
            ephemeral: true
        });
    } catch (error) {
        console.error(
            "[DeleteServer] Slash command failed:",
            error
        );

        return interaction.reply({
            embeds: [
                errorEmbed(
                    "Delete Server Error",
                    error?.message ||
                    "Unable to prepare the server for deletion."
                )
            ],
            ephemeral: true
        });
    }
}

/* ============================================================
 * PREFIX COMMAND
 *
 * Usage:
 * !deleteserver <server-id>
 * !deleteserver <identifier>
 * ============================================================
 */

export async function prefixExecute(
    message,
    args = []
) {
    const target =
        args[0];

    if (!target) {
        return message.reply({
            embeds: [
                errorEmbed(
                    "Missing Server ID",
                    "Please specify the server you want to delete.\n\n" +
                    "**Usage:** `!deleteserver <server-id>`\n\n" +
                    "**Example:** `!deleteserver 12`"
                )
            ]
        });
    }

    try {
        const response =
            await showDeleteConfirmation(
                target,
                message.author
            );

        return message.reply(
            response
        );
    } catch (error) {
        console.error(
            "[DeleteServer] Prefix command failed:",
            error
        );

        return message.reply({
            embeds: [
                errorEmbed(
                    "Delete Server Error",
                    error?.message ||
                    "Unable to prepare the server for deletion."
                )
            ]
        });
    }
}

/* ============================================================
 * CONFIRMATION BUTTON HANDLER
 * ============================================================
 *
 * Expected custom IDs:
 *
 * delete_server_confirm:<discordUserId>:<serverId>
 * delete_server_cancel:<discordUserId>:<serverId>
 *
 * This handler is exported so index.js can route the
 * button interaction.
 * ============================================================
 */

export async function handleDeleteServerButton(
    interaction
) {
    const customId =
        interaction.customId;

    if (
        !customId.startsWith(
            "delete_server_"
        )
    ) {
        return false;
    }

    const parts =
        customId.split(":");

    const action =
        parts[0];

    const ownerId =
        parts[1];

    const serverId =
        parts[2];

    if (
        !ownerId ||
        !serverId
    ) {
        return false;
    }

    /*
     * Only the person who opened the
     * confirmation may use the buttons.
     */
    if (
        interaction.user.id !==
        ownerId
    ) {
        return interaction.reply({
            embeds: [
                errorEmbed(
                    "Not Your Confirmation",
                    "Only the user who requested this deletion can use these buttons."
                )
            ],
            ephemeral: true
        });
    }

    if (
        action ===
        "delete_server_cancel"
    ) {
        const embed =
            createEmbed({
                title: "❌ Deletion Cancelled",
                description:
                    "The server was **not deleted**.",
                color: 0x95A5A6
            });

        embed.setFooter({
            text:
                "HyperForgeX • Petro V2"
        });

        return interaction.update({
            embeds: [embed],
            components: []
        });
    }

    if (
        action ===
        "delete_server_confirm"
    ) {
        await interaction.update({
            embeds: [
                createEmbed({
                    title: "⏳ Deleting Server",
                    description:
                        "Please wait while Petro removes the server from Pterodactyl and updates your resource balance.",
                    color: 0xFEE75C
                })
            ],
            components: []
        });

        return deleteServer(
            interaction,
            serverId,
            ownerId
        );
    }

    return false;
}

/* ============================================================
 * DEFAULT EXPORT
 * ============================================================
 */

export default {
    name,
    description,
    aliases,
    data,
    execute,
    prefixExecute,
    handleDeleteServerButton
};

/*
 * ============================================================
 * End of deleteserver.js
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * PetroBot V2 - Delete Server Command
 * ============================================================
 */