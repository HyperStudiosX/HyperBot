/*
 * ============================================================
 * PetroBot V2 - Create Redeem Code Command
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */

import { randomBytes } from "node:crypto";

import database from "../database.js";
import { isAdmin } from "../utils/permissions.js";
import { createEmbed, errorEmbed } from "../utils/embeds.js";

export const name = "createcode";
export const description = "Create coin or resource redeem codes.";

export const aliases = [
    "create-code",
    "codecreate",
    "newcode"
];

export const data = {
    name: "createcode",
    description: "Create a coin or resource redeem code.",
    options: [
        {
            name: "type",
            description: "The type of redeem code.",
            type: 3,
            required: true,
            choices: [
                {
                    name: "Coins",
                    value: "coins"
                },
                {
                    name: "Resources",
                    value: "resource"
                }
            ]
        },
        {
            name: "value",
            description: "Coin amount or RAM in GB.",
            type: 10,
            required: true
        },
        {
            name: "cpu_or_cpu_percent",
            description: "CPU percentage for a resource code.",
            type: 10,
            required: false
        },
        {
            name: "disk_gb",
            description: "Disk in GB for a resource code.",
            type: 10,
            required: false
        },
        {
            name: "max_uses",
            description: "Maximum number of times the code can be redeemed.",
            type: 4,
            required: false
        }
    ]
};

/*
 * ============================================================
 * CONSTANTS
 * ============================================================
 */

const CODE_PREFIX = "PETRO";

const DEFAULT_MAX_USES = 1;

const MAX_CODE_GENERATION_ATTEMPTS = 10;

/*
 * ============================================================
 * HELPERS
 * ============================================================
 */

/**
 * Safely convert a value to a finite number.
 *
 * @param {*} value
 * @param {number} fallback
 * @returns {number}
 */
function toNumber(value, fallback = 0) {
    const number = Number(value);

    return Number.isFinite(number)
        ? number
        : fallback;
}

/**
 * Format numbers for Discord.
 *
 * @param {*} value
 * @returns {string}
 */
function formatNumber(value) {
    return toNumber(value).toLocaleString("en-US");
}

/**
 * Normalize a code type.
 *
 * @param {*} value
 * @returns {string}
 */
function normalizeType(value) {
    return String(value ?? "")
        .trim()
        .toLowerCase();
}

/**
 * Generate a secure redeem code.
 *
 * Example:
 * PETRO-COIN-8F3A7C91D2
 *
 * @param {"coins"|"resource"} type
 * @returns {string}
 */
function generateCode(type) {
    const suffix = randomBytes(8)
        .toString("hex")
        .toUpperCase();

    const prefix =
        type === "resource"
            ? "RES"
            : "COIN";

    return `${CODE_PREFIX}-${prefix}-${suffix}`;
}

/**
 * Create a code while handling the very unlikely possibility
 * of a database uniqueness collision.
 *
 * @param {object} data
 * @returns {object}
 */
function createUniqueCode(data) {
    let lastError = null;

    for (
        let attempt = 0;
        attempt < MAX_CODE_GENERATION_ATTEMPTS;
        attempt++
    ) {
        const code = generateCode(data.type);

        try {
            return database.createRedeemCode({
                ...data,
                code
            });
        } catch (error) {
            lastError = error;

            const message = String(
                error?.message ?? error
            ).toLowerCase();

            const looksLikeDuplicate =
                message.includes("unique") ||
                message.includes("duplicate") ||
                message.includes("constraint");

            if (!looksLikeDuplicate) {
                throw error;
            }
        }
    }

    throw (
        lastError ??
        new Error(
            "Unable to generate a unique redeem code."
        )
    );
}

/**
 * Validate maximum uses.
 *
 * @param {*} value
 * @returns {{valid:boolean,value:number,error?:string}}
 */
function validateMaxUses(value) {
    if (
        value === undefined ||
        value === null ||
        value === ""
    ) {
        return {
            valid: true,
            value: DEFAULT_MAX_USES
        };
    }

    const maxUses = Number(value);

    if (
        !Number.isInteger(maxUses) ||
        maxUses <= 0
    ) {
        return {
            valid: false,
            value: 0,
            error:
                "Max uses must be a positive whole number."
        };
    }

    return {
        valid: true,
        value: maxUses
    };
}

/**
 * Convert GB to MB.
 *
 * @param {*} value
 * @returns {number}
 */
function gbToMb(value) {
    return Math.floor(
        toNumber(value) * 1024
    );
}

/**
 * Check whether the user is an administrator.
 *
 * @param {object} message
 * @returns {boolean}
 */
function checkAdmin(message) {
    const userId = String(
        message?.author?.id ?? ""
    ).trim();

    if (!userId) {
        return false;
    }

    return isAdmin(userId);
}

/**
 * Check administrator status for a slash interaction.
 *
 * @param {object} interaction
 * @returns {boolean}
 */
function checkSlashAdmin(interaction) {
    const userId = String(
        interaction?.user?.id ?? ""
    ).trim();

    if (!userId) {
        return false;
    }

    return isAdmin(userId);
}

/*
 * ============================================================
 * EMBEDS
 * ============================================================
 */

/**
 * Build the coin-code success embed.
 *
 * @param {object} record
 * @param {number} amount
 * @param {number} maxUses
 * @returns {object}
 */
function buildCoinEmbed(
    record,
    amount,
    maxUses
) {
    const embed = createEmbed({
        title: "🎟️ Coin Redeem Code Created",
        description:
            "A new coin redeem code has been created successfully.",
        color: 0x57F287
    });

    embed.addFields(
        {
            name: "🔑 Redeem Code",
            value: `\`${record.code}\``,
            inline: false
        },
        {
            name: "💰 Coin Value",
            value:
                `**${formatNumber(amount)} coins**`,
            inline: true
        },
        {
            name: "🔄 Maximum Uses",
            value:
                `**${formatNumber(maxUses)}**`,
            inline: true
        },
        {
            name: "🎁 Reward",
            value:
                "When redeemed, this code adds the configured coins to the user's balance.",
            inline: false
        },
        {
            name: "📖 Usage",
            value:
                `\`!redeem ${record.code}\``,
            inline: false
        }
    );

    embed.setFooter({
        text: "HyperForgeX • Petro V2"
    });

    return embed;
}

/**
 * Build the resource-code success embed.
 *
 * @param {object} record
 * @param {number} ramGB
 * @param {number} cpu
 * @param {number} diskGB
 * @param {number} maxUses
 * @returns {object}
 */
function buildResourceEmbed(
    record,
    ramGB,
    cpu,
    diskGB,
    maxUses
) {
    const embed = createEmbed({
        title: "🎟️ Resource Redeem Code Created",
        description:
            "A new resource redeem code has been created successfully.",
        color: 0x57F287
    });

    embed.addFields(
        {
            name: "🔑 Redeem Code",
            value: `\`${record.code}\``,
            inline: false
        },
        {
            name: "🧠 RAM",
            value:
                `**+${formatNumber(ramGB)} GB**`,
            inline: true
        },
        {
            name: "⚙️ CPU",
            value:
                `**+${formatNumber(cpu)}%**`,
            inline: true
        },
        {
            name: "💾 Disk",
            value:
                `**+${formatNumber(diskGB)} GB**`,
            inline: true
        },
        {
            name: "🔄 Maximum Uses",
            value:
                `**${formatNumber(maxUses)}**`,
            inline: true
        },
        {
            name: "📦 Included Resources",
            value:
                "This resource code grants RAM, CPU and disk only.\n" +
                "Allocations, databases, backups and server slots are not included.",
            inline: false
        },
        {
            name: "📖 Usage",
            value:
                `\`!redeem ${record.code}\``,
            inline: false
        }
    );

    embed.setFooter({
        text: "HyperForgeX • Petro V2"
    });

    return embed;
}

/*
 * ============================================================
 * PREFIX HELP
 * ============================================================
 */

function buildUsageMessage() {
    return (
        "❌ **Invalid Usage**\n\n" +
        "**Coin Code**\n" +
        "`!createcode coins <amount> [maxUses]`\n\n" +
        "**Resource Code**\n" +
        "`!createcode resource <RAM_GB> <CPU_%> <DISK_GB> [maxUses]`\n\n" +
        "**Examples**\n" +
        "`!createcode coins 1000`\n" +
        "`!createcode coins 1000 5`\n" +
        "`!createcode resource 2 100 5`\n" +
        "`!createcode resource 2 100 5 1`"
    );
}

/*
 * ============================================================
 * COIN CODE CREATION
 * ============================================================
 */

/**
 * Create a coin redeem code.
 *
 * @param {string} creatorId
 * @param {number} amount
 * @param {number} maxUses
 * @returns {object}
 */
function createCoinCode(
    creatorId,
    amount,
    maxUses
) {
    if (
        !Number.isInteger(amount) ||
        amount <= 0
    ) {
        throw new Error(
            "Coin amount must be a positive whole number."
        );
    }

    return createUniqueCode({
        type: "coins",
        amount,
        maxUses,
        createdBy: creatorId
    });
}

/*
 * ============================================================
 * RESOURCE CODE CREATION
 * ============================================================
 */

/**
 * Create a resource redeem code.
 *
 * @param {string} creatorId
 * @param {number} ramGB
 * @param {number} cpu
 * @param {number} diskGB
 * @param {number} maxUses
 * @returns {object}
 */
function createResourceCode(
    creatorId,
    ramGB,
    cpu,
    diskGB,
    maxUses
) {
    if (
        !Number.isFinite(ramGB) ||
        ramGB <= 0
    ) {
        throw new Error(
            "RAM must be greater than 0 GB."
        );
    }

    if (
        !Number.isFinite(cpu) ||
        cpu <= 0
    ) {
        throw new Error(
            "CPU must be greater than 0%."
        );
    }

    if (
        !Number.isFinite(diskGB) ||
        diskGB <= 0
    ) {
        throw new Error(
            "Disk must be greater than 0 GB."
        );
    }

    const ramMb = gbToMb(ramGB);
    const diskMb = gbToMb(diskGB);

    if (ramMb <= 0) {
        throw new Error(
            "RAM amount is too small."
        );
    }

    if (diskMb <= 0) {
        throw new Error(
            "Disk amount is too small."
        );
    }

    return createUniqueCode({
        type: "resource",
        amount: 0,
        ram: ramMb,
        cpu: Math.floor(cpu),
        disk: diskMb,
        backups: 0,
        allocations: 0,
        databases: 0,
        server_slots: 0,
        maxUses,
        createdBy: creatorId
    });
}

/*
 * ============================================================
 * PREFIX COMMAND
 * ============================================================
 */

/**
 * Execute !createcode.
 *
 * Supported:
 *
 * !createcode coins <amount> [maxUses]
 * !createcode resource <ramGB> <cpu> <diskGB> [maxUses]
 *
 * @param {import("discord.js").Message} message
 * @param {string[]} args
 */
export async function execute(
    message,
    args = []
) {
    if (!checkAdmin(message)) {
        return message.reply({
            embeds: [
                errorEmbed(
                    "Permission Denied",
                    "You do not have permission to create redeem codes."
                )
            ]
        });
    }

    const type = normalizeType(
        args[0]
    );

    if (
        type !== "coins" &&
        type !== "resource"
    ) {
        return message.reply({
            content: buildUsageMessage()
        });
    }

    const creatorId = String(
        message.author.id
    );

    /*
     * --------------------------------------------------------
     * COINS
     * --------------------------------------------------------
     */

    if (type === "coins") {
        const amount = Number(
            args[1]
        );

        const maxUsesResult =
            validateMaxUses(args[2]);

        if (
            !Number.isInteger(amount) ||
            amount <= 0
        ) {
            return message.reply({
                content:
                    "❌ Coin amount must be a positive whole number."
            });
        }

        if (!maxUsesResult.valid) {
            return message.reply({
                content:
                    `❌ ${maxUsesResult.error}`
            });
        }

        try {
            const record =
                createCoinCode(
                    creatorId,
                    amount,
                    maxUsesResult.value
                );

            return message.reply({
                embeds: [
                    buildCoinEmbed(
                        record,
                        amount,
                        maxUsesResult.value
                    )
                ]
            });
        } catch (error) {
            console.error(
                "[CreateCode] Coin code creation failed:",
                error
            );

            return message.reply({
                embeds: [
                    errorEmbed(
                        "Code Creation Failed",
                        "The coin redeem code could not be created."
                    )
                ]
            });
        }
    }

    /*
     * --------------------------------------------------------
     * RESOURCES
     * --------------------------------------------------------
     */

    const ramGB = Number(
        args[1]
    );

    const cpu = Number(
        args[2]
    );

    const diskGB = Number(
        args[3]
    );

    const maxUsesResult =
        validateMaxUses(args[4]);

    if (
        !Number.isFinite(ramGB) ||
        ramGB <= 0
    ) {
        return message.reply({
            content:
                "❌ RAM must be greater than `0` GB."
        });
    }

    if (
        !Number.isFinite(cpu) ||
        cpu <= 0
    ) {
        return message.reply({
            content:
                "❌ CPU must be greater than `0`%."
        });
    }

    if (
        !Number.isFinite(diskGB) ||
        diskGB <= 0
    ) {
        return message.reply({
            content:
                "❌ Disk must be greater than `0` GB."
        });
    }

    if (!maxUsesResult.valid) {
        return message.reply({
            content:
                `❌ ${maxUsesResult.error}`
        });
    }

    try {
        const record =
            createResourceCode(
                creatorId,
                ramGB,
                cpu,
                diskGB,
                maxUsesResult.value
            );

        return message.reply({
            embeds: [
                buildResourceEmbed(
                    record,
                    ramGB,
                    Math.floor(cpu),
                    diskGB,
                    maxUsesResult.value
                )
            ]
        });
    } catch (error) {
        console.error(
            "[CreateCode] Resource code creation failed:",
            error
        );

        return message.reply({
            embeds: [
                errorEmbed(
                    "Code Creation Failed",
                    "The resource redeem code could not be created."
                )
            ]
        });
    }
}

/*
 * ============================================================
 * PREFIX COMPATIBILITY
 * ============================================================
 */

export async function prefixExecute(
    message,
    args = []
) {
    return execute(
        message,
        args
    );
}

/*
 * ============================================================
 * SLASH COMMAND
 * ============================================================
 */

/**
 * Execute /createcode.
 *
 * @param {import("discord.js").ChatInputCommandInteraction} interaction
 */
export async function executeSlash(
    interaction
) {
    if (!checkSlashAdmin(interaction)) {
        return interaction.reply({
            embeds: [
                errorEmbed(
                    "Permission Denied",
                    "You do not have permission to create redeem codes."
                )
            ],
            ephemeral: true
        });
    }

    const type = normalizeType(
        interaction.options.getString(
            "type"
        )
    );

    const value =
        interaction.options.getNumber(
            "value"
        );

    const cpu =
        interaction.options.getNumber(
            "cpu_or_cpu_percent"
        );

    const diskGB =
        interaction.options.getNumber(
            "disk_gb"
        );

    const maxUses =
        interaction.options.getInteger(
            "max_uses"
        );

    const maxUsesResult =
        validateMaxUses(maxUses);

    if (
        type !== "coins" &&
        type !== "resource"
    ) {
        return interaction.reply({
            content:
                "❌ Invalid code type.",
            ephemeral: true
        });
    }

    if (!maxUsesResult.valid) {
        return interaction.reply({
            content:
                `❌ ${maxUsesResult.error}`,
            ephemeral: true
        });
    }

    const creatorId = String(
        interaction.user.id
    );

    /*
     * --------------------------------------------------------
     * COIN CODE
     * --------------------------------------------------------
     */

    if (type === "coins") {
        if (
            !Number.isInteger(value) ||
            value <= 0
        ) {
            return interaction.reply({
                content:
                    "❌ Coin value must be a positive whole number.",
                ephemeral: true
            });
        }

        try {
            const record =
                createCoinCode(
                    creatorId,
                    value,
                    maxUsesResult.value
                );

            return interaction.reply({
                embeds: [
                    buildCoinEmbed(
                        record,
                        value,
                        maxUsesResult.value
                    )
                ]
            });
        } catch (error) {
            console.error(
                "[CreateCode] Slash coin creation failed:",
                error
            );

            return interaction.reply({
                embeds: [
                    errorEmbed(
                        "Code Creation Failed",
                        "The coin redeem code could not be created."
                    )
                ],
                ephemeral: true
            });
        }
    }

    /*
     * --------------------------------------------------------
     * RESOURCE CODE
     * --------------------------------------------------------
     */

    if (
        !Number.isFinite(value) ||
        value <= 0
    ) {
        return interaction.reply({
            content:
                "❌ RAM must be greater than `0` GB.",
            ephemeral: true
        });
    }

    if (
        !Number.isFinite(cpu) ||
        cpu <= 0
    ) {
        return interaction.reply({
            content:
                "❌ CPU must be greater than `0`%.",
            ephemeral: true
        });
    }

    if (
        !Number.isFinite(diskGB) ||
        diskGB <= 0
    ) {
        return interaction.reply({
            content:
                "❌ Disk must be greater than `0` GB.",
            ephemeral: true
        });
    }

    try {
        const record =
            createResourceCode(
                creatorId,
                value,
                cpu,
                diskGB,
                maxUsesResult.value
            );

        return interaction.reply({
            embeds: [
                buildResourceEmbed(
                    record,
                    value,
                    Math.floor(cpu),
                    diskGB,
                    maxUsesResult.value
                )
            ]
        });
    } catch (error) {
        console.error(
            "[CreateCode] Slash resource creation failed:",
            error
        );

        return interaction.reply({
            embeds: [
                errorEmbed(
                    "Code Creation Failed",
                    "The resource redeem code could not be created."
                )
            ],
            ephemeral: true
        });
    }
}

/*
 * ============================================================
 * DEFAULT EXPORT
 * ============================================================
 */

const createCodeCommand = {
    name,
    description,
    aliases,
    data,
    execute,
    prefixExecute,
    executeSlash
};

export default createCodeCommand;

/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */