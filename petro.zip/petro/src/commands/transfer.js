/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */

import { SlashCommandBuilder } from "discord.js";
import { transferCoins } from "../services/economy.js";
import { successEmbed, errorEmbed } from "../utils/embeds.js";

export const data = new SlashCommandBuilder()
    .setName("transfer")
    .setDescription("Transfer coins to another user.")
    .addUserOption(option =>
        option
            .setName("user")
            .setDescription("The user who will receive the coins.")
            .setRequired(true)
    )
    .addIntegerOption(option =>
        option
            .setName("amount")
            .setDescription("The number of coins to transfer.")
            .setMinValue(1)
            .setRequired(true)
    )
    .setDMPermission(true);

export async function execute(interaction) {
    try {
        const recipient = interaction.options.getUser("user", true);
        const amount = interaction.options.getInteger("amount", true);

        if (recipient.bot) {
            return interaction.reply({
                embeds: [
                    errorEmbed(
                        "Invalid Recipient",
                        "You cannot transfer coins to a bot."
                    )
                ],
                ephemeral: true
            });
        }

        if (recipient.id === interaction.user.id) {
            return interaction.reply({
                embeds: [
                    errorEmbed(
                        "Invalid Recipient",
                        "You cannot transfer coins to yourself."
                    )
                ],
                ephemeral: true
            });
        }

        const result = transferCoins(
            interaction.user.id,
            recipient.id,
            amount
        );

        if (!result?.success) {
            return interaction.reply({
                embeds: [
                    errorEmbed(
                        "Transfer Failed",
                        result?.message || "You do not have enough coins for this transfer."
                    )
                ],
                ephemeral: true
            });
        }

        return interaction.reply({
            embeds: [
                successEmbed(
                    "Coins Transferred",
                    `Successfully transferred **${amount.toLocaleString()} coins** to ${recipient}.\n\n` +
                    `**Recipient:** ${recipient.tag}\n` +
                    `**Amount:** \`${amount.toLocaleString()}\` coins`
                )
            ],
            ephemeral: true
        });
    } catch (error) {
        console.error("[Transfer]", error);

        return interaction.reply({
            embeds: [
                errorEmbed(
                    "Transfer Error",
                    error?.message || "An unexpected error occurred while transferring coins."
                )
            ],
            ephemeral: true
        });
    }
}

export default {
    data,
    execute
};

/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */