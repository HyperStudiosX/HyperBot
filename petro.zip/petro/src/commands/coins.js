/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */

import { SlashCommandBuilder } from "discord.js";
import { getBalanceInfo } from "../services/economy.js";
import { balanceEmbed, errorEmbed } from "../utils/embeds.js";
import { economyButtons } from "../utils/components.js";

export const data = new SlashCommandBuilder()
    .setName("coins")
    .setDescription("View your coin balance and economy options.")
    .setDMPermission(true);

export async function execute(interaction) {
    try {
        const balance = getBalanceInfo(interaction.user.id);

        return interaction.reply({
            embeds: [
                balanceEmbed(
                    interaction.user,
                    balance
                )
            ],
            components: economyButtons(),
            ephemeral: true
        });
    } catch (error) {
        console.error("[Coins]", error);

        return interaction.reply({
            embeds: [
                errorEmbed(
                    "Economy Error",
                    error?.message || "Unable to load your coin balance."
                )
            ],
            ephemeral: true
        });
    }
}

export default {
    data,
    execute
};

/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */