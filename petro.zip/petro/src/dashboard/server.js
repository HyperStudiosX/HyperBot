/*
 * ============================================================
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */

import express from "express";
import session from "express-session";
import path from "node:path";
import { fileURLToPath } from "node:url";

import config from "../config.js";
import database from "../database.js";
import serverManager from "../services/serverManager.js";
import { getAllPlans } from "../plans.js";
import { isBotAdmin } from "../utils/permissions.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const publicDirectory = __dirname.replace(
    `${path.sep}dashboard`,
    ""
);

const app = express();

app.disable("x-powered-by");

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(
    session({
        secret: config.DASHBOARD_SESSION_SECRET,
        resave: false,
        saveUninitialized: false,
        cookie: {
            httpOnly: true,
            sameSite: "lax",
            secure: String(config.DASHBOARD_URL || "")
                .startsWith("https://"),
            maxAge: 1000 * 60 * 60 * 24 * 7
        }
    })
);

/*
 * ============================================================
 * HELPERS
 * ============================================================
 */

function requireLogin(req, res, next) {
    if (!req.session.user) {
        return res.status(401).json({
            error: "AUTH_REQUIRED"
        });
    }

    next();
}

function getUserId(req) {
    return String(
        req.session.user?.id || ""
    );
}

function getOwnedServer(req, serverId) {
    return serverManager.requireServerOwner(
        getUserId(req),
        serverId
    );
}

function sendError(res, error) {
    console.error(
        "[Dashboard]",
        error
    );

    const status =
        error?.code === "SERVER_NOT_FOUND" ||
        error?.code === "SERVER_NOT_OWNED"
            ? 404
            : 500;

    return res.status(status).json({
        error:
            error?.message ||
            "An unexpected error occurred."
    });
}

/*
 * ============================================================
 * DISCORD OAUTH
 * ============================================================
 */

app.get("/auth/login", (req, res) => {
    if (
        !config.DISCORD_CLIENT_ID ||
        !config.DISCORD_CLIENT_SECRET
    ) {
        return res.status(500).send(
            "Discord OAuth is not configured."
        );
    }

    const params = new URLSearchParams({
        client_id: config.DISCORD_CLIENT_ID,
        redirect_uri: config.DISCORD_REDIRECT_URI,
        response_type: "code",
        scope: "identify"
    });

    res.redirect(
        `https://discord.com/oauth2/authorize?${params}`
    );
});

app.get("/auth/callback", async (req, res) => {
    try {
        const code =
            String(req.query.code || "");

        if (!code) {
            return res.status(400).send(
                "Missing OAuth authorization code."
            );
        }

        const tokenResponse =
            await fetch(
                "https://discord.com/api/oauth2/token",
                {
                    method: "POST",
                    headers: {
                        "Content-Type":
                            "application/x-www-form-urlencoded"
                    },
                    body:
                        new URLSearchParams({
                            client_id:
                                config.DISCORD_CLIENT_ID,
                            client_secret:
                                config.DISCORD_CLIENT_SECRET,
                            grant_type:
                                "authorization_code",
                            code,
                            redirect_uri:
                                config.DISCORD_REDIRECT_URI
                        })
                }
            );

        if (!tokenResponse.ok) {
            throw new Error(
                "Discord OAuth token exchange failed."
            );
        }

        const tokenData =
            await tokenResponse.json();

        const userResponse =
            await fetch(
                "https://discord.com/api/users/@me",
                {
                    headers: {
                        Authorization:
                            `Bearer ${tokenData.access_token}`
                    }
                }
            );

        if (!userResponse.ok) {
            throw new Error(
                "Discord user information could not be retrieved."
            );
        }

        const discordUser =
            await userResponse.json();

        database.createUser(
            discordUser.id,
            discordUser.username
        );

        req.session.user = {
            id: discordUser.id,
            username: discordUser.username,
            globalName:
                discordUser.global_name || null,
            avatar:
                discordUser.avatar || null,
            discriminator:
                discordUser.discriminator || null
        };

        res.redirect("/");

    } catch (error) {
        console.error(
            "[Dashboard OAuth]",
            error
        );

        res.status(500).send(
            "Dashboard login failed."
        );
    }
});

app.get("/auth/logout", (req, res) => {
    req.session.destroy(
        () => res.redirect("/")
    );
});

/*
 * ============================================================
 * AUTH API
 * ============================================================
 */

app.get("/api/auth/me", (req, res) => {
    if (!req.session.user) {
        return res.json({
            authenticated: false
        });
    }

    res.json({
        authenticated: true,
        user: req.session.user,
        admin: isBotAdmin(
            req.session.user.id
        )
    });
});

/*
 * ============================================================
 * DASHBOARD API
 * ============================================================
 */

app.get(
    "/api/dashboard",
    requireLogin,
    (req, res) => {
        try {
            const discordId =
                getUserId(req);

            const stats =
                database.getUserStats(
                    discordId
                );

            const transactions =
                database.getTransactions(
                    discordId,
                    10
                );

            const servers =
                database.getUserServers(
                    discordId
                );

            const resources =
                database.getUserResources(
                    discordId
                );

            res.json({
                user: req.session.user,
                stats,
                resources,
                transactions,
                servers,
                plans: getAllPlans()
            });

        } catch (error) {
            sendError(res, error);
        }
    }
);

/*
 * ============================================================
 * SERVER LIST
 * ============================================================
 */

app.get(
    "/api/servers",
    requireLogin,
    (req, res) => {
        try {
            const servers =
                database.getUserServers(
                    getUserId(req)
                );

            res.json({
                servers
            });

        } catch (error) {
            sendError(res, error);
        }
    }
);

/*
 * ============================================================
 * SERVER DETAILS
 * ============================================================
 */

app.get(
    "/api/servers/:id",
    requireLogin,
    async (req, res) => {
        try {
            const server =
                getOwnedServer(
                    req,
                    req.params.id
                );

            let live = null;

            try {
                live =
                    await serverManager
                        .getServerStatus(
                            server
                        );
            } catch {}

            res.json({
                server,
                live
            });

        } catch (error) {
            sendError(res, error);
        }
    }
);

/*
 * ============================================================
 * SERVER STATUS
 * ============================================================
 */

app.get(
    "/api/servers/:id/status",
    requireLogin,
    async (req, res) => {
        try {
            const server =
                getOwnedServer(
                    req,
                    req.params.id
                );

            const status =
                await serverManager
                    .getServerStatus(
                        server
                    );

            res.json({
                status
            });

        } catch (error) {
            sendError(res, error);
        }
    }
);

/*
 * ============================================================
 * SERVER POWER
 * ============================================================
 */

app.post(
    "/api/servers/:id/power",
    requireLogin,
    async (req, res) => {
        try {
            const action =
                String(
                    req.body?.action || ""
                ).toLowerCase();

            if (
                ![
                    "start",
                    "stop",
                    "restart",
                    "kill"
                ].includes(action)
            ) {
                return res.status(400).json({
                    error:
                        "Invalid power action."
                });
            }

            const server =
                getOwnedServer(
                    req,
                    req.params.id
                );

            await serverManager.powerServer(
                server,
                action
            );

            res.json({
                success: true,
                action
            });

        } catch (error) {
            sendError(res, error);
        }
    }
);

/*
 * ============================================================
 * SERVER RENAME
 * ============================================================
 */

app.patch(
    "/api/servers/:id",
    requireLogin,
    async (req, res) => {
        try {
            const name =
                String(
                    req.body?.name || ""
                ).trim();

            if (!name) {
                return res.status(400).json({
                    error:
                        "Server name cannot be empty."
                });
            }

            if (name.length > 191) {
                return res.status(400).json({
                    error:
                        "Server name is too long."
                });
            }

            const server =
                getOwnedServer(
                    req,
                    req.params.id
                );

            const updated =
                await serverManager.renameServer(
                    getUserId(req),
                    server.id,
                    name
                );

            res.json({
                success: true,
                server:
                    updated ||
                    database.getServerById(
                        server.id
                    )
            });

        } catch (error) {
            sendError(res, error);
        }
    }
);

/*
 * ============================================================
 * SERVER DELETE
 * ============================================================
 */

app.delete(
    "/api/servers/:id",
    requireLogin,
    async (req, res) => {
        try {
            const server =
                getOwnedServer(
                    req,
                    req.params.id
                );

            const result =
                await serverManager.deleteServer(
                    getUserId(req),
                    server.id
                );

            res.json({
                success: true,
                refunded:
                    result.refunded || null
            });

        } catch (error) {
            sendError(res, error);
        }
    }
);

/*
 * ============================================================
 * RESOURCES
 * ============================================================
 */

app.get(
    "/api/resources",
    requireLogin,
    (req, res) => {
        try {
            const resources =
                database.getUserResources(
                    getUserId(req)
                );

            res.json({
                resources
            });

        } catch (error) {
            sendError(res, error);
        }
    }
);

/*
 * ============================================================
 * ECONOMY
 * ============================================================
 */

app.get(
    "/api/economy",
    requireLogin,
    (req, res) => {
        try {
            const balance =
                database.getCoins(
                    getUserId(req)
                );

            const transactions =
                database.getTransactions(
                    getUserId(req),
                    50
                );

            res.json({
                balance,
                transactions
            });

        } catch (error) {
            sendError(res, error);
        }
    }
);

/*
 * ============================================================
 * PLANS
 * ============================================================
 */

app.get(
    "/api/plans",
    (req, res) => {
        res.json({
            plans: getAllPlans()
        });
    }
);

/*
 * ============================================================
 * ADMIN
 * ============================================================
 */

app.get(
    "/api/admin",
    requireLogin,
    (req, res) => {
        try {
            if (
                !isBotAdmin(
                    getUserId(req)
                )
            ) {
                return res.status(403).json({
                    error: "FORBIDDEN"
                });
            }

            const users =
                database.db.prepare(
                    "SELECT COUNT(*) AS count FROM users"
                ).get()?.count || 0;

            const servers =
                database.db.prepare(
                    "SELECT COUNT(*) AS count FROM servers"
                ).get()?.count || 0;

            const transactions =
                database.db.prepare(
                    "SELECT COUNT(*) AS count FROM transactions"
                ).get()?.count || 0;

            res.json({
                users,
                servers,
                transactions
            });

        } catch (error) {
            sendError(res, error);
        }
    }
);

/*
 * ============================================================
 * STATIC FRONTEND
 * ============================================================
 */

app.use(
    express.static(publicDirectory)
);

app.get(
    "*splat",
    (req, res) => {
        res.sendFile(
            path.join(
                publicDirectory,
                "index.html"
            )
        );
    }
);

/*
 * ============================================================
 * START DASHBOARD
 * ============================================================
 */

let dashboardServer = null;

export function startDashboard() {
    if (!config.DASHBOARD_ENABLED) {
        console.log(
            "[Dashboard] Disabled."
        );

        return null;
    }

    if (dashboardServer) {
        return dashboardServer;
    }

    dashboardServer =
        app.listen(
            config.DASHBOARD_PORT,
            config.DASHBOARD_HOST,
            () => {
                console.log("");
                console.log(
                    "========================================"
                );
                console.log(
                    "🌐 PetroV2 Dashboard"
                );
                console.log(
                    `📡 ${config.DASHBOARD_URL}`
                );
                console.log(
                    `🔌 Port: ${config.DASHBOARD_PORT}`
                );
                console.log(
                    "========================================"
                );
                console.log("");
            }
        );

    return dashboardServer;
}

export {
    app
};

export default {
    app,
    startDashboard
};

/*
 * ============================================================
 * End of server.js
 * Created by HyperForgeX
 * Copyright © 2026 HyperForgeX. All rights reserved.
 * ============================================================
 */