<!--
============================================================
Created by HyperForgeX
Copyright © 2026 HyperForgeX. All rights reserved.
============================================================
-->
# Pterodactyl Deployer V2

Discord bot for managing Pterodactyl servers with a coin economy and resource-based deployment.

## Setup
1. Use Node.js 22.5+.
2. Run `npm install`.
3. Copy `.env.example` to `.env` and fill in the Discord/Pterodactyl values.
4. Run `npm run register` to register slash commands.
5. Run `npm start`.

## Resource flow
- `!createcode coins <amount> [maxUses]`
- `!createcode resource <ramGB> <cpuPercent> <diskGB> [maxUses]`
- `!redeem <code>`
- `!resources`
- `!plans`
- `!buy <planid>`
- `!deploy <RAM_MB> <CPU_%> <DISK_MB> [server name]`

Purchased plans add resources to the user's resource balance. Deployment consumes those resources. Failed deployments refund the resources.

<!--
============================================================
Created by HyperForgeX
Copyright © 2026 HyperForgeX. All rights reserved.
============================================================
-->
