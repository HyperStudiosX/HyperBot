const {
    SlashCommandBuilder,
    PermissionFlagsBits,
    ContainerBuilder,
    TextDisplayBuilder,
    MessageFlags
} = require('discord.js');

module.exports = {
    name: 'role',
    aliases: ['roles'],
    description: 'Manage server roles',

    data: new SlashCommandBuilder()
        .setName('role')
        .setDescription('Manage server roles')

        .addSubcommand(sub =>
            sub
                .setName('create')
                .setDescription('Create a new role')
                .addStringOption(option =>
                    option
                        .setName('name')
                        .setDescription('Name of the role')
                        .setRequired(true)
                )
        )

        .addSubcommand(sub =>
            sub
                .setName('delete')
                .setDescription('Delete a role')
                .addRoleOption(option =>
                    option
                        .setName('role')
                        .setDescription('Role to delete')
                        .setRequired(true)
                )
        )

        .addSubcommand(sub =>
            sub
                .setName('add')
                .setDescription('Give a role to a user')
                .addUserOption(option =>
                    option
                        .setName('user')
                        .setDescription('User')
                        .setRequired(true)
                )
                .addRoleOption(option =>
                    option
                        .setName('role')
                        .setDescription('Role')
                        .setRequired(true)
                )
        )

        .addSubcommand(sub =>
            sub
                .setName('give')
                .setDescription('Give a role to a user')
                .addUserOption(option =>
                    option
                        .setName('user')
                        .setDescription('User')
                        .setRequired(true)
                )
                .addRoleOption(option =>
                    option
                        .setName('role')
                        .setDescription('Role')
                        .setRequired(true)
                )
        )

        .addSubcommand(sub =>
            sub
                .setName('remove')
                .setDescription('Remove a role from a user')
                .addUserOption(option =>
                    option
                        .setName('user')
                        .setDescription('User')
                        .setRequired(true)
                )
                .addRoleOption(option =>
                    option
                        .setName('role')
                        .setDescription('Role')
                        .setRequired(true)
                )
        )

        .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),

    async execute(interactionOrMessage, args = []) {
        const isSlash = interactionOrMessage.isChatInputCommand?.();
        const guild = interactionOrMessage.guild;

        if (!guild) {
            return interactionOrMessage.reply({
                content: '❌ This command can only be used in a server.',
                ephemeral: true
            });
        }

        const member = interactionOrMessage.member;

        if (!member.permissions.has(PermissionFlagsBits.ManageRoles)) {
            return interactionOrMessage.reply({
                content: '❌ You need **Manage Roles** permission to use this command.',
                ephemeral: true
            });
        }

        let subcommand;
        let targetUser;
        let role;

        if (isSlash) {
            subcommand = interactionOrMessage.options.getSubcommand();

            if (subcommand === 'create') {
                const name = interactionOrMessage.options.getString('name');

                try {
                    const newRole = await guild.roles.create({
                        name,
                        reason: `Role created by ${interactionOrMessage.user.tag}`
                    });

                    return interactionOrMessage.reply({
                        content: `✅ Created role **${newRole.name}**.`,
                        allowedMentions: { parse: [] }
                    });
                } catch (error) {
                    console.error('Role create error:', error);

                    return interactionOrMessage.reply({
                        content: '❌ I could not create that role.',
                        ephemeral: true
                    });
                }
            }

            role = interactionOrMessage.options.getRole('role');

            if (subcommand === 'delete') {
                if (!role) {
                    return interactionOrMessage.reply({
                        content: '❌ Role not found.',
                        ephemeral: true
                    });
                }

                if (role.managed) {
                    return interactionOrMessage.reply({
                        content: '❌ I cannot delete a managed/integration role.',
                        ephemeral: true
                    });
                }

                if (role.position >= guild.members.me.roles.highest.position) {
                    return interactionOrMessage.reply({
                        content: '❌ That role is higher than or equal to my highest role.',
                        ephemeral: true
                    });
                }

                await role.delete(
                    `Role deleted by ${interactionOrMessage.user.tag}`
                );

                return interactionOrMessage.reply({
                    content: `✅ Deleted role **${role.name}**.`,
                    allowedMentions: { parse: [] }
                });
            }

            targetUser = interactionOrMessage.options.getMember('user');

            if (!targetUser) {
                return interactionOrMessage.reply({
                    content: '❌ User not found in this server.',
                    ephemeral: true
                });
            }
        } else {
            subcommand = args[0]?.toLowerCase();

            if (!subcommand) {
                return interactionOrMessage.reply({
                    content:
                        '**Role Commands**\n\n' +
                        '`.role create <name>`\n' +
                        '`.role delete <role>`\n' +
                        '`.role add <@user> <role>`\n' +
                        '`.role give <@user> <role>`\n' +
                        '`.role remove <@user> <role>`'
                });
            }

            if (subcommand === 'create') {
                const name = args.slice(1).join(' ');

                if (!name) {
                    return interactionOrMessage.reply(
                        '❌ Please provide a role name.'
                    );
                }

                try {
                    const newRole = await guild.roles.create({
                        name,
                        reason: `Role created by ${interactionOrMessage.author.tag}`
                    });

                    return interactionOrMessage.reply(
                        `✅ Created role **${newRole.name}**.`
                    );
                } catch (error) {
                    console.error('Role create error:', error);

                    return interactionOrMessage.reply(
                        '❌ I could not create that role.'
                    );
                }
            }

            const roleName = args.slice(2).join(' ');
            role = guild.roles.cache.find(
                r => r.name.toLowerCase() === roleName.toLowerCase()
            );

            if (subcommand === 'delete') {
                const deleteName = args.slice(1).join(' ');

                role = guild.roles.cache.find(
                    r => r.name.toLowerCase() === deleteName.toLowerCase()
                );

                if (!role) {
                    return interactionOrMessage.reply(
                        '❌ Role not found.'
                    );
                }

                if (role.managed) {
                    return interactionOrMessage.reply(
                        '❌ I cannot delete a managed/integration role.'
                    );
                }

                if (role.position >= guild.members.me.roles.highest.position) {
                    return interactionOrMessage.reply(
                        '❌ That role is higher than or equal to my highest role.'
                    );
                }

                await role.delete(
                    `Role deleted by ${interactionOrMessage.author.tag}`
                );

                return interactionOrMessage.reply(
                    `✅ Deleted role **${role.name}**.`
                );
            }

            const userArg = args[1];

            if (!userArg) {
                return interactionOrMessage.reply(
                    '❌ Please mention a user.'
                );
            }

            const match = userArg.match(/^<@!?(\d+)>$/);
            const userId = match ? match[1] : userArg;

            try {
                targetUser = await guild.members.fetch(userId);
            } catch {
                return interactionOrMessage.reply(
                    '❌ User not found.'
                );
            }

            const actualRoleName = args.slice(2).join(' ');

            role = guild.roles.cache.find(
                r => r.name.toLowerCase() === actualRoleName.toLowerCase()
            );
        }

        if (!role) {
            return interactionOrMessage.reply({
                content: '❌ Role not found.',
                ephemeral: isSlash
            });
        }

        if (role.managed) {
            return interactionOrMessage.reply({
                content: '❌ I cannot manage a managed/integration role.',
                ephemeral: isSlash
            });
        }

        if (role.position >= guild.members.me.roles.highest.position) {
            return interactionOrMessage.reply({
                content:
                    '❌ That role is higher than or equal to my highest role.',
                ephemeral: isSlash
            });
        }

        if (targetUser.roles.highest.position >= guild.members.me.roles.highest.position) {
            return interactionOrMessage.reply({
                content:
                    '❌ I cannot manage this user's roles because their highest role is higher than or equal to mine.',
                ephemeral: isSlash
            });
        }

        try {
            if (subcommand === 'add' || subcommand === 'give') {
                if (targetUser.roles.cache.has(role.id)) {
                    return interactionOrMessage.reply({
                        content: `⚠️ **${targetUser.user.username}** already has **${role.name}**.`,
                        ephemeral: isSlash
                    });
                }

                await targetUser.roles.add(
                    role,
                    `Role given by ${isSlash ? interactionOrMessage.user.tag : interactionOrMessage.author.tag}`
                );

                return interactionOrMessage.reply({
                    content: `✅ Added **${role.name}** to **${targetUser.user.username}**.`,
                    allowedMentions: { parse: [] }
                });
            }

            if (subcommand === 'remove') {
                if (!targetUser.roles.cache.has(role.id)) {
                    return interactionOrMessage.reply({
                        content: `⚠️ **${targetUser.user.username}** doesn't have **${role.name}**.`,
                        ephemeral: isSlash
                    });
                }

                await targetUser.roles.remove(
                    role,
                    `Role removed by ${isSlash ? interactionOrMessage.user.tag : interactionOrMessage.author.tag}`
                );

                return interactionOrMessage.reply({
                    content: `✅ Removed **${role.name}** from **${targetUser.user.username}**.`,
                    allowedMentions: { parse: [] }
                });
            }

            return interactionOrMessage.reply({
                content: '❌ Unknown role subcommand.',
                ephemeral: isSlash
            });

        } catch (error) {
            console.error('Role command error:', error);

            return interactionOrMessage.reply({
                content:
                    '❌ Something went wrong while managing the role. Make sure I have **Manage Roles** permission.',
                ephemeral: isSlash
            });
        }
    }
};