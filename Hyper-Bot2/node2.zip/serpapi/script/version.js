"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.version = void 0;
/**
 * Specifies the version of the module.
 * Follows [semantic versioning](https://semver.org/).
 *
 * Changing this value creates a new release.
 */
exports.version = "2.2.1";
