"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RequestTimeoutError = exports.InvalidTimeoutError = exports.MissingApiKeyError = exports.InvalidArgumentError = void 0;
class InvalidArgumentError extends Error {
    constructor() {
        super("Arguments are missing or of incorrect type");
        Object.setPrototypeOf(this, InvalidArgumentError.prototype);
    }
}
exports.InvalidArgumentError = InvalidArgumentError;
class MissingApiKeyError extends Error {
    constructor() {
        super("api_key is required, get it from: https://serpapi.com/manage-api-key");
        Object.setPrototypeOf(this, MissingApiKeyError.prototype);
    }
}
exports.MissingApiKeyError = MissingApiKeyError;
class InvalidTimeoutError extends Error {
    constructor() {
        super("Enter a valid timeout in milliseconds");
        Object.setPrototypeOf(this, InvalidTimeoutError.prototype);
    }
}
exports.InvalidTimeoutError = InvalidTimeoutError;
class RequestTimeoutError extends Error {
    constructor() {
        super("The request was timed out");
        Object.setPrototypeOf(this, RequestTimeoutError.prototype);
    }
}
exports.RequestTimeoutError = RequestTimeoutError;
