"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getLocations = exports.getAccount = exports.getHtmlBySearchId = exports.getJsonBySearchId = exports.getHtml = exports.getJson = void 0;
const errors_js_1 = require("./errors.js");
const utils_js_1 = require("./utils.js");
const validators_js_1 = require("./validators.js");
const ACCOUNT_PATH = "/account";
const LOCATIONS_PATH = "/locations.json";
const SEARCH_PATH = "/search";
const SEARCH_ARCHIVE_PATH = `/searches`;
function getJson(...args) {
    if (typeof args[0] === "string" && typeof args[1] === "object") {
        const [engine, parameters, callback] = args;
        const newParameters = Object.assign(Object.assign({}, parameters), { engine });
        return _getJson(newParameters, callback);
    }
    else if (typeof args[0] === "object" &&
        typeof args[1] !== "object" &&
        (typeof args[1] === "undefined" || typeof args[1] === "function")) {
        const [parameters, callback] = args;
        return _getJson(parameters, callback);
    }
    else {
        throw new errors_js_1.InvalidArgumentError();
    }
}
exports.getJson = getJson;
async function _getJson(parameters, callback) {
    const key = (0, validators_js_1.validateApiKey)(parameters.api_key, true);
    const timeout = (0, validators_js_1.validateTimeout)(parameters.timeout);
    const response = await utils_js_1._internals.execute(SEARCH_PATH, Object.assign(Object.assign({}, parameters), { api_key: key, output: "json" }), timeout);
    const json = JSON.parse(response);
    callback === null || callback === void 0 ? void 0 : callback(json);
    return json;
}
function getHtml(...args) {
    if (typeof args[0] === "string" && typeof args[1] === "object") {
        const [engine, parameters, callback] = args;
        const newParameters = Object.assign(Object.assign({}, parameters), { engine });
        return _getHtml(newParameters, callback);
    }
    else if (typeof args[0] === "object" &&
        typeof args[1] !== "object" &&
        (typeof args[1] === "undefined" || typeof args[1] === "function")) {
        const [parameters, callback] = args;
        return _getHtml(parameters, callback);
    }
    else {
        throw new errors_js_1.InvalidArgumentError();
    }
}
exports.getHtml = getHtml;
async function _getHtml(parameters, callback) {
    const key = (0, validators_js_1.validateApiKey)(parameters.api_key, true);
    const timeout = (0, validators_js_1.validateTimeout)(parameters.timeout);
    const html = await utils_js_1._internals.execute(SEARCH_PATH, Object.assign(Object.assign({}, parameters), { api_key: key, output: "html" }), timeout);
    callback === null || callback === void 0 ? void 0 : callback(html);
    return html;
}
/**
 * Get a JSON response given a search ID.
 * - This search ID can be obtained from the `search_metadata.id` key in the response.
 * - Typically used together with the `async` parameter.
 *
 * @param {string} searchId Search ID.
 * @param {object} parameters
 * @param {string=} [parameters.api_key] API key.
 * @param {number=} [parameters.timeout] Timeout in milliseconds.
 * @param {fn=} callback Optional callback.
 * @example
 * const response = await getJson({ engine: "google", api_key: API_KEY, async: true, q: "coffee" });
 * const { id } = response.search_metadata;
 * await delay(1000); // wait for the request to be processed.
 *
 * // async/await
 * const json = await getJsonBySearchId(id, { api_key: API_KEY });
 *
 * // callback
 * getJsonBySearchId(id, { api_key: API_KEY }, console.log);
 */
async function getJsonBySearchId(searchId, parameters = {}, callback) {
    const key = (0, validators_js_1.validateApiKey)(parameters.api_key);
    const timeout = (0, validators_js_1.validateTimeout)(parameters.timeout);
    const response = await utils_js_1._internals.execute(`${SEARCH_ARCHIVE_PATH}/${searchId}`, {
        api_key: key,
        output: "json",
    }, timeout);
    const json = JSON.parse(response);
    callback === null || callback === void 0 ? void 0 : callback(json);
    return json;
}
exports.getJsonBySearchId = getJsonBySearchId;
/**
 * Get a HTML response given a search ID.
 * - This search ID can be obtained from the `search_metadata.id` key in the response.
 * - Typically used together with the `async` parameter.
 *
 * @param {string} searchId Search ID.
 * @param {object} parameters
 * @param {string=} [parameters.api_key] API key.
 * @param {number=} [parameters.timeout] Timeout in milliseconds.
 * @param {fn=} callback Optional callback.
 * @example
 * const response = await getJson({ engine: "google", api_key: API_KEY, async: true, q: "coffee" });
 * const { id } = response.search_metadata;
 * await delay(1000); // wait for the request to be processed.
 *
 * // async/await
 * const html = await getHtmlBySearchId(id, { api_key: API_KEY });
 *
 * // callback
 * getHtmlBySearchId(id, { api_key: API_KEY }, console.log);
 */
async function getHtmlBySearchId(searchId, parameters = {}, callback) {
    const key = (0, validators_js_1.validateApiKey)(parameters.api_key);
    const timeout = (0, validators_js_1.validateTimeout)(parameters.timeout);
    const html = await utils_js_1._internals.execute(`${SEARCH_ARCHIVE_PATH}/${searchId}`, {
        api_key: key,
        output: "html",
    }, timeout);
    callback === null || callback === void 0 ? void 0 : callback(html);
    return html;
}
exports.getHtmlBySearchId = getHtmlBySearchId;
/**
 * Get account information of an API key.
 *
 * Refer to https://serpapi.com/account-api for response examples.
 *
 * @param {object} parameters
 * @param {string=} [parameters.api_key] API key.
 * @param {number=} [parameters.timeout] Timeout in milliseconds.
 * @param {fn=} callback Optional callback.
 * @example
 * // async/await
 * const info = await getAccount({ api_key: API_KEY });
 *
 * // callback
 * getAccount({ api_key: API_KEY }, console.log);
 */
async function getAccount(parameters = {}, 
// deno-lint-ignore no-explicit-any
callback) {
    const key = (0, validators_js_1.validateApiKey)(parameters.api_key);
    const timeout = (0, validators_js_1.validateTimeout)(parameters.timeout);
    const response = await utils_js_1._internals.execute(ACCOUNT_PATH, {
        api_key: key,
    }, timeout);
    const info = JSON.parse(response);
    callback === null || callback === void 0 ? void 0 : callback(info);
    return info;
}
exports.getAccount = getAccount;
/**
 * Get supported locations. Does not require an API key.
 *
 * Refer to https://serpapi.com/locations-api for response examples.
 *
 * @param {object} parameters
 * @param {string=} [parameters.q] Query for a location.
 * @param {number=} [parameters.limit] Limit on number of locations returned.
 * @param {number=} [parameters.timeout] Timeout in milliseconds.
 * @param {fn=} callback Optional callback.
 * @example
 * // async/await
 * const locations = await getLocations({ limit: 3 });
 *
 * // callback
 * getLocations({ limit: 3 }, console.log);
 */
async function getLocations(parameters = {}, 
// deno-lint-ignore no-explicit-any
callback) {
    const timeout = (0, validators_js_1.validateTimeout)(parameters.timeout);
    const response = await utils_js_1._internals.execute(LOCATIONS_PATH, parameters, timeout);
    const locations = JSON.parse(response);
    callback === null || callback === void 0 ? void 0 : callback(locations);
    return locations;
}
exports.getLocations = getLocations;
