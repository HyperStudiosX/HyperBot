"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateTimeout = exports.validateApiKey = void 0;
const config_js_1 = require("./config.js");
const errors_js_1 = require("./errors.js");
function validateApiKey(value, allowNull = false) {
    // `api_key` can be null to support unmetered queries.
    if (allowNull && value === null) {
        return undefined;
    }
    const key = value !== null && value !== void 0 ? value : config_js_1.config.api_key;
    if (!key)
        throw new errors_js_1.MissingApiKeyError();
    return key;
}
exports.validateApiKey = validateApiKey;
function validateTimeout(value) {
    const timeout = value !== null && value !== void 0 ? value : config_js_1.config.timeout;
    if (timeout <= 0)
        throw new errors_js_1.InvalidTimeoutError();
    return timeout;
}
exports.validateTimeout = validateTimeout;
