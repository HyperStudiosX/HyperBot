export declare function validateApiKey(value: string | undefined | null): string;
export declare function validateApiKey(value: string | undefined | null, allowNull: boolean): string | undefined;
export declare function validateTimeout(value: number | undefined): number;
