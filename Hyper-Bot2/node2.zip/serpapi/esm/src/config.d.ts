/// <reference types="node" />
import http from "http";
export type Config = {
    api_key: string | null;
    timeout: number;
    requestOptions?: http.RequestOptions;
};
export declare const config: Config;
