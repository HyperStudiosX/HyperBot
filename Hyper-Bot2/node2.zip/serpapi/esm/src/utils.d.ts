/// <reference types="node" />
/// <reference types="node" />
import http from "http";
import qs from "querystring";
/**
 * This `_internals` object is needed to support stubbing/spying of
 * certain functions in this file.
 * https://deno.land/manual@v1.28.3/basics/testing/mocking
 *
 * It's also useful to encapsulate functions that are polyfilled.
 */
export declare const _internals: {
    execute: typeof execute;
    getHostnameAndPort: typeof getHostnameAndPort;
};
/** Facilitates stubbing in tests */
declare function getHostnameAndPort(): {
    hostname: string;
    port: number;
};
export declare function getSource(): string;
export declare function buildRequestOptions(path: string, parameters: qs.ParsedUrlQueryInput): http.RequestOptions;
export declare function execute(path: string, parameters: qs.ParsedUrlQueryInput, timeout: number): Promise<string>;
export {};
