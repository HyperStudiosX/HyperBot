import { AccountApiParameters, BaseResponse, EngineParameters, GetBySearchIdParameters, LocationsApiParameters } from "./types.js";
/**
 * Get JSON response based on search parameters.
 *
 * @param {object} parameters Search query parameters for the engine. Refer to https://serpapi.com/search-api for parameter explanations.
 * @param {fn=} callback Optional callback.
 * @example
 * // single call (async/await)
 * const json = await getJson({ engine: "google", api_key: API_KEY, q: "coffee" });
 *
 * // single call (callback)
 * getJson({ engine: "google", api_key: API_KEY, q: "coffee" }, console.log);
 */
export declare function getJson(parameters: EngineParameters, callback?: (json: BaseResponse) => void): Promise<BaseResponse>;
/**
 * Get JSON response based on search parameters.
 *
 * @param {string} engine Engine name. Refer to https://serpapi.com/search-api for valid engines.
 * @param {object} parameters Search query parameters for the engine. Refer to https://serpapi.com/search-api for parameter explanations.
 * @param {fn=} callback Optional callback.
 * @example
 * // single call (async/await)
 * const json = await getJson("google", { api_key: API_KEY, q: "coffee" });
 *
 * // single call (callback)
 * getJson("google", { api_key: API_KEY, q: "coffee" }, console.log);
 */
export declare function getJson(engine: string, parameters: EngineParameters, callback?: (json: BaseResponse) => void): Promise<BaseResponse>;
/**
 * Get raw HTML response based on search parameters.
 *
 * @param {object} parameters Search query parameters for the engine. Refer to https://serpapi.com/search-api for parameter explanations.
 * @param {fn=} callback Optional callback.
 * @example
 * // async/await
 * const html = await getHtml({ engine: "google", api_key: API_KEY, q: "coffee" });
 *
 * // callback
 * getHtml({ engine: "google", api_key: API_KEY, q: "coffee" }, console.log);
 */
export declare function getHtml(parameters: EngineParameters, callback?: (html: string) => void): Promise<string>;
/**
 * Get raw HTML response based on search parameters.
 *
 * @param {string} engine Engine name. Refer to https://serpapi.com/search-api for valid engines.
 * @param {object} parameters Search query parameters for the engine. Refer to https://serpapi.com/search-api for parameter explanations.
 * @param {fn=} callback Optional callback.
 * @example
 * // async/await
 * const html = await getHtml({ engine: "google", api_key: API_KEY, q: "coffee" });
 *
 * // callback
 * getHtml({ engine: "google", api_key: API_KEY, q: "coffee" }, console.log);
 */
export declare function getHtml(engine: string, parameters: EngineParameters, callback?: (html: string) => void): Promise<string>;
/**
 * Get a JSON response given a search ID.
 * - This search ID can be obtained from the `search_metadata.id` key in the response.
 * - Typically used together with the `async` parameter.
 *
 * @param {string} searchId Search ID.
 * @param {object} parameters
 * @param {string=} [parameters.api_key] API key.
 * @param {number=} [parameters.timeout] Timeout in milliseconds.
 * @param {fn=} callback Optional callback.
 * @example
 * const response = await getJson({ engine: "google", api_key: API_KEY, async: true, q: "coffee" });
 * const { id } = response.search_metadata;
 * await delay(1000); // wait for the request to be processed.
 *
 * // async/await
 * const json = await getJsonBySearchId(id, { api_key: API_KEY });
 *
 * // callback
 * getJsonBySearchId(id, { api_key: API_KEY }, console.log);
 */
export declare function getJsonBySearchId(searchId: string, parameters?: GetBySearchIdParameters, callback?: (json: BaseResponse) => void): Promise<BaseResponse>;
/**
 * Get a HTML response given a search ID.
 * - This search ID can be obtained from the `search_metadata.id` key in the response.
 * - Typically used together with the `async` parameter.
 *
 * @param {string} searchId Search ID.
 * @param {object} parameters
 * @param {string=} [parameters.api_key] API key.
 * @param {number=} [parameters.timeout] Timeout in milliseconds.
 * @param {fn=} callback Optional callback.
 * @example
 * const response = await getJson({ engine: "google", api_key: API_KEY, async: true, q: "coffee" });
 * const { id } = response.search_metadata;
 * await delay(1000); // wait for the request to be processed.
 *
 * // async/await
 * const html = await getHtmlBySearchId(id, { api_key: API_KEY });
 *
 * // callback
 * getHtmlBySearchId(id, { api_key: API_KEY }, console.log);
 */
export declare function getHtmlBySearchId(searchId: string, parameters?: GetBySearchIdParameters, callback?: (html: string) => void): Promise<string>;
/**
 * Get account information of an API key.
 *
 * Refer to https://serpapi.com/account-api for response examples.
 *
 * @param {object} parameters
 * @param {string=} [parameters.api_key] API key.
 * @param {number=} [parameters.timeout] Timeout in milliseconds.
 * @param {fn=} callback Optional callback.
 * @example
 * // async/await
 * const info = await getAccount({ api_key: API_KEY });
 *
 * // callback
 * getAccount({ api_key: API_KEY }, console.log);
 */
export declare function getAccount(parameters?: AccountApiParameters, callback?: (info: any) => void): Promise<any>;
/**
 * Get supported locations. Does not require an API key.
 *
 * Refer to https://serpapi.com/locations-api for response examples.
 *
 * @param {object} parameters
 * @param {string=} [parameters.q] Query for a location.
 * @param {number=} [parameters.limit] Limit on number of locations returned.
 * @param {number=} [parameters.timeout] Timeout in milliseconds.
 * @param {fn=} callback Optional callback.
 * @example
 * // async/await
 * const locations = await getLocations({ limit: 3 });
 *
 * // callback
 * getLocations({ limit: 3 }, console.log);
 */
export declare function getLocations(parameters?: LocationsApiParameters, callback?: (locations: any) => void): Promise<any>;
