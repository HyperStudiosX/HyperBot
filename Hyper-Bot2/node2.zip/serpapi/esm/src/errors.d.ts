export declare class InvalidArgumentError extends Error {
    constructor();
}
export declare class MissingApiKeyError extends Error {
    constructor();
}
export declare class InvalidTimeoutError extends Error {
    constructor();
}
export declare class RequestTimeoutError extends Error {
    constructor();
}
