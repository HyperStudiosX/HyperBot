/**
 * Specifies the version of the module.
 * Follows [semantic versioning](https://semver.org/).
 *
 * Changing this value creates a new release.
 */
export declare const version = "2.2.1";
